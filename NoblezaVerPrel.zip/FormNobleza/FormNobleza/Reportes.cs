﻿using FormNobleza.Data;
using System;
using System.Data;
using System.Windows.Forms;
using FormNobleza.Services; 

namespace FormNobleza
{
    public partial class Reportes : Form
    {

        public Reportes()
        {
            InitializeComponent();
            AplicarEstiloCorporativoGrid();
            _busquedaSinResultados = false;
            ReportesGrid.Visible = true;
            btnPDFS.Enabled = false;
            btnResponsiva.Enabled = false;

        }
        private bool _busquedaSinResultados = false;
        private readonly ReportesRepository _reportesRepo = new ReportesRepository();

        // BOTONES DE NAVEGACIÓN DEL MENÚ LATERAL
        private void btnReportes_Click(object sender, EventArgs e)
        {
            Reportes pantallaDashboard = new Reportes();
        
            pantallaDashboard.FormClosed += (s, args) => this.Close();
            pantallaDashboard.Show();
            this.Hide();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            Menu pantallaDashboard = new Menu();
            pantallaDashboard.FormClosed += (s, args) => this.Close();

            pantallaDashboard.Show();
            this.Hide();
        }

        private void btnCrud_Click(object sender, EventArgs e)
        {
            Crud pantallaDashboard = new Crud();
            pantallaDashboard.FormClosed += (s, args) => this.Close();

            pantallaDashboard.Show();
            this.Hide();
        }

        private void btnTracking_Click(object sender, EventArgs e)
        {
            Tracking pantallaDashboard = new Tracking();
            pantallaDashboard.FormClosed += (s, args) => this.Close();

            pantallaDashboard.Show();
            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult confirmacion = MessageBox.Show("¿Estás seguro de que deseas salir del sistema?", "Confirmar salida",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
            );

            // 2. Evaluamos qué botón presionó el usuario
            if (confirmacion == DialogResult.Yes)
            {
                FormLogin pantallaDashboard = new FormLogin();
                pantallaDashboard.FormClosed += (s, args) => this.Close();

                pantallaDashboard.Show();

                this.Hide(); // Oculta el login
            }
        }

        // ========================================================
        // LÓGICA DEL BUSCADOR (CON LA TECLA ENTER)
        // ========================================================
        private void txtSerie_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Silenciamos el "Ding" de Windows
                e.SuppressKeyPress = true;

                // Usamos  variable: txtSerie
                string serie = txtSerie.Text.Trim();

                if (string.IsNullOrWhiteSpace(serie))
                {
                    MessageBox.Show("Ingresa un número de serie para buscar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                try
                {
                    // Vamos a MariaDB por el historial fusionado
                    DataTable historial = _reportesRepo.ObtenerLineaDeTiempoCompleta(serie);

                    if (historial.Rows.Count > 0)
                    {
                        btnResponsiva.Enabled = true;
                        btnPDFS.Enabled = true;
                        ReportesGrid.Visible = true;
                        lblEnter.Text = "Numero de Serie hallado.";
                        lblEnter.ForeColor = Color.RoyalBlue;
                        lblEnter.Visible = true;
                        // Pintamos en el Grid: ReportesGrid
                        ReportesGrid.DataSource = historial;

                        // ACÁ LE CAMBIAS EL NOMBRE VISUAL A LAS COLUMNAS
                        ReportesGrid.Columns["numeroSerie"].HeaderText = "Número de Serie";
                        ReportesGrid.Columns["nombreEquipo"].HeaderText = "Nombre del Equipo";
                        ReportesGrid.Columns["nombreTrabajador"].HeaderText = "Nombre Empleado";
                        ReportesGrid.Columns["nave"].HeaderText = "Nave";
                        ReportesGrid.Columns["comentarios"].HeaderText = "Comentarios";
                        ReportesGrid.Columns["estado"].HeaderText = "Estado de Asignación";
                        ReportesGrid.Columns["fecha"].HeaderText = "Fecha de Registro";


                    }
                    else
                    {
                        _busquedaSinResultados = true;
                        lblEnter.Text = "Numero de Serie inexistente.";
                        lblEnter.ForeColor = Color.Red;
                        lblEnter.Visible = true;
                        ReportesGrid.DataSource = null;
                        btnPDFS.Enabled = false;
                        ReportesGrid.Invalidate();

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Error de Servidor", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // ========================================================
        // LÓGICA DE EXPORTACIÓN A PDF
        // ========================================================
        private void btnPDFS_Click(object sender, EventArgs e)
        {
            string serie = txtSerie.Text.Trim();

            if (string.IsNullOrWhiteSpace(serie))
            {
                MessageBox.Show("Ingrese un número de serie.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // 1. Obtenemos la tabla de movimientos (El historial)
                DataTable datosHistorial = _reportesRepo.ObtenerLineaDeTiempoCompleta(serie);

                // 2. Obtenemos las características del equipo
                DataTable datosHw = _reportesRepo.ObtenerDatosHardwareParaPDF(serie);

                string procesador = "N/A";
                string ram = "N/A";
                string disco = "N/A";
                string sistema = "N/A";
                string fechaCreacion = "N/A";

                if (datosHw.Rows.Count > 0)
                {
                    DataRow filaHw = datosHw.Rows[0];
                    procesador = filaHw["nombreProcesador"].ToString();
                    ram = filaHw["ram"].ToString();
                    disco = filaHw["disco"].ToString();
                    sistema = filaHw["nombreSistema"].ToString();

                    DateTime fechaRaw = Convert.ToDateTime(filaHw["fechaCreacion"]);
                    fechaCreacion = fechaRaw.ToString("dd/MM/yyyy");
                }

                using (SaveFileDialog ventanaGuardar = new SaveFileDialog())
                {
                    ventanaGuardar.Filter = "Documento PDF (*.pdf)|*.pdf";
                    ventanaGuardar.FileName = $"Historial_{serie}_{DateTime.Now:yyyyMMdd}";

                    if (ventanaGuardar.ShowDialog() == DialogResult.OK)
                    {
                        GeneradorReportesPDF pdfService = new GeneradorReportesPDF();

                        // AQUÍ LE PASAMOS LOS 8 DATOS EXACTOS AL MÉTODO DEL HISTORIAL
                        pdfService.ExportarHistorialAPdf(ventanaGuardar.FileName, serie, procesador, ram, disco, sistema, fechaCreacion, datosHistorial);

                        MessageBox.Show("Historial exportado con éxito.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo() { FileName = ventanaGuardar.FileName, UseShellExecute = true });
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al generar el historial: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void AplicarEstiloCorporativoGrid()
        {
            // 1. OBLIGATORIO: Apagar el estilo por defecto para que deje pintar tus colores
            ReportesGrid.EnableHeadersVisualStyles = false;

            // 2. ENCABEZADOS (Títulos) - Tu Azul Rey (#00479A)
            ReportesGrid.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#00479A");
            ReportesGrid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            // Usamos Arial directo, en negritas para que el título resalte
            ReportesGrid.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            ReportesGrid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            ReportesGrid.ColumnHeadersHeight = 35;

            // 3. TABLA GENERAL (Filas) - Tu Azul Cian (#00738A)
            ReportesGrid.DefaultCellStyle.BackColor = ColorTranslator.FromHtml("#00738A");
            ReportesGrid.DefaultCellStyle.ForeColor = Color.White;
            // Usamos Arial regular para la lectura de los datos
            ReportesGrid.DefaultCellStyle.Font = new Font("Arial", 9);

            // 4. FILAS ALTERNADAS (Efecto cebra)
            // Le puse un tono apenitas más oscuro que el #00738A para no cansar la vista
            ReportesGrid.AlternatingRowsDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#006579");

            // 5. SELECCIÓN (Cuando le das clic a un equipo)
            // Mantenemos tu azul oscuro para que se note claramente qué fila agarraste
            ReportesGrid.DefaultCellStyle.SelectionBackColor = ColorTranslator.FromHtml("#002B5E");
            ReportesGrid.DefaultCellStyle.SelectionForeColor = Color.White;

            // 6. BORDES Y APARIENCIA GENERAL
            ReportesGrid.BorderStyle = BorderStyle.None;
            ReportesGrid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            // Cambié el borde de la celda a un gris muy claro para que la línea blanca pura no "deslumbre"
            ReportesGrid.GridColor = Color.LightGray;

            // Ocultar la columna de la flechita izquierda y autoajustar el tamaño
            ReportesGrid.RowHeadersVisible = false;
            ReportesGrid.AllowUserToResizeRows = false;
            // Esto permite seleccionar celdas individuales en lugar de toda la fila
            ReportesGrid.SelectionMode = DataGridViewSelectionMode.CellSelect;
            // Esto habilita la copia nativa con Ctrl+C
            ReportesGrid.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            // Reemplaza el Fill por esto:
            ReportesGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            ReportesGrid.AllowUserToResizeColumns = true;

        }


        private void CentrarPanel()
        {
            // Verificamos que el panel ya esté cargado en memoria
            if (panelPrincipal != null)
            {
                // 1. Calculamos la mitad exacta del ancho libre
                int centroX = (this.ClientSize.Width - panelPrincipal.Width) / 2;

                // 2. Calculamos la mitad exacta de la altura libre
                int centroY = (this.ClientSize.Height - panelPrincipal.Height) / 2;

                // 3. Movemos el panel a esas coordenadas
                panelPrincipal.Location = new Point(centroX, centroY);
            }
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtSerie_TextChanged(object sender, EventArgs e)
        {

        }

        private void Reportes_Load(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void ReportesGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panelPrincipal_Resize(object sender, EventArgs e)
        {

        }

        private void Reportes_Resize(object sender, EventArgs e)
        {
            CentrarPanel();
        }

        private void btnResponsiva_Click(object sender, EventArgs e)
        {
            string serie = txtSerie.Text.Trim(); // Asegúrate de que tu TextBox se llame así

            if (string.IsNullOrWhiteSpace(serie))
            {
                MessageBox.Show("Por favor, escanea o ingresa primero un número de serie.", "Serie Requerida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                DataTable datosHw = _reportesRepo.ObtenerDatosHardwareParaPDF(serie);

                if (datosHw.Rows.Count == 0)
                {
                    MessageBox.Show("No se encontró ningún equipo registrado con este número de serie.", "No Encontrado", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // AQUÍ NACE LA VARIABLE 'fila', de aquí sacamos todo
                DataRow fila = datosHw.Rows[0];

                string modelo = fila["Modelo"].ToString();
                string tipo = fila["NombreCategoria"].ToString();
                string marca = fila["nombreMarca"].ToString();

                string procesador = fila["nombreProcesador"].ToString();
                string ram = fila["ram"].ToString();
                string disco = fila["disco"].ToString();
                string sistema = fila["nombreSistema"].ToString();

                // AQUÍ EXTRAEMOS Y FORMATEAMOS LA FECHA
                DateTime fechaRaw = Convert.ToDateTime(fila["fechaCreacion"]);
                string fechaCreacion = fechaRaw.ToString("dd/MM/yyyy");

                string nombreEmpleado = fila.IsNull("nombreTrabajador") || string.IsNullOrWhiteSpace(fila["nombreTrabajador"].ToString()) ? "SIN ASIGNAR" : fila["nombreTrabajador"].ToString();
                string comentarios = fila.IsNull("comentarios") || string.IsNullOrWhiteSpace(fila["comentarios"].ToString()) ? "Ninguno" : fila["comentarios"].ToString();

                using (SaveFileDialog ventanaGuardar = new SaveFileDialog())
                {
                    ventanaGuardar.Filter = "Documento PDF (*.pdf)|*.pdf";
                    ventanaGuardar.FileName = $"Responsiva_{serie}_{DateTime.Now:yyyyMMdd}";

                    if (ventanaGuardar.ShowDialog() == DialogResult.OK)
                    {
                        GeneradorReportesPDF pdfService = new GeneradorReportesPDF();

                        // AQUÍ LE PASAMOS LOS 12 DATOS EXACTOS, INCLUYENDO LA FECHA
                        pdfService.ExportarCartaResponsiva(ventanaGuardar.FileName, nombreEmpleado, tipo, marca, modelo, serie, procesador, ram, disco, sistema, fechaCreacion, comentarios);

                        MessageBox.Show("La carta responsiva ha sido generada.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo() { FileName = ventanaGuardar.FileName, UseShellExecute = true });
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al generar la responsiva: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void panel4_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void ReportesGrid_Paint(object sender, PaintEventArgs e)
        
        {
            if (ReportesGrid.Rows.Count > 0)
            {
                return;
            }
            if (_busquedaSinResultados)
            {
                string mensaje = "EQUIPO INEXISTENTE\nInserte un número de serie distinto";

                Font fuente = new Font("Arial", 14, FontStyle.Bold);
                Brush brocha = new SolidBrush(Color.LightSlateGray);

                StringFormat formato = new StringFormat();
                formato.Alignment = StringAlignment.Center;
                formato.LineAlignment = StringAlignment.Center;

                Rectangle area = new Rectangle(0, 0, ReportesGrid.Width, ReportesGrid.Height);

                e.Graphics.DrawString(mensaje, fuente, brocha, area, formato);
            }
            else
            {
                string mensaje = "\nDIGITE UN NUMERO DE SERIE";

                Font fuente = new Font("Arial", 14, FontStyle.Bold);
                Brush brocha = new SolidBrush(Color.LightSlateGray);

                StringFormat formato = new StringFormat();
                formato.Alignment = StringAlignment.Center;
                formato.LineAlignment = StringAlignment.Center;

                Rectangle area = new Rectangle(0, 0, ReportesGrid.Width, ReportesGrid.Height);

                e.Graphics.DrawString(mensaje, fuente, brocha, area, formato);
            }
        }
    }
}
