﻿namespace FormNobleza
{
    partial class Tracking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tracking));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            label4 = new Label();
            label5 = new Label();
            btnGuardarAsignacion = new Button();
            txtnumeroSerie = new TextBox();
            cmbUbicacion = new ComboBox();
            txtComentarios = new TextBox();
            txtEncargado = new TextBox();
            label7 = new Label();
            dataGridAsignacion = new DataGridView();
            panel1 = new Panel();
            pictureBox4 = new PictureBox();
            panel3 = new Panel();
            btnLimpiar = new Button();
            btnDevoluciones = new Button();
            lblDevolucion = new Label();
            pictureBox1 = new PictureBox();
            txtNombreEquipo = new TextBox();
            lblEnter = new Label();
            lblInformacion = new Label();
            lblAlerta = new Label();
            pictureBox2 = new PictureBox();
            flowLayoutPanel1 = new FlowLayoutPanel();
            panel5 = new Panel();
            btnReportes = new Button();
            label11 = new Label();
            btnProfil = new Button();
            btnExit = new Button();
            btnTracking = new Button();
            btnCrud = new Button();
            btnHome = new Button();
            panelPrincipal = new Panel();
            flowLayoutPanel2 = new FlowLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)dataGridAsignacion).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel5.SuspendLayout();
            panelPrincipal.SuspendLayout();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(90, 320);
            label4.Name = "label4";
            label4.Size = new Size(0, 15);
            label4.TabIndex = 3;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(375, 384);
            label5.Name = "label5";
            label5.Size = new Size(0, 15);
            label5.TabIndex = 4;
            // 
            // btnGuardarAsignacion
            // 
            btnGuardarAsignacion.BackColor = Color.FromArgb(0, 115, 138);
            btnGuardarAsignacion.Cursor = Cursors.Hand;
            btnGuardarAsignacion.Enabled = false;
            btnGuardarAsignacion.FlatAppearance.BorderSize = 0;
            btnGuardarAsignacion.FlatStyle = FlatStyle.Flat;
            btnGuardarAsignacion.Font = new Font("Segoe UI Semibold", 12F);
            btnGuardarAsignacion.ForeColor = Color.FromArgb(248, 249, 250);
            btnGuardarAsignacion.Image = (Image)resources.GetObject("btnGuardarAsignacion.Image");
            btnGuardarAsignacion.ImageAlign = ContentAlignment.MiddleLeft;
            btnGuardarAsignacion.Location = new Point(17, 365);
            btnGuardarAsignacion.Name = "btnGuardarAsignacion";
            btnGuardarAsignacion.Size = new Size(209, 29);
            btnGuardarAsignacion.TabIndex = 5;
            btnGuardarAsignacion.Text = "Guardar";
            btnGuardarAsignacion.UseVisualStyleBackColor = false;
            btnGuardarAsignacion.Click += btnGuardarAsignacion_Click;
            // 
            // txtnumeroSerie
            // 
            txtnumeroSerie.BorderStyle = BorderStyle.None;
            txtnumeroSerie.Cursor = Cursors.IBeam;
            txtnumeroSerie.Font = new Font("Segoe UI Semibold", 12F);
            txtnumeroSerie.Location = new Point(17, 15);
            txtnumeroSerie.Name = "txtnumeroSerie";
            txtnumeroSerie.PlaceholderText = "Numero de Serie:";
            txtnumeroSerie.Size = new Size(189, 22);
            txtnumeroSerie.TabIndex = 0;
            txtnumeroSerie.KeyDown += txtnumeroSerie_KeyDown;
            // 
            // cmbUbicacion
            // 
            cmbUbicacion.Cursor = Cursors.Hand;
            cmbUbicacion.Enabled = false;
            cmbUbicacion.FlatStyle = FlatStyle.Flat;
            cmbUbicacion.Font = new Font("Segoe UI Semibold", 12F);
            cmbUbicacion.FormattingEnabled = true;
            cmbUbicacion.Items.AddRange(new object[] { "Nave 1", "Nave 2", "Nave 3", "Nave 4", "Nave 5", "Nave 6", "Nave 7", "Nave 8", "Nave 9", "Nave 10", "Nave 11", "", "" });
            cmbUbicacion.Location = new Point(17, 194);
            cmbUbicacion.Name = "cmbUbicacion";
            cmbUbicacion.Size = new Size(209, 29);
            cmbUbicacion.TabIndex = 2;
            cmbUbicacion.Text = "Nave";
            cmbUbicacion.SelectedIndexChanged += txtUbicacion_SelectedIndexChanged;
            cmbUbicacion.KeyDown += cmbUbicacion_KeyDown;
            // 
            // txtComentarios
            // 
            txtComentarios.BorderStyle = BorderStyle.None;
            txtComentarios.Cursor = Cursors.IBeam;
            txtComentarios.Enabled = false;
            txtComentarios.Font = new Font("Segoe UI Semibold", 12F);
            txtComentarios.Location = new Point(17, 303);
            txtComentarios.Name = "txtComentarios";
            txtComentarios.PlaceholderText = "Comentarios:";
            txtComentarios.Size = new Size(209, 22);
            txtComentarios.TabIndex = 4;
            txtComentarios.KeyDown += txtComentarios_KeyDown;
            // 
            // txtEncargado
            // 
            txtEncargado.BorderStyle = BorderStyle.None;
            txtEncargado.Cursor = Cursors.IBeam;
            txtEncargado.Enabled = false;
            txtEncargado.Font = new Font("Segoe UI Semibold", 12F);
            txtEncargado.Location = new Point(17, 229);
            txtEncargado.Name = "txtEncargado";
            txtEncargado.PlaceholderText = "Nombre del trabajador:";
            txtEncargado.Size = new Size(209, 22);
            txtEncargado.TabIndex = 3;
            txtEncargado.TextChanged += txtEncargado_TextChanged;
            txtEncargado.KeyDown += txtEncargado_KeyDown;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 18F);
            label7.ForeColor = Color.FromArgb(26, 26, 26);
            label7.Location = new Point(372, 19);
            label7.Name = "label7";
            label7.Size = new Size(301, 32);
            label7.TabIndex = 11;
            label7.Text = "ASIGNACIÓN DE EQUIPOS";
            label7.Click += label7_Click;
            // 
            // dataGridAsignacion
            // 
            dataGridAsignacion.AllowUserToAddRows = false;
            dataGridAsignacion.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = Color.AliceBlue;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9.5F);
            dataGridViewCellStyle1.SelectionBackColor = Color.LightSteelBlue;
            dataGridAsignacion.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridAsignacion.BackgroundColor = Color.FromArgb(235, 241, 246);
            dataGridAsignacion.BorderStyle = BorderStyle.None;
            dataGridAsignacion.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Control;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9.5F);
            dataGridViewCellStyle2.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dataGridAsignacion.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dataGridAsignacion.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9.5F);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = Color.Gainsboro;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dataGridAsignacion.DefaultCellStyle = dataGridViewCellStyle3;
            dataGridAsignacion.Location = new Point(10, 99);
            dataGridAsignacion.MultiSelect = false;
            dataGridAsignacion.Name = "dataGridAsignacion";
            dataGridAsignacion.ReadOnly = true;
            dataGridAsignacion.RowHeadersVisible = false;
            dataGridAsignacion.RowTemplate.Height = 35;
            dataGridAsignacion.SelectionMode = DataGridViewSelectionMode.CellSelect;
            dataGridAsignacion.Size = new Size(751, 515);
            dataGridAsignacion.TabIndex = 12;
            dataGridAsignacion.Paint += dataGridAsignacion_Paint;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(248, 249, 250);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(lblAlerta);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(dataGridAsignacion);
            panel1.Location = new Point(171, 18);
            panel1.Name = "panel1";
            panel1.Size = new Size(1029, 648);
            panel1.TabIndex = 13;
            panel1.Paint += panel1_Paint_1;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(922, 0);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(84, 69);
            pictureBox4.TabIndex = 35;
            pictureBox4.TabStop = false;
            // 
            // panel3
            // 
            panel3.Controls.Add(btnLimpiar);
            panel3.Controls.Add(btnDevoluciones);
            panel3.Controls.Add(lblDevolucion);
            panel3.Controls.Add(txtnumeroSerie);
            panel3.Controls.Add(pictureBox1);
            panel3.Controls.Add(cmbUbicacion);
            panel3.Controls.Add(txtNombreEquipo);
            panel3.Controls.Add(lblEnter);
            panel3.Controls.Add(txtComentarios);
            panel3.Controls.Add(lblInformacion);
            panel3.Controls.Add(btnGuardarAsignacion);
            panel3.Controls.Add(txtEncargado);
            panel3.Location = new Point(767, 87);
            panel3.Name = "panel3";
            panel3.Size = new Size(248, 527);
            panel3.TabIndex = 34;
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = Color.FromArgb(248, 249, 250);
            btnLimpiar.Cursor = Cursors.Hand;
            btnLimpiar.FlatAppearance.BorderSize = 0;
            btnLimpiar.FlatStyle = FlatStyle.Flat;
            btnLimpiar.Font = new Font("Segoe UI Semibold", 12F);
            btnLimpiar.ForeColor = Color.FromArgb(248, 249, 250);
            btnLimpiar.Image = (Image)resources.GetObject("btnLimpiar.Image");
            btnLimpiar.ImageAlign = ContentAlignment.MiddleLeft;
            btnLimpiar.Location = new Point(194, 329);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(32, 30);
            btnLimpiar.TabIndex = 39;
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // btnDevoluciones
            // 
            btnDevoluciones.BackColor = Color.FromArgb(0, 115, 138);
            btnDevoluciones.Cursor = Cursors.Hand;
            btnDevoluciones.Enabled = false;
            btnDevoluciones.FlatAppearance.BorderSize = 0;
            btnDevoluciones.FlatStyle = FlatStyle.Flat;
            btnDevoluciones.Font = new Font("Segoe UI Semibold", 12F);
            btnDevoluciones.ForeColor = Color.FromArgb(248, 249, 250);
            btnDevoluciones.Image = (Image)resources.GetObject("btnDevoluciones.Image");
            btnDevoluciones.ImageAlign = ContentAlignment.MiddleLeft;
            btnDevoluciones.Location = new Point(17, 103);
            btnDevoluciones.Name = "btnDevoluciones";
            btnDevoluciones.Size = new Size(209, 29);
            btnDevoluciones.TabIndex = 35;
            btnDevoluciones.Text = "Devolución";
            btnDevoluciones.UseVisualStyleBackColor = false;
            btnDevoluciones.Click += btnDevoluciones_Click;
            // 
            // lblDevolucion
            // 
            lblDevolucion.AutoSize = true;
            lblDevolucion.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDevolucion.ForeColor = Color.FromArgb(0, 115, 138);
            lblDevolucion.Location = new Point(50, 131);
            lblDevolucion.Name = "lblDevolucion";
            lblDevolucion.Size = new Size(168, 17);
            lblDevolucion.TabIndex = 36;
            lblDevolucion.Text = "Equipo devuelto a sistemas";
            lblDevolucion.TextAlign = ContentAlignment.TopCenter;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.Window;
            pictureBox1.BackgroundImage = Properties.Resources.search_24dp_00738A_FILL0_wght400_GRAD0_opsz24;
            pictureBox1.Location = new Point(203, 15);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(23, 22);
            pictureBox1.TabIndex = 33;
            pictureBox1.TabStop = false;
            // 
            // txtNombreEquipo
            // 
            txtNombreEquipo.BorderStyle = BorderStyle.None;
            txtNombreEquipo.Cursor = Cursors.IBeam;
            txtNombreEquipo.Font = new Font("Segoe UI Semibold", 12F);
            txtNombreEquipo.Location = new Point(17, 266);
            txtNombreEquipo.Name = "txtNombreEquipo";
            txtNombreEquipo.PlaceholderText = "Nombre del equipo:";
            txtNombreEquipo.Size = new Size(209, 22);
            txtNombreEquipo.TabIndex = 2;
            txtNombreEquipo.TextChanged += txtIdTrabajador_TextChanged;
            txtNombreEquipo.KeyDown += txtNombreEquipo_KeyDown;
            // 
            // lblEnter
            // 
            lblEnter.AutoSize = true;
            lblEnter.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblEnter.ForeColor = Color.FromArgb(0, 115, 138);
            lblEnter.Location = new Point(28, 56);
            lblEnter.Name = "lblEnter";
            lblEnter.Size = new Size(101, 17);
            lblEnter.TabIndex = 21;
            lblEnter.Text = "Presione ENTER";
            lblEnter.TextAlign = ContentAlignment.TopCenter;
            // 
            // lblInformacion
            // 
            lblInformacion.AutoSize = true;
            lblInformacion.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblInformacion.ForeColor = Color.FromArgb(0, 115, 138);
            lblInformacion.Location = new Point(50, 174);
            lblInformacion.Name = "lblInformacion";
            lblInformacion.Size = new Size(144, 17);
            lblInformacion.TabIndex = 20;
            lblInformacion.Text = "Información del equipo";
            lblInformacion.TextAlign = ContentAlignment.TopCenter;
            // 
            // lblAlerta
            // 
            lblAlerta.AutoSize = true;
            lblAlerta.ForeColor = Color.FromArgb(255, 128, 128);
            lblAlerta.Location = new Point(513, 87);
            lblAlerta.Name = "lblAlerta";
            lblAlerta.Size = new Size(0, 15);
            lblAlerta.TabIndex = 15;
            lblAlerta.Click += label1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Excel2__1_1;
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(178, 81);
            pictureBox2.TabIndex = 14;
            pictureBox2.TabStop = false;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel1.Location = new Point(3, 0);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(1200, 19);
            flowLayoutPanel1.TabIndex = 17;
            flowLayoutPanel1.Paint += flowLayoutPanel1_Paint;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(248, 249, 250);
            panel5.Controls.Add(btnReportes);
            panel5.Controls.Add(label11);
            panel5.Controls.Add(btnProfil);
            panel5.Controls.Add(btnExit);
            panel5.Controls.Add(btnTracking);
            panel5.Controls.Add(btnCrud);
            panel5.Controls.Add(btnHome);
            panel5.Location = new Point(3, 18);
            panel5.Name = "panel5";
            panel5.Size = new Size(162, 647);
            panel5.TabIndex = 32;
            panel5.Paint += panel5_Paint;
            // 
            // btnReportes
            // 
            btnReportes.BackColor = Color.FromArgb(248, 249, 250);
            btnReportes.Cursor = Cursors.Hand;
            btnReportes.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnReportes.FlatAppearance.BorderSize = 2;
            btnReportes.FlatStyle = FlatStyle.Flat;
            btnReportes.Font = new Font("Segoe UI Semibold", 9F);
            btnReportes.ForeColor = Color.Black;
            btnReportes.Image = (Image)resources.GetObject("btnReportes.Image");
            btnReportes.ImageAlign = ContentAlignment.MiddleLeft;
            btnReportes.Location = new Point(19, 253);
            btnReportes.Name = "btnReportes";
            btnReportes.Size = new Size(121, 37);
            btnReportes.TabIndex = 12;
            btnReportes.Text = "Reportes";
            btnReportes.UseVisualStyleBackColor = false;
            btnReportes.Click += btnReportes_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(19, 62);
            label11.Name = "label11";
            label11.Size = new Size(111, 15);
            label11.TabIndex = 6;
            label11.Text = "¡HOLA, INGENIERO!";
            // 
            // btnProfil
            // 
            btnProfil.Cursor = Cursors.Hand;
            btnProfil.FlatAppearance.BorderSize = 0;
            btnProfil.FlatStyle = FlatStyle.Flat;
            btnProfil.Image = Properties.Resources.person_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnProfil.Location = new Point(40, 21);
            btnProfil.Name = "btnProfil";
            btnProfil.Size = new Size(64, 38);
            btnProfil.TabIndex = 10;
            btnProfil.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.FromArgb(248, 249, 250);
            btnExit.Cursor = Cursors.Hand;
            btnExit.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnExit.FlatAppearance.BorderSize = 2;
            btnExit.FlatStyle = FlatStyle.Flat;
            btnExit.Font = new Font("Segoe UI Semibold", 9F);
            btnExit.ForeColor = Color.Black;
            btnExit.Image = (Image)resources.GetObject("btnExit.Image");
            btnExit.ImageAlign = ContentAlignment.MiddleLeft;
            btnExit.Location = new Point(19, 375);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(121, 37);
            btnExit.TabIndex = 3;
            btnExit.Text = "Salir ";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // btnTracking
            // 
            btnTracking.BackColor = Color.FromArgb(248, 249, 250);
            btnTracking.Cursor = Cursors.Hand;
            btnTracking.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnTracking.FlatAppearance.BorderSize = 2;
            btnTracking.FlatStyle = FlatStyle.Flat;
            btnTracking.Font = new Font("Segoe UI Semibold", 9F);
            btnTracking.Image = (Image)resources.GetObject("btnTracking.Image");
            btnTracking.ImageAlign = ContentAlignment.MiddleLeft;
            btnTracking.Location = new Point(20, 200);
            btnTracking.Name = "btnTracking";
            btnTracking.Size = new Size(121, 37);
            btnTracking.TabIndex = 2;
            btnTracking.Text = "Asignación";
            btnTracking.UseVisualStyleBackColor = false;
            btnTracking.Click += btnTracking_Click;
            // 
            // btnCrud
            // 
            btnCrud.BackColor = Color.FromArgb(248, 249, 250);
            btnCrud.Cursor = Cursors.Hand;
            btnCrud.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnCrud.FlatAppearance.BorderSize = 2;
            btnCrud.FlatStyle = FlatStyle.Flat;
            btnCrud.Font = new Font("Segoe UI Semibold", 9F);
            btnCrud.Image = (Image)resources.GetObject("btnCrud.Image");
            btnCrud.ImageAlign = ContentAlignment.MiddleLeft;
            btnCrud.Location = new Point(20, 147);
            btnCrud.Name = "btnCrud";
            btnCrud.Size = new Size(121, 37);
            btnCrud.TabIndex = 1;
            btnCrud.Text = "Añadir";
            btnCrud.UseVisualStyleBackColor = false;
            btnCrud.Click += btnCrud_Click;
            // 
            // btnHome
            // 
            btnHome.BackColor = Color.FromArgb(248, 249, 250);
            btnHome.Cursor = Cursors.Hand;
            btnHome.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnHome.FlatAppearance.BorderSize = 2;
            btnHome.FlatStyle = FlatStyle.Flat;
            btnHome.Font = new Font("Segoe UI Semibold", 9F);
            btnHome.ForeColor = Color.Black;
            btnHome.Image = (Image)resources.GetObject("btnHome.Image");
            btnHome.ImageAlign = ContentAlignment.MiddleLeft;
            btnHome.Location = new Point(19, 99);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(121, 37);
            btnHome.TabIndex = 0;
            btnHome.Text = "Inicio";
            btnHome.UseVisualStyleBackColor = false;
            btnHome.Click += btnHome_Click;
            // 
            // panelPrincipal
            // 
            panelPrincipal.Controls.Add(flowLayoutPanel2);
            panelPrincipal.Controls.Add(flowLayoutPanel1);
            panelPrincipal.Controls.Add(panel5);
            panelPrincipal.Controls.Add(label4);
            panelPrincipal.Controls.Add(panel1);
            panelPrincipal.Controls.Add(label5);
            panelPrincipal.Location = new Point(87, 12);
            panelPrincipal.Name = "panelPrincipal";
            panelPrincipal.Size = new Size(1200, 689);
            panelPrincipal.TabIndex = 33;
            panelPrincipal.Paint += panelPrincipal_Paint;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel2.Location = new Point(0, 667);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(1200, 19);
            flowLayoutPanel2.TabIndex = 33;
            // 
            // Tracking
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(1306, 749);
            Controls.Add(panelPrincipal);
            Name = "Tracking";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Rastreo";
            WindowState = FormWindowState.Maximized;
            Load += Tracking_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridAsignacion).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panelPrincipal.ResumeLayout(false);
            panelPrincipal.PerformLayout();
            ResumeLayout(false);
        }



        #endregion
        private Label label4;
        private Label label5;
        private Button btnGuardarAsignacion;
        private TextBox txtnumeroSerie;
        private ComboBox cmbUbicacion;
        private TextBox txtComentarios;
        private Label label7;
        private DataGridView dataGridAsignacion;
        private Panel panel1;
        private FlowLayoutPanel flowLayoutPanel2;
        private FlowLayoutPanel flowLayoutPanel1;
        private PictureBox pictureBox2;
        private Label lblAlerta;
        private TextBox txtNombreEquipo;
        private Panel panel5;
        private Button btnReportes;
        private Label label11;
        private Button btnProfil;
        private Button btnExit;
        private Button btnTracking;
        private Button btnCrud;
        private Button btnHome;
        private Label lblInformacion;
        private Label lblEnter;
        private PictureBox pictureBox1;
        private Panel panelPrincipal;
        private Panel panel3;
        private Label lblDevolucion;
        private Button btnDevoluciones;
        private TextBox txtEncargado;
        private PictureBox pictureBox4;
        private Button btnLimpiar;
    }
}