using System.Drawing.Text;
using System.Drawing;
using System.Windows.Forms;
using FormNobleza.Services;
using System;
using FormNobleza.Models;
namespace FormNobleza
{
    public partial class FormLogin : Form
    {
        //Instancia de autenticación
        private readonly AuthService _authService = new AuthService();
        public FormLogin()
        {
            InitializeComponent();
            CentrarPanel();

            lblError.Visible = false; //Label oculto
            btnContraseña.Image = Properties.Resources.ojo;
            txtContraseña.UseSystemPasswordChar = true;
            btnContraseña.Image = Properties.Resources.ojo;

        }

        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            
            //string usuarioInput = txtUsuario.Text.Trim();
            //string passwordInput = txtContraseña.Text;

            //try
            //{
            //    bool loginExitoso = _authService.ValidarLogin(usuarioInput, passwordInput);

            //    if (loginExitoso)
            //    {
            //        //Login exitoso
            //        UsuarioSesion.IdUsuario = 1;
            //        UsuarioSesion.NombreUsuario = usuarioInput;

                    //lblError.Visible = false;
                    //MessageBox.Show($"¡Bienvenido al sistema, {usuarioInput}!", "Acceso Concedido", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Menu pantallaDashboard = new Menu();
                    pantallaDashboard.FormClosed += (s, args) => this.Close();
                    pantallaDashboard.Show();

                    this.Hide();

            //    }
            //    else
            //    {
            //        // FALLÓ EL LOGIN: Activamos nuestra alerta visual personalizada
            //        lblError.Text = "El usuario o la contraseña son incorrectos.";
            //        lblError.ForeColor = Color.Red; // Pintamos las letras de rojo para alertar
            //        lblError.Visible = true;

            //    }


            //}
            //catch (Exception ex)
            //{

            //    //Error de servicios de Xampp apagados
            //    MessageBox.Show(ex.Message, "Error de Conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);

            //}
        }

        private void error(string mensaje)
        {
            lblError.Text = mensaje;
            lblError.Visible = true;
        }

        private void txtContraseña_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;

                // Simulamos un clic fantasma en el botón de iniciar sesión
                btnIniciarSesion.PerformClick();
            }
        }

        private void txtUsuario_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // Silencia el "Ding" de Windows

                // Ponemos el cursor a parpadear en la caja de la contraseña
                txtContraseña.Focus();
            }
        }


        private void btnOcultar_click(object sender, EventArgs e)
        {
            // Si la contraseña ESTÁ OCULTA (true)...
            if (txtContraseña.UseSystemPasswordChar == true)
            {
                // REVELAR CONTRASEÑA: Apagamos los puntitos
                txtContraseña.UseSystemPasswordChar = false;

                // CAMBIAR EL PNG: Ponemos el icono de "Ojo bloqueado"
                btnContraseña.Image = Properties.Resources.ojobloqueado;
            }
            else
            {
                // Si la contraseña ESTÁ VISIBLE (false)...

                // OCULTAR CONTRASEÑA: Encendemos los puntitos de nuevo
                txtContraseña.UseSystemPasswordChar = true;

                // CAMBIAR EL PNG: Ponemos el icono de "Ojo abierto / Ver"
                btnContraseña.Image = Properties.Resources.ojo;
            }
        }
        private void CentrarPanel()
        {
            // Verificamos que el panel exista y tenga un padre asignado
            if (panelPrincipal != null && panelPrincipal.Parent != null)
            {
                // Calculamos usando el tamaño del PADRE (ya sea el Formulario o panel1)
                int centroX = (panelPrincipal.Parent.ClientSize.Width - panelPrincipal.Width) / 2;
                int centroY = (panelPrincipal.Parent.ClientSize.Height - panelPrincipal.Height) / 2;

                panelPrincipal.Location = new Point(centroX, centroY);
            }
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {
            CentrarPanel();

        }

        private void FormLogin_Resize(object sender, EventArgs e)
        {
            CentrarPanel();

        }
      
    }
}
