﻿namespace FormNobleza
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            label8 = new Label();
            flowLayoutPanel1 = new FlowLayoutPanel();
            flowLayoutPanel2 = new FlowLayoutPanel();
            panel4 = new Panel();
            pictureBox4 = new PictureBox();
            pictureBox1 = new PictureBox();
            txtBuscador = new TextBox();
            pictureBox3 = new PictureBox();
            dgvMenuPrincipal = new DataGridView();
            label9 = new Label();
            flowLayoutPanel4 = new FlowLayoutPanel();
            label10 = new Label();
            panel5 = new Panel();
            btnReportes = new Button();
            label11 = new Label();
            btnProfil = new Button();
            btnExit = new Button();
            btnTracking = new Button();
            btnCrud = new Button();
            btnHome = new Button();
            panelPrincipal = new Panel();
            flowLayoutPanel3 = new FlowLayoutPanel();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvMenuPrincipal).BeginInit();
            panel5.SuspendLayout();
            panelPrincipal.SuspendLayout();
            SuspendLayout();
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Semibold", 18F);
            label8.ForeColor = Color.FromArgb(26, 26, 26);
            label8.Location = new Point(404, 21);
            label8.Name = "label8";
            label8.Size = new Size(206, 32);
            label8.TabIndex = 5;
            label8.Text = "MENÚ PRINCIPAL";
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Location = new Point(34, 52);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(0, 0);
            flowLayoutPanel1.TabIndex = 6;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.Location = new Point(0, 0);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(0, 0);
            flowLayoutPanel2.TabIndex = 7;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(248, 249, 250);
            panel4.Controls.Add(pictureBox4);
            panel4.Controls.Add(pictureBox1);
            panel4.Controls.Add(txtBuscador);
            panel4.Controls.Add(pictureBox3);
            panel4.Controls.Add(dgvMenuPrincipal);
            panel4.Controls.Add(label8);
            panel4.Location = new Point(182, 18);
            panel4.Name = "panel4";
            panel4.Size = new Size(1018, 662);
            panel4.TabIndex = 8;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(921, 0);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(84, 69);
            pictureBox4.TabIndex = 33;
            pictureBox4.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.Window;
            pictureBox1.BackgroundImage = Properties.Resources.search_24dp_00738A_FILL0_wght400_GRAD0_opsz24;
            pictureBox1.Location = new Point(409, 138);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(23, 22);
            pictureBox1.TabIndex = 32;
            pictureBox1.TabStop = false;
            // 
            // txtBuscador
            // 
            txtBuscador.BorderStyle = BorderStyle.None;
            txtBuscador.Cursor = Cursors.IBeam;
            txtBuscador.Font = new Font("Segoe UI Semibold", 12F);
            txtBuscador.Location = new Point(65, 138);
            txtBuscador.Name = "txtBuscador";
            txtBuscador.PlaceholderText = "Ingrese Nombre/Numero de Serie/Nave/Modelo";
            txtBuscador.Size = new Size(367, 22);
            txtBuscador.TabIndex = 15;
            txtBuscador.TextChanged += txtBuscador_TextChanged;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.Excel2__1_1;
            pictureBox3.Location = new Point(0, 0);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(178, 81);
            pictureBox3.TabIndex = 14;
            pictureBox3.TabStop = false;
            // 
            // dgvMenuPrincipal
            // 
            dgvMenuPrincipal.BackgroundColor = Color.FromArgb(235, 241, 246);
            dgvMenuPrincipal.BorderStyle = BorderStyle.None;
            dgvMenuPrincipal.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvMenuPrincipal.Location = new Point(3, 180);
            dgvMenuPrincipal.Name = "dgvMenuPrincipal";
            dgvMenuPrincipal.Size = new Size(1006, 433);
            dgvMenuPrincipal.TabIndex = 13;
            dgvMenuPrincipal.CellContentClick += dgvMenuPrincipal_CellContentClick;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(95, 315);
            label9.Name = "label9";
            label9.Size = new Size(0, 15);
            label9.TabIndex = 24;
            // 
            // flowLayoutPanel4
            // 
            flowLayoutPanel4.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel4.Location = new Point(3, 3);
            flowLayoutPanel4.Name = "flowLayoutPanel4";
            flowLayoutPanel4.Size = new Size(1200, 19);
            flowLayoutPanel4.TabIndex = 26;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(61, 317);
            label10.Name = "label10";
            label10.Size = new Size(0, 15);
            label10.TabIndex = 25;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(248, 249, 250);
            panel5.Controls.Add(btnReportes);
            panel5.Controls.Add(label11);
            panel5.Controls.Add(btnProfil);
            panel5.Controls.Add(btnExit);
            panel5.Controls.Add(btnTracking);
            panel5.Controls.Add(btnCrud);
            panel5.Controls.Add(btnHome);
            panel5.Location = new Point(0, 18);
            panel5.Name = "panel5";
            panel5.Size = new Size(176, 662);
            panel5.TabIndex = 32;
            // 
            // btnReportes
            // 
            btnReportes.BackColor = Color.FromArgb(248, 249, 250);
            btnReportes.Cursor = Cursors.Hand;
            btnReportes.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnReportes.FlatAppearance.BorderSize = 2;
            btnReportes.FlatStyle = FlatStyle.Flat;
            btnReportes.Font = new Font("Segoe UI Semibold", 9F);
            btnReportes.ForeColor = Color.Black;
            btnReportes.Image = (Image)resources.GetObject("btnReportes.Image");
            btnReportes.ImageAlign = ContentAlignment.MiddleLeft;
            btnReportes.Location = new Point(19, 253);
            btnReportes.Name = "btnReportes";
            btnReportes.Size = new Size(121, 37);
            btnReportes.TabIndex = 12;
            btnReportes.Text = "Reportes";
            btnReportes.UseVisualStyleBackColor = false;
            btnReportes.Click += btnReportes_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(19, 62);
            label11.Name = "label11";
            label11.Size = new Size(111, 15);
            label11.TabIndex = 6;
            label11.Text = "¡HOLA, INGENIERO!";
            // 
            // btnProfil
            // 
            btnProfil.Cursor = Cursors.Hand;
            btnProfil.FlatAppearance.BorderSize = 0;
            btnProfil.FlatStyle = FlatStyle.Flat;
            btnProfil.Image = Properties.Resources.person_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnProfil.Location = new Point(40, 21);
            btnProfil.Name = "btnProfil";
            btnProfil.Size = new Size(64, 38);
            btnProfil.TabIndex = 10;
            btnProfil.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.FromArgb(248, 249, 250);
            btnExit.Cursor = Cursors.Hand;
            btnExit.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnExit.FlatAppearance.BorderSize = 2;
            btnExit.FlatStyle = FlatStyle.Flat;
            btnExit.Font = new Font("Segoe UI Semibold", 9F);
            btnExit.ForeColor = Color.Black;
            btnExit.Image = (Image)resources.GetObject("btnExit.Image");
            btnExit.ImageAlign = ContentAlignment.MiddleLeft;
            btnExit.Location = new Point(19, 375);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(121, 37);
            btnExit.TabIndex = 3;
            btnExit.Text = "Salir ";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // btnTracking
            // 
            btnTracking.BackColor = Color.FromArgb(248, 249, 250);
            btnTracking.Cursor = Cursors.Hand;
            btnTracking.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnTracking.FlatAppearance.BorderSize = 2;
            btnTracking.FlatStyle = FlatStyle.Flat;
            btnTracking.Font = new Font("Segoe UI Semibold", 9F);
            btnTracking.Image = (Image)resources.GetObject("btnTracking.Image");
            btnTracking.ImageAlign = ContentAlignment.MiddleLeft;
            btnTracking.Location = new Point(20, 200);
            btnTracking.Name = "btnTracking";
            btnTracking.Size = new Size(121, 37);
            btnTracking.TabIndex = 2;
            btnTracking.Text = "Asignacion";
            btnTracking.UseVisualStyleBackColor = false;
            btnTracking.Click += btnTracking_Click;
            // 
            // btnCrud
            // 
            btnCrud.BackColor = Color.FromArgb(248, 249, 250);
            btnCrud.Cursor = Cursors.Hand;
            btnCrud.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnCrud.FlatAppearance.BorderSize = 2;
            btnCrud.FlatStyle = FlatStyle.Flat;
            btnCrud.Font = new Font("Segoe UI Semibold", 9F);
            btnCrud.Image = (Image)resources.GetObject("btnCrud.Image");
            btnCrud.ImageAlign = ContentAlignment.MiddleLeft;
            btnCrud.Location = new Point(20, 147);
            btnCrud.Name = "btnCrud";
            btnCrud.Size = new Size(121, 37);
            btnCrud.TabIndex = 1;
            btnCrud.Text = "Añadir";
            btnCrud.UseVisualStyleBackColor = false;
            btnCrud.Click += btnCrud_Click;
            // 
            // btnHome
            // 
            btnHome.BackColor = Color.FromArgb(248, 249, 250);
            btnHome.Cursor = Cursors.Hand;
            btnHome.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnHome.FlatAppearance.BorderSize = 2;
            btnHome.FlatStyle = FlatStyle.Flat;
            btnHome.Font = new Font("Segoe UI Semibold", 9F);
            btnHome.ForeColor = Color.Black;
            btnHome.Image = (Image)resources.GetObject("btnHome.Image");
            btnHome.ImageAlign = ContentAlignment.MiddleLeft;
            btnHome.Location = new Point(19, 99);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(121, 37);
            btnHome.TabIndex = 0;
            btnHome.Text = "Inicio";
            btnHome.UseVisualStyleBackColor = false;
            btnHome.Click += btnHome_Click;
            // 
            // panelPrincipal
            // 
            panelPrincipal.Controls.Add(flowLayoutPanel4);
            panelPrincipal.Controls.Add(flowLayoutPanel3);
            panelPrincipal.Controls.Add(panel5);
            panelPrincipal.Controls.Add(flowLayoutPanel1);
            panelPrincipal.Controls.Add(panel4);
            panelPrincipal.Controls.Add(label9);
            panelPrincipal.Controls.Add(label10);
            panelPrincipal.Location = new Point(50, 12);
            panelPrincipal.Name = "panelPrincipal";
            panelPrincipal.Size = new Size(1200, 700);
            panelPrincipal.TabIndex = 33;
            // 
            // flowLayoutPanel3
            // 
            flowLayoutPanel3.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel3.Location = new Point(0, 681);
            flowLayoutPanel3.Name = "flowLayoutPanel3";
            flowLayoutPanel3.Size = new Size(1203, 19);
            flowLayoutPanel3.TabIndex = 33;
            // 
            // Menu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1289, 724);
            Controls.Add(panelPrincipal);
            Controls.Add(flowLayoutPanel2);
            Name = "Menu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MenuPrincipal";
            WindowState = FormWindowState.Maximized;
            Load += Menu_Load;
            Resize += Menu_Resize;
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvMenuPrincipal).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panelPrincipal.ResumeLayout(false);
            panelPrincipal.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Label label8;
        private FlowLayoutPanel flowLayoutPanel1;
        private FlowLayoutPanel flowLayoutPanel2;
        private Panel panel4;
        private Label label9;
        private FlowLayoutPanel flowLayoutPanel3;
        private FlowLayoutPanel flowLayoutPanel4;
        private Label label10;
        private DataGridView dgvMenuPrincipal;
        private PictureBox pictureBox3;
        private TextBox txtBuscador;
        private Panel panel5;
        private Button btnReportes;
        private Label label11;
        private Button btnProfil;
        private Button btnExit;
        private Button btnTracking;
        private Button btnCrud;
        private Button btnHome;
        private Label lblAlertaId;
        private PictureBox pictureBox1;
        private Panel panelPrincipal;
        private PictureBox pictureBox4;
    }
}