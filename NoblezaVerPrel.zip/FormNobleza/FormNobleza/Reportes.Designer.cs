﻿namespace FormNobleza
{
    partial class Reportes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Reportes));
            flowLayoutPanel1 = new FlowLayoutPanel();
            btnPDF = new Button();
            cmbFecha = new ComboBox();
            label2 = new Label();
            btnGenerarPdf = new Button();
            txtId = new TextBox();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            panel5 = new Panel();
            btnReportes = new Button();
            label11 = new Label();
            btnProfil = new Button();
            btnExit = new Button();
            btnTracking = new Button();
            btnCrud = new Button();
            btnHome = new Button();
            panel4 = new Panel();
            pictureBox4 = new PictureBox();
            button1 = new Button();
            btnResponsiva = new Button();
            pictureBox2 = new PictureBox();
            lblEnter = new Label();
            lblAlerta = new Label();
            btnPDFS = new Button();
            txtSerie = new TextBox();
            pictureBox3 = new PictureBox();
            ReportesGrid = new DataGridView();
            label8 = new Label();
            panelPrincipal = new Panel();
            flowLayoutPanel2 = new FlowLayoutPanel();
            flowLayoutPanel3 = new FlowLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel5.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ReportesGrid).BeginInit();
            panelPrincipal.SuspendLayout();
            SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel1.Location = new Point(36, -22);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(911, 19);
            flowLayoutPanel1.TabIndex = 32;
            // 
            // btnPDF
            // 
            btnPDF.BackColor = Color.FromArgb(0, 115, 138);
            btnPDF.Cursor = Cursors.Hand;
            btnPDF.Enabled = false;
            btnPDF.FlatAppearance.BorderSize = 0;
            btnPDF.FlatStyle = FlatStyle.Flat;
            btnPDF.Font = new Font("Segoe UI Semibold", 12F);
            btnPDF.ForeColor = Color.FromArgb(248, 249, 250);
            btnPDF.Location = new Point(488, 365);
            btnPDF.Name = "btnPDF";
            btnPDF.Size = new Size(209, 29);
            btnPDF.TabIndex = 25;
            btnPDF.Text = "Guardar";
            btnPDF.UseVisualStyleBackColor = false;
            // 
            // cmbFecha
            // 
            cmbFecha.Cursor = Cursors.Hand;
            cmbFecha.Enabled = false;
            cmbFecha.FlatStyle = FlatStyle.Flat;
            cmbFecha.Font = new Font("Segoe UI Semibold", 12F);
            cmbFecha.FormattingEnabled = true;
            cmbFecha.Items.AddRange(new object[] { "Mensual ", "Anual ", "General" });
            cmbFecha.Location = new Point(153, 190);
            cmbFecha.Name = "cmbFecha";
            cmbFecha.Size = new Size(172, 29);
            cmbFecha.TabIndex = 22;
            cmbFecha.Text = "Fecha de Reporte";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.DarkGreen;
            label2.Location = new Point(153, 159);
            label2.Name = "label2";
            label2.Size = new Size(171, 15);
            label2.TabIndex = 21;
            label2.Text = "Este dispositivo está registrado!";
            // 
            // btnGenerarPdf
            // 
            btnGenerarPdf.Location = new Point(0, 0);
            btnGenerarPdf.Name = "btnGenerarPdf";
            btnGenerarPdf.Size = new Size(75, 23);
            btnGenerarPdf.TabIndex = 24;
            // 
            // txtId
            // 
            txtId.BorderStyle = BorderStyle.None;
            txtId.Cursor = Cursors.IBeam;
            txtId.Font = new Font("Segoe UI Semibold", 12F);
            txtId.Location = new Point(153, 122);
            txtId.Name = "txtId";
            txtId.PlaceholderText = "Id:";
            txtId.Size = new Size(172, 22);
            txtId.TabIndex = 19;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 18F);
            label1.ImageAlign = ContentAlignment.BottomRight;
            label1.Location = new Point(356, 21);
            label1.Name = "label1";
            label1.Size = new Size(125, 32);
            label1.TabIndex = 4;
            label1.Text = "REPORTES";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Excel2__1_1;
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(178, 81);
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(248, 249, 250);
            panel5.Controls.Add(btnReportes);
            panel5.Controls.Add(label11);
            panel5.Controls.Add(btnProfil);
            panel5.Controls.Add(btnExit);
            panel5.Controls.Add(btnTracking);
            panel5.Controls.Add(btnCrud);
            panel5.Controls.Add(btnHome);
            panel5.Location = new Point(0, 19);
            panel5.Name = "panel5";
            panel5.Size = new Size(170, 653);
            panel5.TabIndex = 35;
            // 
            // btnReportes
            // 
            btnReportes.BackColor = Color.FromArgb(248, 249, 250);
            btnReportes.Cursor = Cursors.Hand;
            btnReportes.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnReportes.FlatAppearance.BorderSize = 2;
            btnReportes.FlatStyle = FlatStyle.Flat;
            btnReportes.Font = new Font("Segoe UI Semibold", 9F);
            btnReportes.ForeColor = Color.Black;
            btnReportes.Image = (Image)resources.GetObject("btnReportes.Image");
            btnReportes.ImageAlign = ContentAlignment.MiddleLeft;
            btnReportes.Location = new Point(19, 253);
            btnReportes.Name = "btnReportes";
            btnReportes.Size = new Size(121, 37);
            btnReportes.TabIndex = 12;
            btnReportes.Text = "Reportes";
            btnReportes.UseVisualStyleBackColor = false;
            btnReportes.Click += btnReportes_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(19, 62);
            label11.Name = "label11";
            label11.Size = new Size(111, 15);
            label11.TabIndex = 6;
            label11.Text = "¡HOLA, INGENIERO!";
            // 
            // btnProfil
            // 
            btnProfil.Cursor = Cursors.Hand;
            btnProfil.FlatAppearance.BorderSize = 0;
            btnProfil.FlatStyle = FlatStyle.Flat;
            btnProfil.Image = Properties.Resources.person_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnProfil.Location = new Point(40, 21);
            btnProfil.Name = "btnProfil";
            btnProfil.Size = new Size(64, 38);
            btnProfil.TabIndex = 10;
            btnProfil.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.FromArgb(248, 249, 250);
            btnExit.Cursor = Cursors.Hand;
            btnExit.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnExit.FlatAppearance.BorderSize = 2;
            btnExit.FlatStyle = FlatStyle.Flat;
            btnExit.Font = new Font("Segoe UI Semibold", 9F);
            btnExit.ForeColor = Color.Black;
            btnExit.Image = (Image)resources.GetObject("btnExit.Image");
            btnExit.ImageAlign = ContentAlignment.MiddleLeft;
            btnExit.Location = new Point(19, 375);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(121, 37);
            btnExit.TabIndex = 3;
            btnExit.Text = "Salir ";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // btnTracking
            // 
            btnTracking.BackColor = Color.FromArgb(248, 249, 250);
            btnTracking.Cursor = Cursors.Hand;
            btnTracking.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnTracking.FlatAppearance.BorderSize = 2;
            btnTracking.FlatStyle = FlatStyle.Flat;
            btnTracking.Font = new Font("Segoe UI Semibold", 9F);
            btnTracking.Image = (Image)resources.GetObject("btnTracking.Image");
            btnTracking.ImageAlign = ContentAlignment.MiddleLeft;
            btnTracking.Location = new Point(20, 200);
            btnTracking.Name = "btnTracking";
            btnTracking.Size = new Size(121, 37);
            btnTracking.TabIndex = 2;
            btnTracking.Text = "Asignación";
            btnTracking.UseVisualStyleBackColor = false;
            btnTracking.Click += btnTracking_Click;
            // 
            // btnCrud
            // 
            btnCrud.BackColor = Color.FromArgb(248, 249, 250);
            btnCrud.Cursor = Cursors.Hand;
            btnCrud.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnCrud.FlatAppearance.BorderSize = 2;
            btnCrud.FlatStyle = FlatStyle.Flat;
            btnCrud.Font = new Font("Segoe UI Semibold", 9F);
            btnCrud.Image = (Image)resources.GetObject("btnCrud.Image");
            btnCrud.ImageAlign = ContentAlignment.MiddleLeft;
            btnCrud.Location = new Point(20, 147);
            btnCrud.Name = "btnCrud";
            btnCrud.Size = new Size(121, 37);
            btnCrud.TabIndex = 1;
            btnCrud.Text = "Añadir";
            btnCrud.UseVisualStyleBackColor = false;
            btnCrud.Click += btnCrud_Click;
            // 
            // btnHome
            // 
            btnHome.BackColor = Color.FromArgb(248, 249, 250);
            btnHome.Cursor = Cursors.Hand;
            btnHome.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnHome.FlatAppearance.BorderSize = 2;
            btnHome.FlatStyle = FlatStyle.Flat;
            btnHome.Font = new Font("Segoe UI Semibold", 9F);
            btnHome.ForeColor = Color.Black;
            btnHome.Image = (Image)resources.GetObject("btnHome.Image");
            btnHome.ImageAlign = ContentAlignment.MiddleLeft;
            btnHome.Location = new Point(19, 99);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(121, 37);
            btnHome.TabIndex = 0;
            btnHome.Text = "Inicio";
            btnHome.UseVisualStyleBackColor = false;
            btnHome.Click += btnHome_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(248, 249, 250);
            panel4.Controls.Add(pictureBox4);
            panel4.Controls.Add(button1);
            panel4.Controls.Add(btnResponsiva);
            panel4.Controls.Add(pictureBox2);
            panel4.Controls.Add(lblEnter);
            panel4.Controls.Add(lblAlerta);
            panel4.Controls.Add(btnPDFS);
            panel4.Controls.Add(txtSerie);
            panel4.Controls.Add(pictureBox3);
            panel4.Controls.Add(ReportesGrid);
            panel4.Controls.Add(label8);
            panel4.Location = new Point(173, 19);
            panel4.Name = "panel4";
            panel4.Size = new Size(1027, 653);
            panel4.TabIndex = 37;
            panel4.Paint += panel4_Paint_1;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(919, 0);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(84, 69);
            pictureBox4.TabIndex = 36;
            pictureBox4.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(0, 115, 138);
            button1.Cursor = Cursors.Hand;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI Semibold", 12F);
            button1.ForeColor = Color.FromArgb(248, 249, 250);
            button1.Image = Properties.Resources.download_24dp_FFFFFF_FILL0_wght400_GRAD0_opsz24;
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.Location = new Point(645, 512);
            button1.Name = "button1";
            button1.Size = new Size(144, 40);
            button1.TabIndex = 35;
            button1.Text = "Cambio";
            button1.UseVisualStyleBackColor = false;
            // 
            // btnResponsiva
            // 
            btnResponsiva.BackColor = Color.FromArgb(0, 115, 138);
            btnResponsiva.Cursor = Cursors.Hand;
            btnResponsiva.FlatAppearance.BorderSize = 0;
            btnResponsiva.FlatStyle = FlatStyle.Flat;
            btnResponsiva.Font = new Font("Segoe UI Semibold", 12F);
            btnResponsiva.ForeColor = Color.FromArgb(248, 249, 250);
            btnResponsiva.Image = (Image)resources.GetObject("btnResponsiva.Image");
            btnResponsiva.ImageAlign = ContentAlignment.MiddleLeft;
            btnResponsiva.Location = new Point(447, 512);
            btnResponsiva.Name = "btnResponsiva";
            btnResponsiva.Size = new Size(144, 40);
            btnResponsiva.TabIndex = 34;
            btnResponsiva.Text = "Responsiva";
            btnResponsiva.UseVisualStyleBackColor = false;
            btnResponsiva.Click += btnResponsiva_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = SystemColors.Window;
            pictureBox2.BackgroundImage = Properties.Resources.search_24dp_00738A_FILL0_wght400_GRAD0_opsz24;
            pictureBox2.Location = new Point(304, 99);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(23, 22);
            pictureBox2.TabIndex = 33;
            pictureBox2.TabStop = false;
            // 
            // lblEnter
            // 
            lblEnter.AutoSize = true;
            lblEnter.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblEnter.ForeColor = Color.FromArgb(0, 115, 138);
            lblEnter.Location = new Point(174, 124);
            lblEnter.Name = "lblEnter";
            lblEnter.Size = new Size(101, 17);
            lblEnter.TabIndex = 22;
            lblEnter.Text = "Presione ENTER";
            lblEnter.TextAlign = ContentAlignment.TopCenter;
            // 
            // lblAlerta
            // 
            lblAlerta.AutoSize = true;
            lblAlerta.ForeColor = Color.FromArgb(255, 128, 128);
            lblAlerta.Location = new Point(108, 152);
            lblAlerta.Name = "lblAlerta";
            lblAlerta.Size = new Size(0, 15);
            lblAlerta.TabIndex = 19;
            // 
            // btnPDFS
            // 
            btnPDFS.BackColor = Color.FromArgb(0, 115, 138);
            btnPDFS.Cursor = Cursors.Hand;
            btnPDFS.FlatAppearance.BorderSize = 0;
            btnPDFS.FlatStyle = FlatStyle.Flat;
            btnPDFS.Font = new Font("Segoe UI Semibold", 12F);
            btnPDFS.ForeColor = Color.FromArgb(248, 249, 250);
            btnPDFS.Image = Properties.Resources.download_24dp_FFFFFF_FILL0_wght400_GRAD0_opsz24;
            btnPDFS.ImageAlign = ContentAlignment.MiddleLeft;
            btnPDFS.Location = new Point(264, 512);
            btnPDFS.Name = "btnPDFS";
            btnPDFS.Size = new Size(144, 40);
            btnPDFS.TabIndex = 18;
            btnPDFS.Text = "Historial";
            btnPDFS.UseVisualStyleBackColor = false;
            btnPDFS.Click += btnPDFS_Click;
            // 
            // txtSerie
            // 
            txtSerie.BorderStyle = BorderStyle.None;
            txtSerie.Cursor = Cursors.IBeam;
            txtSerie.Font = new Font("Segoe UI Semibold", 12F);
            txtSerie.Location = new Point(158, 99);
            txtSerie.Name = "txtSerie";
            txtSerie.PlaceholderText = "Numero de Serie:";
            txtSerie.Size = new Size(169, 22);
            txtSerie.TabIndex = 15;
            txtSerie.TextChanged += txtSerie_TextChanged;
            txtSerie.KeyDown += txtSerie_KeyDown;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.Excel2__1_1;
            pictureBox3.Location = new Point(0, 0);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(178, 81);
            pictureBox3.TabIndex = 14;
            pictureBox3.TabStop = false;
            // 
            // ReportesGrid
            // 
            ReportesGrid.BackgroundColor = Color.FromArgb(235, 241, 246);
            ReportesGrid.BorderStyle = BorderStyle.None;
            ReportesGrid.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            ReportesGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            ReportesGrid.Location = new Point(80, 170);
            ReportesGrid.Name = "ReportesGrid";
            ReportesGrid.SelectionMode = DataGridViewSelectionMode.CellSelect;
            ReportesGrid.Size = new Size(839, 291);
            ReportesGrid.TabIndex = 13;
            ReportesGrid.CellContentClick += ReportesGrid_CellContentClick;
            ReportesGrid.Paint += ReportesGrid_Paint;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Semibold", 18F);
            label8.ForeColor = Color.FromArgb(26, 26, 26);
            label8.Location = new Point(466, 27);
            label8.Name = "label8";
            label8.Size = new Size(125, 32);
            label8.TabIndex = 5;
            label8.Text = "REPORTES";
            // 
            // panelPrincipal
            // 
            panelPrincipal.Controls.Add(flowLayoutPanel3);
            panelPrincipal.Controls.Add(flowLayoutPanel2);
            panelPrincipal.Controls.Add(panel5);
            panelPrincipal.Controls.Add(panel4);
            panelPrincipal.Controls.Add(flowLayoutPanel1);
            panelPrincipal.Location = new Point(44, 12);
            panelPrincipal.Name = "panelPrincipal";
            panelPrincipal.Size = new Size(1200, 689);
            panelPrincipal.TabIndex = 38;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel2.Location = new Point(0, 3);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(1203, 19);
            flowLayoutPanel2.TabIndex = 38;
            // 
            // flowLayoutPanel3
            // 
            flowLayoutPanel3.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel3.Location = new Point(0, 670);
            flowLayoutPanel3.Name = "flowLayoutPanel3";
            flowLayoutPanel3.Size = new Size(1200, 19);
            flowLayoutPanel3.TabIndex = 39;
            // 
            // Reportes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1247, 732);
            Controls.Add(panelPrincipal);
            Name = "Reportes";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Reportes";
            WindowState = FormWindowState.Maximized;
            Load += Reportes_Load;
            Resize += Reportes_Resize;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)ReportesGrid).EndInit();
            panelPrincipal.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private FlowLayoutPanel flowLayoutPanel3;
        private FlowLayoutPanel flowLayoutPanel1;
        private Label label1;
        private PictureBox pictureBox1;
        private TextBox txtId;
        private Button btnGenerarPdf;
        private Label label2;
        private ComboBox cmbFecha;
        private Panel panel5;
        private Button btnReportes;
        private Label label11;
        private Button btnProfil;
        private Button btnExit;
        private Button btnTracking;
        private Button btnCrud;
        private Button btnHome;
        private DataGridView ReportesGridGridReportes;
        private Button btnPDF;
        private Panel panel4;
        private TextBox txtSerie;
        private Button btnBusqueda;
        private PictureBox pictureBox3;
        private DataGridView ReportesGrid;
        private Label label8;
        private Button btnPDFS;
        private Label lblAlerta;
        private Label lblEnter;
        private PictureBox pictureBox2;
        private Panel panelPrincipal;
        private FlowLayoutPanel flowLayoutPanel2;
        private Button btnResponsiva;
        private Button button1;
        private PictureBox pictureBox4;
    }
}