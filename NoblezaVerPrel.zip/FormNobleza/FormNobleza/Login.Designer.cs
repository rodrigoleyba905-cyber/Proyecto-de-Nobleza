﻿namespace FormNobleza
{
    partial class FormLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormLogin));
            panel3 = new Panel();
            txtContraseña = new TextBox();
            txtUsuario = new TextBox();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            panel1 = new Panel();
            pictureBox4 = new PictureBox();
            label3 = new Label();
            pictureBox3 = new PictureBox();
            btnContraseña = new Button();
            pictureBox2 = new PictureBox();
            btnIniciarSesion = new Button();
            lblError = new Label();
            panelPrincipal = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panelPrincipal.SuspendLayout();
            SuspendLayout();
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(0, 115, 138);
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(303, 700);
            panel3.TabIndex = 8;
            // 
            // txtContraseña
            // 
            txtContraseña.BorderStyle = BorderStyle.None;
            txtContraseña.Cursor = Cursors.IBeam;
            txtContraseña.Font = new Font("Segoe UI Semibold", 12F);
            txtContraseña.Location = new Point(321, 322);
            txtContraseña.Name = "txtContraseña";
            txtContraseña.PlaceholderText = "Contraseña:";
            txtContraseña.Size = new Size(200, 22);
            txtContraseña.TabIndex = 2;
            txtContraseña.KeyDown += txtContraseña_KeyDown;
            // 
            // txtUsuario
            // 
            txtUsuario.BackColor = SystemColors.Window;
            txtUsuario.BorderStyle = BorderStyle.None;
            txtUsuario.Cursor = Cursors.IBeam;
            txtUsuario.Font = new Font("Segoe UI Semibold", 12F);
            txtUsuario.Location = new Point(321, 274);
            txtUsuario.Name = "txtUsuario";
            txtUsuario.PlaceholderText = "Usuario:";
            txtUsuario.Size = new Size(200, 22);
            txtUsuario.TabIndex = 1;
            txtUsuario.KeyDown += txtUsuario_KeyDown;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Excel2__1_1;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(178, 81);
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(321, 358);
            label2.Name = "label2";
            label2.Size = new Size(0, 15);
            label2.TabIndex = 10;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(248, 249, 250);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(btnContraseña);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(btnIniciarSesion);
            panel1.Controls.Add(lblError);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(txtUsuario);
            panel1.Controls.Add(txtContraseña);
            panel1.Location = new Point(302, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(854, 700);
            panel1.TabIndex = 8;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(708, 0);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(84, 69);
            pictureBox4.TabIndex = 22;
            pictureBox4.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 18F);
            label3.Location = new Point(399, 78);
            label3.Name = "label3";
            label3.Size = new Size(210, 32);
            label3.TabIndex = 21;
            label3.Text = "INICIO DE SESIÓN";
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = SystemColors.Window;
            pictureBox3.BackgroundImage = (Image)resources.GetObject("pictureBox3.BackgroundImage");
            pictureBox3.Location = new Point(292, 322);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(23, 22);
            pictureBox3.TabIndex = 20;
            pictureBox3.TabStop = false;
            // 
            // btnContraseña
            // 
            btnContraseña.BackColor = SystemColors.Window;
            btnContraseña.FlatAppearance.BorderSize = 0;
            btnContraseña.FlatStyle = FlatStyle.Flat;
            btnContraseña.Location = new Point(498, 323);
            btnContraseña.Name = "btnContraseña";
            btnContraseña.Size = new Size(23, 22);
            btnContraseña.TabIndex = 19;
            btnContraseña.UseVisualStyleBackColor = false;
            btnContraseña.Click += btnOcultar_click;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = SystemColors.Window;
            pictureBox2.BackgroundImage = Properties.Resources.account_circle_24dp_00738A_FILL0_wght400_GRAD0_opsz24;
            pictureBox2.Location = new Point(292, 274);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(23, 22);
            pictureBox2.TabIndex = 18;
            pictureBox2.TabStop = false;
            // 
            // btnIniciarSesion
            // 
            btnIniciarSesion.BackColor = Color.FromArgb(0, 115, 138);
            btnIniciarSesion.Cursor = Cursors.Hand;
            btnIniciarSesion.FlatAppearance.BorderSize = 0;
            btnIniciarSesion.FlatStyle = FlatStyle.Flat;
            btnIniciarSesion.Font = new Font("Segoe UI Semibold", 12F);
            btnIniciarSesion.ForeColor = Color.FromArgb(248, 249, 250);
            btnIniciarSesion.Location = new Point(321, 376);
            btnIniciarSesion.Name = "btnIniciarSesion";
            btnIniciarSesion.Size = new Size(200, 30);
            btnIniciarSesion.TabIndex = 3;
            btnIniciarSesion.Text = "Iniciar Sesion";
            btnIniciarSesion.UseVisualStyleBackColor = false;
            btnIniciarSesion.Click += btnIniciarSesion_Click;
            // 
            // lblError
            // 
            lblError.AutoSize = true;
            lblError.ForeColor = Color.FromArgb(255, 128, 128);
            lblError.Location = new Point(321, 358);
            lblError.Name = "lblError";
            lblError.Size = new Size(119, 15);
            lblError.TabIndex = 16;
            lblError.Text = "Error de credenciales!";
            // 
            // panelPrincipal
            // 
            panelPrincipal.Anchor = AnchorStyles.None;
            panelPrincipal.Controls.Add(panel1);
            panelPrincipal.Controls.Add(panel3);
            panelPrincipal.Location = new Point(43, 23);
            panelPrincipal.Name = "panelPrincipal";
            panelPrincipal.Size = new Size(1113, 700);
            panelPrincipal.TabIndex = 9;
            // 
            // FormLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(1184, 749);
            Controls.Add(panelPrincipal);
            Name = "FormLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form Login";
            WindowState = FormWindowState.Maximized;
            Load += FormLogin_Load;
            Resize += FormLogin_Resize;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panelPrincipal.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Panel panel3;
        private TextBox txtContraseña;
        private TextBox txtUsuario;
        private Button btnSesion;
        private PictureBox pictureBox1;
        private Label label2;
        private Panel panel1;
        private Button btnIniciarSesion;
        private PictureBox pictureBox2;
        private Button btnContraseña;
        private Label lblError;
        private PictureBox pictureBox3;
        private Panel panelPrincipal;
        private Label label3;
        private PictureBox pictureBox4;
    }
}
