﻿using FormNobleza.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FormNobleza.Models;
using FormNobleza.Data;
using FormNobleza.Data;

namespace FormNobleza
{
    public partial class Tracking : Form
    {
        private bool _busquedaSinResultados = false;
        private bool _equipoLibre = false;

        public Tracking()
        {
            InitializeComponent();
            CentrarPanel();
            ConfigurarInterfazInicial();
            RefrescarGridTracking();
            AplicarEstiloCorporativoGrid();


        }
        private void CentrarPanel()
        {
            // Verificamos que el panel exista y tenga un padre asignado
            if (panelPrincipal != null && panelPrincipal.Parent != null)
            {
                // Calculamos usando el tamaño del PADRE (ya sea el Formulario o panel1)
                int centroX = (panelPrincipal.Parent.ClientSize.Width - panelPrincipal.Width) / 2;
                int centroY = (panelPrincipal.Parent.ClientSize.Height - panelPrincipal.Height) / 2;

                panelPrincipal.Location = new Point(centroX, centroY);
            }
        }



        //  Variable para saber si el botón guardar hará un INSERT nuevo o una REASIGNACIÓN
        private bool _esReasignacion = false;
        private readonly TrackingRepository _trackingRepository = new TrackingRepository();
        private readonly HardwareRepository _hardwareRepository = new HardwareRepository();
        /// <summary>
        /// Bloquea todos los controles de captura y oculta elementos dinámicos.
        /// Se llama al abrir el formulario y después de cada guardado exitoso.
        /// </summary>
        private void ConfigurarInterfazInicial()
        {
            txtNombreEquipo.Enabled = false;
            txtEncargado.Enabled = false;
            cmbUbicacion.Enabled = false;
            txtComentarios.Enabled = false;

            btnDevoluciones.Enabled = false;
            btnGuardarAsignacion.Enabled = false;
            btnGuardarAsignacion.Visible = true;
            btnGuardarAsignacion.Text = "Guardar";

            cmbUbicacion.SelectedIndex = -1;
            txtNombreEquipo.Clear();
            txtEncargado.Clear();
            txtComentarios.Clear();

            lblAlerta.Text = "";
            lblAlerta.Visible = false;

            lblDevolucion.Visible = false;

            lblInformacion.Visible = true;
            lblEnter.Visible = true;


            _esReasignacion = false;
            txtnumeroSerie.Focus();
        }
        private void LimpiarTextBoxAsignaciones()
        {
            txtNombreEquipo.Clear();
            txtEncargado.Clear();
            txtComentarios.Clear();

            cmbUbicacion.SelectedIndex = -1;
        }



        private void BuscarEquipo()
        {
            string serie = txtnumeroSerie.Text.Trim();

            if (string.IsNullOrWhiteSpace(serie)) return;

            // Reset visual general antes de cualquier validación
            lblInformacion.Visible = true;
            btnDevoluciones.Visible = false;
            btnGuardarAsignacion.Enabled = false;
            DeshabilitarCampos();
            txtnumeroSerie.Enabled = false;


            try
            {
                // 1. ¿Existe el número de serie en el inventario?
                bool existe = _hardwareRepository.ExisteNumeroSerie(serie);
                if (!existe)
                {
                    txtnumeroSerie.Enabled = true;
                    lblEnter.Text = "Número de serie inexistente";
                    lblEnter.ForeColor = Color.Red;
                    DeshabilitarCampos();
                    LimpiarTextBoxAsignaciones();

                    // --- BANDERAS: CASO INEXISTENTE ---
                    _busquedaSinResultados = true;
                    _equipoLibre = false;

                    // Limpiamos el grid dejándolo en null para forzar el evento Paint
                    dataGridAsignacion.DataSource = null;
                    dataGridAsignacion.Rows.Clear();
                    dataGridAsignacion.ColumnHeadersVisible = false;
                    dataGridAsignacion.Invalidate(); // ¡Llama al texto gris!
                    return;
                }

                // 2. ¿El equipo está dado de baja?
                string estadoHardware = _hardwareRepository.ObtenerEstado(serie);
                if (estadoHardware == "DESECHO" || estadoHardware == "INACTIVO")
                {
                    lblEnter.Text = "Equipo en desecho (No asignable).";
                    lblEnter.ForeColor = Color.Red;
                    DeshabilitarCampos();
                    LimpiarTextBoxAsignaciones();

                    // --- BANDERAS: APAGAMOS TODO (No queremos marcas de agua aquí) ---
                    _busquedaSinResultados = false;
                    _equipoLibre = false;

                    dataGridAsignacion.DataSource = null;
                    dataGridAsignacion.Rows.Clear();
                    dataGridAsignacion.ColumnHeadersVisible = false;
                    dataGridAsignacion.Invalidate();
                    return;
                }

                // 3. Vamos por el historial a la BD usando
                AsignacionTracking asignacionReciente = _trackingRepository.BuscarPorNumeroSerie(serie);

                // 4. Verificamos si existe un registro y si su estado es 1 (ACTIVA)
                if (asignacionReciente != null && asignacionReciente.idEstadoAsignacion == 1)
                {
                    // RUTA A: EQUIPO PRESTADO 
                    lblEnter.Text = "Equipo actualmente asignado";
                    lblEnter.ForeColor = Color.RoyalBlue;

                    // --- BANDERAS: APAGAMOS TODO (El grid se va a llenar de datos reales) ---
                    _busquedaSinResultados = false;
                    _equipoLibre = false;

                    dataGridAsignacion.ColumnHeadersVisible = true;

                    HabilitarCampos();

                    // Llenamos campos
                    txtNombreEquipo.Text = asignacionReciente.nombreEquipo;
                    txtEncargado.Text = asignacionReciente.nombreTrabajador;
                    cmbUbicacion.Text = asignacionReciente.nave;
                    txtComentarios.Text = asignacionReciente.comentarios;



                    // Pintamos el Grid
                    var listaUnica = new List<AsignacionTracking> { asignacionReciente };
                    dataGridAsignacion.DataSource = listaUnica;

                    if (dataGridAsignacion.Columns.Contains("idEstadoAsignacion"))
                        dataGridAsignacion.Columns["idEstadoAsignacion"].Visible = false;

                    btnDevoluciones.Visible = true;
                    btnDevoluciones.Enabled = true;
                    btnGuardarAsignacion.Enabled = true;
                    _esReasignacion = true;
                }
                else
                {
                    // RUTA B: EQUIPO LIBRE (Nunca se ha prestado, o el último estado fue Devolución)
                    lblEnter.Text = "Equipo disponible para asignar";
                    lblEnter.ForeColor = Color.RoyalBlue;

                    HabilitarCampos();
                    LimpiarTextBoxAsignaciones(); // Limpiamos por si había textos de otra búsqueda

                    // --- BANDERAS: CASO EQUIPO LIBRE ---
                    _busquedaSinResultados = false;
                    _equipoLibre = true;

                    dataGridAsignacion.DataSource = null;
                    dataGridAsignacion.Rows.Clear();
                    dataGridAsignacion.ColumnHeadersVisible = false;

                    // ¡Disparamos el repintado para llamar al texto verde!
                    dataGridAsignacion.Invalidate();

                    btnDevoluciones.Visible = false;
                    btnGuardarAsignacion.Enabled = true;
                    _esReasignacion = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al buscar el equipo: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Tracking_Load(object sender, EventArgs e)
        {
            CentrarPanel();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnCrud_Click(object sender, EventArgs e)
        {

            Crud pantallaDashboard = new Crud();
            pantallaDashboard.FormClosed += (s, args) => this.Close();

            pantallaDashboard.Show();

            this.Hide();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {

            Menu pantallaDashboard = new Menu();
            pantallaDashboard.FormClosed += (s, args) => this.Close();

            pantallaDashboard.Show();

            this.Hide();
        }

        private void btnTracking_Click(object sender, EventArgs e)
        {


            Tracking pantallaDashboard = new Tracking();
            pantallaDashboard.FormClosed += (s, args) => this.Close();

            pantallaDashboard.Show();

            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult confirmacion = MessageBox.Show("¿Estás seguro de que deseas salir del sistema?", "Confirmar salida",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
            );

            // 2. Evaluamos qué botón presionó el usuario
            if (confirmacion == DialogResult.Yes)
            {
                FormLogin pantallaDashboard = new FormLogin();
                pantallaDashboard.FormClosed += (s, args) => this.Close();

                pantallaDashboard.Show();

                this.Hide(); // Oculta el login
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void txtUbicacion_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            Reportes pantallaDashboard = new Reportes();
            pantallaDashboard.FormClosed += (s, args) => this.Close();

            pantallaDashboard.Show();

            this.Hide();
        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtnumeroSerie_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {

                //Silenciamos el sonido de Windows
                e.SuppressKeyPress = true;
                BuscarEquipo();
                cmbUbicacion.Focus();
            }

        }

        private void btnGuardarAsignacion_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(txtNombreEquipo.Text) ||
                 string.IsNullOrWhiteSpace(txtEncargado.Text) ||
                 cmbUbicacion.SelectedIndex == -1)
            {
                MessageBox.Show("ID Trabajador, Nombre y Nave son obligatorios.",
                                "Captura incompleta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string serie = txtnumeroSerie.Text.Trim();
                string idTrabajador = txtNombreEquipo.Text.Trim();
                string nombre = txtEncargado.Text.Trim();
                string nave = cmbUbicacion.Text;
                string comentarios = txtComentarios.Text.Trim();
                bool exito;

                var asignacionActiva = _trackingRepository.BuscarAsignacionActiva(serie);

                if (_esReasignacion)
                {
                    exito = _trackingRepository.ActualizarAsignacion(serie, nave, idTrabajador, nombre, comentarios);
                    MessageBox.Show("Equipo reasignado exitosamente.",
                                    "Reasignación completada", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    RefrescarModulo();

                    RefrescarGridTracking();

                }
                else
                {
                    var nueva = new AsignacionTracking
                    {
                        numeroSerie = serie,
                        nombreEquipo = idTrabajador,
                        nombreTrabajador = nombre,
                        nave = nave,
                        comentarios = comentarios,
                        idEstadoAsignacion = 1,

                    };

                    exito = _trackingRepository.InsertarAsignacion(nueva);
                    if (exito)
                        MessageBox.Show("Equipo asignado exitosamente.",
                                        "Asignación completada", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    RefrescarModulo();

                }

                if (!exito)
                {
                    MessageBox.Show("No se pudo guardar en la base de datos.",
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                txtnumeroSerie.Clear();
                ConfigurarInterfazInicial();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Excepción", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnReasignar_Click(object sender, EventArgs e)
        {
            string serie = txtnumeroSerie.Text;

            HabilitarCampos();
            btnGuardarAsignacion.Enabled = true;
            btnGuardarAsignacion.Text = "Confirmar";


            lblEnter.Text = "Edite los datos y confirme la reasignación";
            lblEnter.ForeColor = Color.RoyalBlue;

            txtNombreEquipo.Focus();
            cmbUbicacion.Focus();
        }

        private void HabilitarCampos()
        {
            txtNombreEquipo.Enabled = true;
            txtEncargado.Enabled = true;
            cmbUbicacion.Enabled = true;
            txtComentarios.Enabled = true;

        }

        private void DeshabilitarCampos()
        {
            txtNombreEquipo.Enabled = false;
            txtEncargado.Enabled = false;
            cmbUbicacion.Enabled = false;
            txtComentarios.Enabled = false;

            txtNombreEquipo.Clear();
            txtEncargado.Clear();
            cmbUbicacion.SelectedIndex = -1;
            txtComentarios.Clear();
        }



        /// <summary>
        /// Llama al repositorio y refresca el DataGridView con los datos más recientes.
        /// </summary>
        private void RefrescarGridTracking()
        {
            try
            {
                // 1. Obtenemos los datos de MariaDB
                DataTable datos = _trackingRepository.ObtenerAsignacionesActivas();

                dataGridAsignacion.DataSource = datos;

                if (dataGridAsignacion.Columns.Count > 0)
                {
                    dataGridAsignacion.Columns["idAsignacion"].Visible = false; // Ocultamos el ID interno de la BD
                    dataGridAsignacion.Columns["numeroSerie"].HeaderText = "Número de Serie";
                    dataGridAsignacion.Columns["nombreEquipo"].HeaderText = " Nombre del Equipo";
                    dataGridAsignacion.Columns["nombreTrabajador"].HeaderText = "Nombre";
                    dataGridAsignacion.Columns["nave"].HeaderText = "Nave";
                    dataGridAsignacion.Columns["fechaAsignacion"].HeaderText = "Fecha Asignación";
                    dataGridAsignacion.Columns["comentarios"].HeaderText = "Comentarios";

                    // Auto-ajustar el tamaño de las columnas
                    dataGridAsignacion.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo cargar la tabla de tracking: " + ex.Message,
                                "Error de Conexión", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void AplicarEstiloCorporativoGrid()
        {
            // 1. OBLIGATORIO: Apagar el estilo por defecto para que deje pintar tus colores
            dataGridAsignacion.EnableHeadersVisualStyles = false;

            // 2. ENCABEZADOS (Títulos) - Tu Azul Rey (#00479A)
            dataGridAsignacion.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#00479A");
            dataGridAsignacion.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            // Usamos Arial directo, en negritas para que el título resalte
            dataGridAsignacion.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dataGridAsignacion.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridAsignacion.ColumnHeadersHeight = 35;

            // 3. TABLA GENERAL (Filas) - Tu Azul Cian (#00738A)
            dataGridAsignacion.DefaultCellStyle.BackColor = ColorTranslator.FromHtml("#00738A");
            dataGridAsignacion.DefaultCellStyle.ForeColor = Color.White;
            // Usamos Arial regular para la lectura de los datos
            dataGridAsignacion.DefaultCellStyle.Font = new Font("Arial", 9);

            // 4. FILAS ALTERNADAS (Efecto cebra)
            // Le puse un tono apenitas más oscuro que el #00738A para no cansar la vista
            dataGridAsignacion.AlternatingRowsDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#006579");

            // 5. SELECCIÓN (Cuando le das clic a un equipo)
            // Mantenemos tu azul oscuro para que se note claramente qué fila agarraste
            dataGridAsignacion.DefaultCellStyle.SelectionBackColor = ColorTranslator.FromHtml("#002B5E");
            dataGridAsignacion.DefaultCellStyle.SelectionForeColor = Color.White;

            // 6. BORDES Y APARIENCIA GENERAL
            dataGridAsignacion.BorderStyle = BorderStyle.None;
            dataGridAsignacion.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            // Cambié el borde de la celda a un gris muy claro para que la línea blanca pura no "deslumbre"
            dataGridAsignacion.GridColor = Color.LightGray;

            // Ocultar la columna de la flechita izquierda y autoajustar el tamaño
            dataGridAsignacion.RowHeadersVisible = false;
            dataGridAsignacion.AllowUserToResizeRows = false;
            // Esto permite seleccionar celdas individuales en lugar de toda la fila
            dataGridAsignacion.SelectionMode = DataGridViewSelectionMode.CellSelect;
            // Esto habilita la copia nativa con Ctrl+C
            dataGridAsignacion.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            // Reemplaza el Fill por esto:
            dataGridAsignacion.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dataGridAsignacion.AllowUserToResizeColumns = true;

        }
        private void txtIdTrabajador_KeyDown(object sender, KeyEventArgs e)
        {
           
        }

        private void txtEncargado_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // Silencia el "Ding" de Windows

                txtNombreEquipo.Focus();
            }
        }

        private void txtComentarios_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // Silencia el "Ding" de Windows

                btnGuardarAsignacion.PerformClick();
            }

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnDevoluciones_Click(object sender, EventArgs e)
        {
            {
                txtnumeroSerie.Enabled = true;
                btnDevoluciones.Enabled = false;
                string serie = txtnumeroSerie.Text.Trim();

                // 1. Validamos que haya un número de serie escrito
                if (string.IsNullOrWhiteSpace(serie))
                {
                    MessageBox.Show("Por favor, ingrese o seleccione un número de serie para devolver.",
                                    "Dato faltante", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // 2. Pedimos confirmación al usuario por seguridad
                DialogResult confirmacion = MessageBox.Show($"¿Estás seguro de que deseas registrar la devolución del equipo con serie '{serie}'?",
                                                            "Confirmar Devolución",
                                                            MessageBoxButtons.YesNo,
                                                            MessageBoxIcon.Question);

                if (confirmacion == DialogResult.Yes)
                {
                    try
                    {
                        // 3. Ejecutamos el método del repositorio
                        bool exito = _trackingRepository.RegistrarDevolucion(serie);

                        if (exito)
                        {
                            MessageBox.Show("El equipo ha sido devuelto exitosamente. La fecha se registró automáticamente.",
                                            "Devolución completada", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // 4. Limpiamos la pantalla y refrescamos la tabla

                            txtnumeroSerie.Focus();
                            ConfigurarInterfazInicial();
                            RefrescarGridTracking();

                        }
                        else
                        {
                            MessageBox.Show("No se pudo procesar la devolución. Verifique que el equipo actualmente esté asignado (ACTIVO).",
                                            "Operación no realizada", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message, "Excepción", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void dataGridAsignacion_Paint(object sender, PaintEventArgs e)
        {
            // 1. Primero confirmamos que el grid esté vacío (aplica para ambos casos)
            if (dataGridAsignacion.Rows.Count == 0)
            {
                string mensaje = "";
                Brush brocha = null;

                // --- AQUÍ ACOMODAS TUS IF ---

                // CASO A: El equipo NO existe en la base de datos
                if (_busquedaSinResultados)
                {
                    mensaje = "EQUIPO INEXISTENTE\nInserte un número de serie distinto";
                    brocha = new SolidBrush(Color.LightSlateGray);
                }
                // CASO B: El equipo SÍ existe, pero está libre en SISTEMAS
                else if (_equipoLibre)
                {
                    mensaje = "EQUIPO DISPONIBLE\nListo para ser asignado";
                    brocha = new SolidBrush(Color.LightSlateGray);
                }

                // 2. Si alguna de las banderas activó un mensaje, entonces sí pintamos
                if (!string.IsNullOrEmpty(mensaje))
                {
                    Font fuente = new Font("Arial", 14, FontStyle.Bold);

                    StringFormat formato = new StringFormat();
                    formato.Alignment = StringAlignment.Center;
                    formato.LineAlignment = StringAlignment.Center;

                    Rectangle area = new Rectangle(0, 0, dataGridAsignacion.Width, dataGridAsignacion.Height);

                    e.Graphics.DrawString(mensaje, fuente, brocha, area, formato);
                }
            }
        }

        private void panelPrincipal_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {

            RefrescarModulo();

        }

        private void RefrescarModulo()
        {
            Tracking pantallaDashboard = new Tracking();
            pantallaDashboard.Show();
            this.Hide();
            txtnumeroSerie.Focus();
        }

        private void txtIdTrabajador_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEncargado_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbUbicacion_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // Silencia el "Ding" de Windows

                txtEncargado.Focus();
            }
        }

        
        private void txtNombreEquipo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // Silencia el "Ding" de Windows

                txtComentarios.Focus();
            }
        }
    }
}



