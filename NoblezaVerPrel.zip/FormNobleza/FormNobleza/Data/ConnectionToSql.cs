﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;

namespace FormNobleza.Data
{
    public class ConnectionToSql
    {
        protected readonly string connectionString;

        public ConnectionToSql()
        {
            connectionString = "Server = localhost; Port = 3306; Database = nobleza; Uid = trackpc; Pwd =trackpc;";
        }

        public MySqlConnection GetConnection()
        {
            return new MySqlConnection(connectionString);
        }
    }
}
