﻿using System;
using MySql.Data.MySqlClient;
using FormNobleza.Models;
using System.Data;

namespace FormNobleza.Data
{
    public class TrackingRepository : ConnectionToSql
    {
        /// <summary>
        /// Busca si un número de serie tiene una asignación ACTIVA (idEstadoAsignacion = 1).
        /// Retorna el objeto si existe, null si el equipo está libre.
        /// </summary>
        public AsignacionTracking BuscarAsignacionActiva(string numeroSerie)
        {
            // CAMBIO: Buscamos por idEstadoAsignacion = 1
            string query = @"SELECT * FROM asignaciones 
                             WHERE numeroSerie = @serie 
                               AND idEstadoAsignacion = 1 
                             LIMIT 1;";
            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@serie", numeroSerie.Trim());

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new AsignacionTracking
                                {
                                    idAsignacion = Convert.ToInt32(reader["idAsignacion"]),
                                    numeroSerie = reader["numeroSerie"].ToString(),
                                    nombreEquipo = reader["nombreEquipo"].ToString(),
                                    nombreTrabajador = reader["nombreTrabajador"].ToString(),
                                    nave = reader["nave"].ToString(),
                                    comentarios = reader["comentarios"].ToString(),
                                    // CAMBIO: Ahora leemos el ID numérico en lugar del texto
                                    idEstadoAsignacion = Convert.ToInt32(reader["idEstadoAsignacion"]),
                                    fechaAsignacion = Convert.ToDateTime(reader["fechaAsignacion"]),
                                };
                            }
                        }
                    }
                }
                return null; // Equipo libre
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar la asignación activa: " + ex.Message);
            }
        }
        public AsignacionTracking BuscarPorNumeroSerie(string serie)
        {
            string valorSerie = serie.Trim();

            // Traemos solo el registro más reciente de esa computadora específica
            string query = @"SELECT * FROM asignaciones 
                     WHERE numeroSerie = @numeroSerie 
                     ORDER BY fechaAsignacion DESC LIMIT 1;";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@numeroSerie", valorSerie);

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new AsignacionTracking
                                {
                                    // Mapeamos SOLO los campos que pertenecen a la tabla asignaciones
                                    numeroSerie = reader["numeroSerie"].ToString(),

                                    nombreEquipo = reader["nombreEquipo"].ToString(),

                                    nombreTrabajador = reader["nombreTrabajador"].ToString(),
                                    nave = reader["nave"].ToString(),

                                    // Protegemos los comentarios por si los dejaron en blanco (nulos)
                                    comentarios = reader["comentarios"] != DBNull.Value ? reader["comentarios"].ToString() : "",

                                    idEstadoAsignacion = reader["idEstadoAsignacion"] != DBNull.Value ? Convert.ToInt32(reader["idEstadoAsignacion"]) : 0,

                                    fechaAsignacion = Convert.ToDateTime(reader["fechaAsignacion"])
                                };
                            }
                        }
                    }
                }
                return null; // Si nunca se ha prestado, regresa null
            }
            catch (Exception ex)
            {
                throw new Exception("Error al buscar la asignación por Número de Serie: " + ex.Message);
            }
        }
        /// <summary>
        /// Registra una nueva asignación (INSERT).
        /// fechaAsignacion la genera MariaDB con DEFAULT current_timestamp().
        /// </summary>
        public bool InsertarAsignacion(AsignacionTracking asignacion)
        {
            // 1. Corregimos el query: Agregamos  a la lista de columnas
            string queryInsert = @"INSERT INTO asignaciones 
                          (numeroSerie, nombreEquipo, nombreTrabajador, nave, comentarios, idEstadoAsignacion) 
                          VALUES (@serie, @idTrab, @nombre, @nave, @comentarios, 1);";

            // 2. El query para actualizar tu tabla principal
            string queryUpdate = @"UPDATE hardware 
                           SET idEstadoAsignacion = 1 
                           WHERE numeroSerie = @serie;";

            try
            {
                // AQUÍ nace la conexión
                using (var connection = GetConnection())
                {
                    connection.Open();

                    // PASO A: Insertamos el historial en la tabla asignaciones
                    using (var cmdInsert = new MySqlCommand(queryInsert, connection))
                    {
                        cmdInsert.Parameters.AddWithValue("@serie", asignacion.numeroSerie);
                        cmdInsert.Parameters.AddWithValue("@idTrab", asignacion.nombreEquipo);
                        cmdInsert.Parameters.AddWithValue("@nombre", asignacion.nombreTrabajador);
                        cmdInsert.Parameters.AddWithValue("@nave", asignacion.nave);
                        cmdInsert.Parameters.AddWithValue("@comentarios", asignacion.comentarios ?? "");
                       

                        cmdInsert.ExecuteNonQuery();
                    }

                    // PASO B: Actualizamos la tabla hardware
                    using (var cmdUpdate = new MySqlCommand(queryUpdate, connection))
                    {
                        cmdUpdate.Parameters.AddWithValue("@serie", asignacion.numeroSerie);
                        cmdUpdate.ExecuteNonQuery();
                    }

                    return true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al insertar nueva asignación: " + ex.Message);
            }
        }

        /// <summary>
        /// Extrae todo el historial de equipos que actualmente están asignados (ACTIVOS)
        /// </summary>
        public DataTable ObtenerAsignacionesActivas()
        {
            DataTable tablaVacia = new DataTable();
            // CAMBIO: Filtramos por idEstadoAsignacion = 1
            string query = @"SELECT idAsignacion, numeroSerie, nombreEquipo, nombreTrabajador, nave, fechaAsignacion, comentarios 
                             FROM asignaciones 
                             WHERE idEstadoAsignacion = 1 
                             ORDER BY fechaAsignacion DESC;";
            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        using (var adapter = new MySqlDataAdapter(command))
                        {
                            adapter.Fill(tablaVacia);
                        }
                    }
                }
                return tablaVacia;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al obtener el historial de tracking: " + ex.Message);
            }
        }

        /// <summary>
        /// Actualiza el dueño actual (UPDATE – modo Reasignación).
        /// </summary>
        public bool ActualizarAsignacion(string numeroSerie, string nave, string nombreEquipo,
                                 string nombreTrabajador, string comentarios)
        {
            string query = @"UPDATE asignaciones 
                             SET nave = @nave, 
                                 nombreEquipo = @idTrab, 
                                 nombreTrabajador = @nombre, 
                                 comentarios = @comentarios,
                                 fechaAsignacion = CURRENT_TIMESTAMP
                             WHERE numeroSerie = @serie 
                               AND idEstadoAsignacion = 1;"; // Agregué el filtro para asegurar que solo toque la activa
            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@nave", nave);
                        command.Parameters.AddWithValue("@idTrab", nombreEquipo);
                        command.Parameters.AddWithValue("@nombre", nombreTrabajador);
                        command.Parameters.AddWithValue("@comentarios", comentarios ?? "");
                        command.Parameters.AddWithValue("@serie", numeroSerie);

                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error en la actualización base: " + ex.Message);
            }
        }

        /// <summary>
        /// Registra la devolución de un equipo cambiando su estado a SISTEMAS (ID 3).
        /// </summary>
        public bool RegistrarDevolucion(string numeroSerie)
        {
            // 1. Cerramos el historial: Cambiamos la asignación actual a terminada (ej. ID 2)
            // Nota: Dependiendo de tu base de datos, aquí también podrías hacer un UPDATE 
            // a la fecha de devolución (ej. fechaDevolucion = CURRENT_TIMESTAMP)
            string queryCerrarAsignacion = @"UPDATE asignaciones 
                                 SET idEstadoAsignacion = 2,
                                     fechaDevolucion = CURRENT_TIMESTAMP 
                                 WHERE numeroSerie = @serie AND idEstadoAsignacion = 1;";

            // 2. Liberamos el equipo: Le decimos a la tabla principal que regresó a Sistemas (ID 3)
            string queryActualizarHardware = @"UPDATE hardware 
                                       SET idEstadoAsignacion = 3 
                                       WHERE numeroSerie = @serie;";

            try
            {
                // Abrimos el "tubo" de comunicación una sola vez
                using (var connection = GetConnection())
                {
                    connection.Open();

                    // PASO A: Terminamos la asignación en el tracking
                    using (var cmdCerrar = new MySqlCommand(queryCerrarAsignacion, connection))
                    {
                        cmdCerrar.Parameters.AddWithValue("@serie", numeroSerie);
                        cmdCerrar.ExecuteNonQuery();
                    }

                    // PASO B: Actualizamos la tabla principal de hardware
                    using (var cmdUpdate = new MySqlCommand(queryActualizarHardware, connection))
                    {
                        cmdUpdate.Parameters.AddWithValue("@serie", numeroSerie);
                        cmdUpdate.ExecuteNonQuery();
                    }

                    return true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al registrar la devolución: " + ex.Message);
            }
        }
    }
}