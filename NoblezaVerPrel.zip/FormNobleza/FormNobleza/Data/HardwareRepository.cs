﻿using System;
using System.Collections.Generic;
using System.Data;
using MySql.Data.MySqlClient;
using FormNobleza.Models;

namespace FormNobleza.Data
{
    // Hereda ConnectionToSql para reutilizar GetConnection()
    public class HardwareRepository : ConnectionToSql
    {
        // VALIDAR ID
        public bool ExisteNumeroSerie(string serie)
        {
            string query = "SELECT COUNT(*) FROM hardware WHERE numeroSerie = @numeroSerie;";
            string numeroSerie = serie.Trim();

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@numeroSerie", numeroSerie);
                        int count = Convert.ToInt32(command.ExecuteScalar());
                        return count > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al validar el ID: " + ex.Message);
            }
        }

        public Hardware BuscarPorNumeroSerie(string serie)
        {
            string valorSerie = serie.Trim();
            string query = "SELECT * FROM hardware WHERE numeroSerie = @numeroSerie;";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@numeroSerie", valorSerie);

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new Hardware
                                {
                                    idHardware = Convert.ToInt32(reader["idHardware"]),
                                    numeroSerie = reader["numeroSerie"].ToString(),
                                    modelo = reader["modelo"].ToString(),
                                    idCategoria = Convert.ToInt32(reader["idCategoria"]),
                                    idMarca = Convert.ToInt32(reader["idMarca"]),
                                    idEstado = Convert.ToInt32(reader["idEstado"]),

                                    // Campos corregidos y actualizados
                                    idProcesador = reader["idProcesador"] == DBNull.Value ? 0 : Convert.ToInt32(reader["idProcesador"]),
                                    idSistema = reader["idSistema"] == DBNull.Value ? 0 : Convert.ToInt32(reader["idSistema"]),
                                    disco = reader["disco"].ToString(),
                                    ram = reader["ram"].ToString(),
                                };
                            }
                        }
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al buscar por numero de Serie " + ex.Message);
            }
        }

        // INSERTAR NUEVO HARDWARE
        public void Insertar(Hardware hw)
        {
            // INYECTAMOS idEstadoAsignacion en el INSERT y le quemamos el 3
            string query = @"INSERT INTO hardware 
                    (numeroSerie, modelo, idCategoria, idMarca, idEstado, idProcesador, idSistema, disco, ram, idEstadoAsignacion) 
                    VALUES 
                    (@numeroSerie, @modelo, @idCategoria, @idMarca, @idEstado, @idProcesador, @idSistema, @disco, @ram, 3);";
            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@numeroSerie", hw.numeroSerie.Trim());
                        command.Parameters.AddWithValue("@modelo", hw.modelo.Trim());
                        command.Parameters.AddWithValue("@idCategoria", hw.idCategoria);
                        command.Parameters.AddWithValue("@idMarca", hw.idMarca);
                        command.Parameters.AddWithValue("@idEstado", hw.idEstado);
                        command.Parameters.AddWithValue("@idProcesador", hw.idProcesador);
                        command.Parameters.AddWithValue("@idSistema", hw.idSistema);
                        command.Parameters.AddWithValue("@disco", hw.disco);
                        command.Parameters.AddWithValue("@ram", hw.ram);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al insertar el equipo: " + ex.Message);
            }
        }
        // ACTUALIZAR Hardware existente 
        public void Actualizar(Hardware hw)
        {
            string query = @"UPDATE hardware SET 
                        numeroSerie    = @numeroSerie, 
                        modelo         = @modelo, 
                        idCategoria    = @idCategoria, 
                        idMarca        = @idMarca, 
                        idEstado       = @idEstado, 
                        idProcesador   = @idProcesador, 
                        idSistema      = @idSistema, 
                        disco          = @disco, 
                        ram            = @ram 
                    WHERE idHardware   = @idHardware;";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@numeroSerie", hw.numeroSerie.Trim());
                        command.Parameters.AddWithValue("@modelo", hw.modelo.Trim());
                        command.Parameters.AddWithValue("@idCategoria", hw.idCategoria);
                        command.Parameters.AddWithValue("@idMarca", hw.idMarca);
                        command.Parameters.AddWithValue("@idEstado", hw.idEstado);

                        command.Parameters.AddWithValue("@idProcesador", hw.idProcesador);
                        command.Parameters.AddWithValue("@idSistema", hw.idSistema);
                        command.Parameters.AddWithValue("@disco", hw.disco);
                        command.Parameters.AddWithValue("@ram", hw.ram);

                        command.Parameters.AddWithValue("@idHardware", hw.idHardware);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al actualizar el equipo: " + ex.Message);
            }
        }

        // ELIMINAR
        public void Eliminar(int idHardware)
        {
            string queryAsignaciones = @"
                DELETE FROM asignaciones 
                WHERE numeroSerie = (SELECT numeroSerie FROM hardware WHERE idHardware = @idHardware);";

            string queryHardware = "DELETE FROM hardware WHERE idHardware = @idHardware;";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();

                    using (var transaction = connection.BeginTransaction())
                    {
                        using (var command = new MySqlCommand(queryAsignaciones, connection, transaction))
                        {
                            command.Parameters.AddWithValue("@idHardware", idHardware);
                            command.ExecuteNonQuery();
                        }

                        using (var command = new MySqlCommand(queryHardware, connection, transaction))
                        {
                            command.Parameters.AddWithValue("@idHardware", idHardware);
                            command.ExecuteNonQuery();
                        }
                        transaction.Commit();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error crítico al eliminar el equipo y sus dependencias de rastreo: " + ex.Message);
            }
        }

        public List<Hardware> BuscarUnicoParaGrid(string numeroSerie)
        {
            //TODO A LEFT JOIN: Así aseguramos que la compu salga aunque le falten datos.
            // 2. IFNULL: Limpiamos los nulos desde aquí para no hacer sufrir a C#.
            string query = @" 
        SELECT 
            h.idHardware, 
            h.numeroSerie, 
            IFNULL(h.modelo, 'S/M') AS modelo, 
            IFNULL(c.nombreCategoria, 'N/A') AS nombreCategoria, 
            IFNULL(m.nombreMarca, 'N/A') AS nombreMarca, 
            IFNULL(e.nombreEstado, 'N/A') AS nombreEstado,         
            IFNULL(p.nombreProcesador, 'N/A') AS nombreProcesador, 
            IFNULL(s.nombreSistema, 'N/A') AS nombreSistema,        
            h.idProcesador, 
            h.idSistema, 
            IFNULL(h.disco, 'N/A') AS disco, 
            IFNULL(h.ram, 'N/A') AS ram, 
            h.fechaCreacion  
        FROM hardware h  
        LEFT JOIN categorias c ON h.idCategoria = c.idCategoria  
        LEFT JOIN marcas m ON h.idMarca = m.idMarca  
        LEFT JOIN estados_hardware e ON h.idEstado = e.idEstado  
        LEFT JOIN procesador p ON h.idProcesador = p.idProcesador  
        LEFT JOIN sistema s ON h.idSistema = s.idSistema 
        WHERE h.numeroSerie = @serie  
        LIMIT 1;";

            var lista = new List<Hardware>();

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@serie", numeroSerie.Trim());

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                lista.Add(new Hardware
                                {
                                    idHardware = Convert.ToInt32(reader["idHardware"]),
                                    numeroSerie = reader["numeroSerie"].ToString(),

                                    // Como SQL ya nos mandó 'S/M' o 'N/A', el ToString() es 100% seguro
                                    modelo = reader["modelo"].ToString(),
                                    Categoria = reader["nombreCategoria"].ToString(),
                                    Marca = reader["nombreMarca"].ToString(),
                                    Estado = reader["nombreEstado"].ToString(),
                                    Procesador = reader["nombreProcesador"].ToString(),
                                    Sistema = reader["nombreSistema"].ToString(),
                                    disco = reader["disco"].ToString(),
                                    ram = reader["ram"].ToString(),

                                    // Estos los dejamos con la validación de DBNull porque son números (IDs)
                                    idProcesador = reader["idProcesador"] == DBNull.Value ? 0 : Convert.ToInt32(reader["idProcesador"]),
                                    idSistema = reader["idSistema"] == DBNull.Value ? 0 : Convert.ToInt32(reader["idSistema"]),

                                    fechaCreacion = Convert.ToDateTime(reader["fechaCreacion"])
                                });
                            }
                        }
                    }
                }
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al buscar el equipo específico: " + ex.Message);
            }
        }

        // Pintar el grid
        // Pintar el grid
        public DataTable ObtenerTodos()
        {
            DataTable tablaFusionada = new DataTable();

            string query = @"
    SELECT 
        h.numeroSerie AS 'Número de Serie',
        IFNULL(h.modelo, 'S/M') AS 'Modelo',
        IFNULL(c.nombreCategoria, 'N/A') AS 'Categoría',
        IFNULL(m.nombreMarca, 'N/A') AS 'Marca',
        IFNULL(eh.nombreEstado, 'N/A') AS 'Estado Físico',
        IFNULL(p.nombreProcesador, 'N/A') AS 'Procesador',
        IFNULL(s.nombreSistema, 'N/A') AS 'Sistema Operativo',
        IFNULL(h.disco, 'N/A') AS 'Disco Duro',
        IFNULL(h.ram, 'N/A') AS 'RAM',
        h.fechaCreacion AS 'Fecha Registro',
        IFNULL(ea.nombreEstadoAsignacion, 'SIN ASIGNAR') AS 'Estado Asignación',
        
        -- Campos de la tabla asignaciones
        IFNULL(a.nombreTrabajador, 'SIN ASIGNAR') AS 'Trabajador',
        IFNULL(a.nave, 'SIN ASIGNAR') AS 'Nave'
        
    FROM hardware h
    LEFT JOIN categorias c ON h.idCategoria = c.idCategoria
    LEFT JOIN marcas m ON h.idMarca = m.idMarca
    LEFT JOIN estados_hardware eh ON h.idEstado = eh.idEstado
    LEFT JOIN procesador p ON h.idProcesador = p.idProcesador
    LEFT JOIN sistema s ON h.idSistema = s.idSistema
    LEFT JOIN estados_asignacion ea ON h.idEstadoAsignacion = ea.idEstadoAsignacion
    
    -- Cruzamos la tabla pero exigiendo que la asignación esté ACTIVA (1)
    LEFT JOIN asignaciones a ON h.numeroSerie = a.numeroSerie AND a.idEstadoAsignacion = 1
    
    ORDER BY h.fechaCreacion DESC;";
            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        using (var adapter = new MySqlDataAdapter(command))
                        {
                            adapter.Fill(tablaFusionada);
                        }
                    }
                }
                return tablaFusionada;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al cargar el nuevo inventario: " + ex.Message);
            }
        }

        public bool DarDeBajaDefinitiva(string numeroSerie, int idEstadoDesecho, int idAdmin)
        {
            // 1. Actualizamos el estado del hardware
            string queryHardware = @"
        UPDATE hardware 
        SET idEstado = @idDesecho
        WHERE numeroSerie = @serie;";

            // 2. LA CORRECCIÓN: Usamos idEstadoAsignacion = 2 (INACTIVA) 
            // y cerramos la asignación sin importar si estaba con un usuario (1) o en Sistemas (3)
            string queryAsignacion = @"
        UPDATE asignaciones 
        SET idEstadoAsignacion = 2, 
            fechaDevolucion = CURRENT_TIMESTAMP,
            comentarios = CONCAT(IFNULL(comentarios, ''), ' - [BAJA DEFINITIVA POR DESECHO]') 
        WHERE numeroSerie = @serie AND idEstadoAsignacion IN (1, 3);";

            // 3. Dejamos el registro histórico de la muerte del equipo
            string queryHistorial = @"
        INSERT INTO historial_asignaciones (numeroSerie, nombreEquipo, nombreTrabajador, nave, comentarios)
        VALUES (@serie, 'N/A', 'SISTEMA', 'DESECHO', 'Baja definitiva del inventario');";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();

                    // Iniciamos la Transacción
                    using (var transaction = connection.BeginTransaction())
                    {
                        // Paso 1: Hardware
                        using (var cmd1 = new MySqlCommand(queryHardware, connection, transaction))
                        {
                            cmd1.Parameters.AddWithValue("@serie", numeroSerie);
                            cmd1.Parameters.AddWithValue("@idDesecho", idEstadoDesecho);
                            cmd1.Parameters.AddWithValue("@idAdmin", idAdmin);
                            cmd1.ExecuteNonQuery();
                        }

                        // Paso 2: Asignaciones
                        using (var cmd2 = new MySqlCommand(queryAsignacion, connection, transaction))
                        {
                            cmd2.Parameters.AddWithValue("@serie", numeroSerie);
                            cmd2.ExecuteNonQuery();
                        }

                        // Paso 3: Historial
                        using (var cmd3 = new MySqlCommand(queryHistorial, connection, transaction))
                        {
                            cmd3.Parameters.AddWithValue("@serie", numeroSerie);
                            cmd3.ExecuteNonQuery();
                        }

                        // Consolidamos todo en la base de datos
                        transaction.Commit();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error crítico al dar de baja el equipo: " + ex.Message);
            }
        }

        public DataTable ObtenerDatosHardwareParaPDF(string numeroSerie)
        {
            DataTable tabla = new DataTable();

            // Añadidos los nuevos campos para que estén disponibles en tu PDF
            string query = @"
                SELECT h.modelo, c.nombreCategoria, m.nombreMarca, h.idProcesador, h.idSistema, h.disco, h.ram 
                FROM hardware h
                INNER JOIN categorias c ON h.idCategoria = c.idCategoria
                INNER JOIN marcas m ON h.idMarca = m.idMarca
                WHERE h.numeroSerie = @serie 
                LIMIT 1;";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@serie", numeroSerie.Trim());
                        using (var adapter = new MySqlDataAdapter(command))
                        {
                            adapter.Fill(tabla);
                        }
                    }
                }
                return tabla;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al recuperar detalles del hardware para el PDF: " + ex.Message);
            }
        }
        public string ObtenerEstado(string numeroSerie)
        {
            string estado = "";
            string query = @"
        SELECT e.nombreEstado 
        FROM hardware h
        INNER JOIN estados_hardware e ON h.idEstado = e.idEstado
        WHERE h.numeroSerie = @numeroSerie" ;

            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@numeroSerie", numeroSerie);
                    var result = command.ExecuteScalar();

                    if (result != null)
                    {
                        estado = result.ToString().ToUpper();
                    }
                }
            }
            return estado;
        }
    }
}