﻿using System;
using System.Data;
using MySql.Data.MySqlClient;

namespace FormNobleza.Data
{
    public class MenuRepository : ConnectionToSql
    {
        public DataTable ObtenerInventarioGeneral(string filtro)
        {
            DataTable tablaInventario = new DataTable();

            // Buscamos coincidencias en Serie, Nombre del Trabajador o Nave.
            // Si el filtro viene vacío (%), trae absolutamente TODA la tabla de asignaciones.
            string query = @"
          SELECT 
        numeroSerie AS 'NÚMERO SERIE',
        nombreEquipo AS 'NOMBRE EQUIPO',
        nombreTrabajador AS 'RESPONSABLE',
        nave AS 'NAVE',
        e.nombreEstadoAsignacion AS 'ESTADO',
        fechaAsignacion AS 'ÚLTIMA ASIGNACIÓN'
    FROM asignaciones
    LEFT JOIN estados_asignacion e ON asignaciones.idEstadoAsignacion = e.idEstadoAsignacion
    
    -- 1. Le decimos que A HUEVO solo traiga los que tienen el estado 1
    WHERE asignaciones.idEstadoAsignacion = 1 
    
    -- 2. Encerramos tu buscador entre paréntesis para que no rompa la regla de arriba
    AND (
        numeroSerie LIKE CONCAT('%', @busqueda, '%')
        OR nombreTrabajador LIKE CONCAT('%', @busqueda, '%')
        OR nave LIKE CONCAT('%', @busqueda, '%')
    )
    ORDER BY fechaAsignacion DESC;";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        // Le agregamos los comodines '%' para que busque la palabra en cualquier posición
                        command.Parameters.AddWithValue("@busqueda", "%" + filtro + "%");

                        using (var adapter = new MySqlDataAdapter(command))
                        {
                            adapter.Fill(tablaInventario);
                        }
                    }
                }
                return tablaInventario;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar el inventario principal: " + ex.Message);
            }
        }
    }
}