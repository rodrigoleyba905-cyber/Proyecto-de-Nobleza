﻿using System;
using System.Data;
using MySql.Data.MySqlClient;

namespace FormNobleza.Data
{
    public class ReportesRepository : ConnectionToSql
    {
        /// <summary>
        /// Fusiona la tabla histórica y la tabla viva para armar la línea de tiempo completa.
        /// Retorna un DataTable listo para pintar en el DataGridView o mandar al PDF.
        /// </summary>
        public DataTable ObtenerLineaDeTiempoCompleta(string numeroSerie)
        {
            DataTable tablaHistorial = new DataTable();

            string query = @"
        SELECT 
            numeroSerie, 
            nombreEquipo, 
            nombreTrabajador, 
            nave, 
            comentarios, 
            'INACTIVA' AS estado,  
            fechaMovimiento AS fecha
        FROM historial_asignaciones
        WHERE numeroSerie = @serie

        UNION ALL

        -- Evento 1: LA ASIGNACION. Siempre existe una por cada fila de `asignaciones`,
        -- sin importar si ya se devolvio o sigue activa. Usa SIEMPRE fechaAsignacion.
        SELECT 
            a.numeroSerie,
            IF(a.idEstadoAsignacion = 3, 'S/N', a.nombreEquipo)      AS nombreEquipo,
            IF(a.idEstadoAsignacion = 3, 'S/N', a.nombreTrabajador)  AS nombreTrabajador,
            IF(a.idEstadoAsignacion = 3, 'S/N', a.nave)              AS nave,
            IF(a.idEstadoAsignacion = 3, 'S/N', a.comentarios)       AS comentarios,
            CONCAT('ASIGNADO - ', e.nombreEstadoAsignacion)          AS estado,
            a.fechaAsignacion                                        AS fecha
        FROM asignaciones a
        INNER JOIN estados_asignacion e ON a.idEstadoAsignacion = e.idEstadoAsignacion
        WHERE a.numeroSerie = @serie

        UNION ALL

        -- Evento 2: LA DEVOLUCION. Solo aparece si el equipo ya fue devuelto
        -- (fechaDevolucion no es NULL). Esta es la fila que antes se perdia.
        SELECT 
            a.numeroSerie,
            a.nombreEquipo,
            a.nombreTrabajador,
            a.nave,
            a.comentarios,
            'DEVUELTO' AS estado,
            a.fechaDevolucion AS fecha
        FROM asignaciones a
        WHERE a.numeroSerie = @serie
          AND a.fechaDevolucion IS NOT NULL

        ORDER BY fecha DESC;";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@serie", numeroSerie.Trim());

                        using (var adapter = new MySqlDataAdapter(command))
                        {
                            adapter.Fill(tablaHistorial);
                        }
                    }
                }
                return tablaHistorial;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al fusionar el historial del equipo: " + ex.Message);
            }
        }
        public DataTable ObtenerDatosHardwareParaPDF(string numeroSerie)
        {
            DataTable tabla = new DataTable();

            // Traemos todo en texto (nombres) y usamos LEFT JOIN para proteger el query de nulos
            string query = @"
        SELECT 
            h.modelo, 
            c.nombreCategoria, 
            h.fechaCreacion,
            m.nombreMarca,
            p.nombreProcesador,
            s.nombreSistema,
            h.disco,
            h.ram,
            a.nombreTrabajador,
            a.comentarios
        FROM hardware h
        LEFT JOIN categorias c ON h.idCategoria = c.idCategoria
        LEFT JOIN marcas m ON h.idMarca = m.idMarca
        LEFT JOIN procesador p ON h.idProcesador = p.idProcesador
        LEFT JOIN sistema s ON h.idSistema = s.idSistema
        LEFT JOIN asignaciones a ON h.numeroSerie = a.numeroSerie AND a.idEstadoAsignacion = 1
        WHERE h.numeroSerie = @serie 
        LIMIT 1;";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@serie", numeroSerie.Trim());
                        using (var adapter = new MySqlDataAdapter(command))
                        {
                            adapter.Fill(tabla);
                        }
                    }
                }
                return tabla;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al recuperar detalles del equipo y asignación para el PDF: " + ex.Message);
            }
        }
    }
}