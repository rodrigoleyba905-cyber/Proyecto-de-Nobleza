﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FormNobleza.Models
{
    public class Hardware
    {
        public string numeroSerie { get; set; }
        public string modelo { get; set; }
        public string Categoria { get; set; } = "";
        public string Marca { get; set; } = "";
        public string Estado { get; set; } = "";
        public string Procesador { get; set; } = "";
        public string Sistema { get; set; } = "";
        public string disco { get; set; }
        public string ram { get; set; }
        public DateTime fechaCreacion { get; set; }

        // 2. LO QUE SE OCULTA (Los mandamos al fondo para que no rompan el orden)
        public int idHardware { get; set; }
        public int idCategoria { get; set; }
        public int idMarca { get; set; }
        public int idEstado { get; set; }
        public int idProcesador { get; set; }
        public int idSistema { get; set; }
    }
}