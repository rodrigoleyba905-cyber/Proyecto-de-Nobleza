﻿using System;

namespace FormNobleza.Models
{
    public class AsignacionTracking
    {
        public int idAsignacion { get; set; }
        public string numeroSerie { get; set; }
        public string nombreEquipo { get; set; }
        public string nombreTrabajador { get; set; }   // nombreTrabajador en BD
        public string nave { get; set; }
        public string comentarios { get; set; }
        public DateTime fechaAsignacion { get; set; }
        public int idEstadoAsignacion { get; set; }
    }
}