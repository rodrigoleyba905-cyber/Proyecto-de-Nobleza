﻿namespace FormNobleza
{
    partial class Crud
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Crud));
            dataGridRegistro = new DataGridView();
            btnAñadirEquipo = new Button();
            btnEliminarEquipo = new Button();
            label1 = new Label();
            panel1 = new Panel();
            pictureBox4 = new PictureBox();
            panelEdicion = new Panel();
            btnLimpiar = new Button();
            cmbSistema = new ComboBox();
            txtRam = new TextBox();
            txtDisco = new TextBox();
            cmbProcesador = new ComboBox();
            pictureBox2 = new PictureBox();
            lblInformacion = new Label();
            lblAlertaId = new Label();
            txtNumeroSerie = new TextBox();
            cmbEstado = new ComboBox();
            cmbMarca = new ComboBox();
            txtModelo = new TextBox();
            cmbCategoria = new ComboBox();
            pictureBox1 = new PictureBox();
            flowLayoutPanel3 = new FlowLayoutPanel();
            panel5 = new Panel();
            btnReportes = new Button();
            label11 = new Label();
            btnProfil = new Button();
            btnExit = new Button();
            btnTracking = new Button();
            btnCrud = new Button();
            btnHome = new Button();
            panelPrincipal = new Panel();
            flowLayoutPanel1 = new FlowLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)dataGridRegistro).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            panelEdicion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel5.SuspendLayout();
            panelPrincipal.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridRegistro
            // 
            dataGridRegistro.BackgroundColor = Color.FromArgb(235, 241, 246);
            dataGridRegistro.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(33, 97, 172);
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 10F);
            dataGridViewCellStyle1.ForeColor = Color.White;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridRegistro.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridRegistro.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.White;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9.5F);
            dataGridViewCellStyle2.ForeColor = Color.FromArgb(26, 26, 26);
            dataGridViewCellStyle2.SelectionBackColor = Color.Black;
            dataGridViewCellStyle2.SelectionForeColor = Color.White;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataGridRegistro.DefaultCellStyle = dataGridViewCellStyle2;
            dataGridRegistro.EnableHeadersVisualStyles = false;
            dataGridRegistro.Location = new Point(9, 99);
            dataGridRegistro.MultiSelect = false;
            dataGridRegistro.Name = "dataGridRegistro";
            dataGridRegistro.ReadOnly = true;
            dataGridRegistro.SelectionMode = DataGridViewSelectionMode.CellSelect;
            dataGridRegistro.Size = new Size(811, 516);
            dataGridRegistro.TabIndex = 0;
            dataGridRegistro.Paint += dataGridRegistro_Paint;
            // 
            // btnAñadirEquipo
            // 
            btnAñadirEquipo.BackColor = Color.FromArgb(0, 115, 138);
            btnAñadirEquipo.Cursor = Cursors.Hand;
            btnAñadirEquipo.FlatAppearance.BorderSize = 0;
            btnAñadirEquipo.FlatStyle = FlatStyle.Flat;
            btnAñadirEquipo.Font = new Font("Segoe UI Semibold", 12F);
            btnAñadirEquipo.ForeColor = Color.FromArgb(248, 249, 250);
            btnAñadirEquipo.Image = (Image)resources.GetObject("btnAñadirEquipo.Image");
            btnAñadirEquipo.ImageAlign = ContentAlignment.MiddleLeft;
            btnAñadirEquipo.Location = new Point(10, 421);
            btnAñadirEquipo.Name = "btnAñadirEquipo";
            btnAñadirEquipo.Size = new Size(209, 30);
            btnAñadirEquipo.TabIndex = 1;
            btnAñadirEquipo.Text = "Guardar Cambios";
            btnAñadirEquipo.UseVisualStyleBackColor = false;
            btnAñadirEquipo.Click += btnAñadir_Click;
            // 
            // btnEliminarEquipo
            // 
            btnEliminarEquipo.BackColor = Color.FromArgb(0, 115, 138);
            btnEliminarEquipo.Cursor = Cursors.Hand;
            btnEliminarEquipo.FlatAppearance.BorderSize = 0;
            btnEliminarEquipo.FlatStyle = FlatStyle.Flat;
            btnEliminarEquipo.Font = new Font("Segoe UI Semibold", 12F);
            btnEliminarEquipo.ForeColor = Color.FromArgb(248, 249, 250);
            btnEliminarEquipo.Image = Properties.Resources.delete_24dp_FFFFFF_FILL0_wght400_GRAD0_opsz24;
            btnEliminarEquipo.ImageAlign = ContentAlignment.MiddleLeft;
            btnEliminarEquipo.Location = new Point(10, 497);
            btnEliminarEquipo.Name = "btnEliminarEquipo";
            btnEliminarEquipo.Size = new Size(209, 30);
            btnEliminarEquipo.TabIndex = 3;
            btnEliminarEquipo.Text = "Eliminar";
            btnEliminarEquipo.UseVisualStyleBackColor = false;
            btnEliminarEquipo.Click += btnEliminarEquipo_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 18F);
            label1.Location = new Point(356, 21);
            label1.Name = "label1";
            label1.Size = new Size(266, 32);
            label1.TabIndex = 4;
            label1.Text = "REGISTRO DE EQUIPOS";
            label1.Click += label1_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(248, 249, 250);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(panelEdicion);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(dataGridRegistro);
            panel1.Controls.Add(pictureBox1);
            panel1.ForeColor = Color.FromArgb(26, 26, 26);
            panel1.Location = new Point(168, 20);
            panel1.Name = "panel1";
            panel1.Size = new Size(1059, 658);
            panel1.TabIndex = 5;
            panel1.Paint += panel1_Paint;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(952, 0);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(84, 69);
            pictureBox4.TabIndex = 37;
            pictureBox4.TabStop = false;
            // 
            // panelEdicion
            // 
            panelEdicion.Controls.Add(btnLimpiar);
            panelEdicion.Controls.Add(cmbSistema);
            panelEdicion.Controls.Add(txtRam);
            panelEdicion.Controls.Add(txtDisco);
            panelEdicion.Controls.Add(cmbProcesador);
            panelEdicion.Controls.Add(pictureBox2);
            panelEdicion.Controls.Add(lblInformacion);
            panelEdicion.Controls.Add(lblAlertaId);
            panelEdicion.Controls.Add(txtNumeroSerie);
            panelEdicion.Controls.Add(cmbEstado);
            panelEdicion.Controls.Add(btnAñadirEquipo);
            panelEdicion.Controls.Add(cmbMarca);
            panelEdicion.Controls.Add(btnEliminarEquipo);
            panelEdicion.Controls.Add(txtModelo);
            panelEdicion.Controls.Add(cmbCategoria);
            panelEdicion.Location = new Point(826, 88);
            panelEdicion.Name = "panelEdicion";
            panelEdicion.Size = new Size(233, 542);
            panelEdicion.TabIndex = 30;
            panelEdicion.Paint += panelEdicion_Paint;
            // 
            // btnLimpiar
            // 
            btnLimpiar.BackColor = Color.FromArgb(248, 249, 250);
            btnLimpiar.Cursor = Cursors.Hand;
            btnLimpiar.FlatAppearance.BorderSize = 0;
            btnLimpiar.FlatStyle = FlatStyle.Flat;
            btnLimpiar.Font = new Font("Segoe UI Semibold", 12F);
            btnLimpiar.ForeColor = Color.FromArgb(248, 249, 250);
            btnLimpiar.Image = (Image)resources.GetObject("btnLimpiar.Image");
            btnLimpiar.ImageAlign = ContentAlignment.MiddleLeft;
            btnLimpiar.Location = new Point(187, 381);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(32, 30);
            btnLimpiar.TabIndex = 38;
            btnLimpiar.UseVisualStyleBackColor = false;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // cmbSistema
            // 
            cmbSistema.Cursor = Cursors.Hand;
            cmbSistema.Enabled = false;
            cmbSistema.FlatStyle = FlatStyle.Flat;
            cmbSistema.Font = new Font("Segoe UI Semibold", 12F);
            cmbSistema.FormattingEnabled = true;
            cmbSistema.Items.AddRange(new object[] { "Windows 10", "Windows 11", "MacOs" });
            cmbSistema.Location = new Point(12, 290);
            cmbSistema.Name = "cmbSistema";
            cmbSistema.Size = new Size(209, 29);
            cmbSistema.TabIndex = 37;
            cmbSistema.Text = "Sistema Operativo: ";
            cmbSistema.SelectedIndexChanged += cmbSistema_SelectedIndexChanged;
            cmbSistema.KeyDown += cmbSistema_KeyDown;
            // 
            // txtRam
            // 
            txtRam.BorderStyle = BorderStyle.None;
            txtRam.Cursor = Cursors.IBeam;
            txtRam.Font = new Font("Segoe UI Semibold", 12F);
            txtRam.Location = new Point(10, 353);
            txtRam.Name = "txtRam";
            txtRam.PlaceholderText = "Memoria RAM:";
            txtRam.Size = new Size(209, 22);
            txtRam.TabIndex = 36;
            txtRam.KeyDown += txtRam_KeyDown;
            // 
            // txtDisco
            // 
            txtDisco.BorderStyle = BorderStyle.None;
            txtDisco.Cursor = Cursors.IBeam;
            txtDisco.Font = new Font("Segoe UI Semibold", 12F);
            txtDisco.Location = new Point(10, 325);
            txtDisco.Name = "txtDisco";
            txtDisco.PlaceholderText = "Disco Duro:";
            txtDisco.Size = new Size(209, 22);
            txtDisco.TabIndex = 35;
            txtDisco.KeyDown += txtDisco_KeyDown;
            // 
            // cmbProcesador
            // 
            cmbProcesador.Cursor = Cursors.Hand;
            cmbProcesador.Enabled = false;
            cmbProcesador.FlatStyle = FlatStyle.Flat;
            cmbProcesador.Font = new Font("Segoe UI Semibold", 12F);
            cmbProcesador.FormattingEnabled = true;
            cmbProcesador.Items.AddRange(new object[] { "Core i3", "Ryzen 3", "Core i5", "Ryzen 5", "Core i7", "Rysen 7", "Core i9", "Ryzen 9", "M1", "M2", "M3", "M4" });
            cmbProcesador.Location = new Point(13, 255);
            cmbProcesador.Name = "cmbProcesador";
            cmbProcesador.Size = new Size(209, 29);
            cmbProcesador.TabIndex = 34;
            cmbProcesador.Text = "Procesador:";
            cmbProcesador.KeyDown += cmbProcesador_KeyDown;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = SystemColors.Window;
            pictureBox2.BackgroundImage = Properties.Resources.search_24dp_00738A_FILL0_wght400_GRAD0_opsz24;
            pictureBox2.Location = new Point(199, 11);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(23, 22);
            pictureBox2.TabIndex = 33;
            pictureBox2.TabStop = false;
            // 
            // lblInformacion
            // 
            lblInformacion.AutoSize = true;
            lblInformacion.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblInformacion.ForeColor = Color.FromArgb(0, 115, 138);
            lblInformacion.Location = new Point(41, 98);
            lblInformacion.Name = "lblInformacion";
            lblInformacion.Size = new Size(144, 17);
            lblInformacion.TabIndex = 31;
            lblInformacion.Text = "Información del equipo";
            lblInformacion.TextAlign = ContentAlignment.TopCenter;
            // 
            // lblAlertaId
            // 
            lblAlertaId.AutoSize = true;
            lblAlertaId.BackColor = Color.FromArgb(248, 249, 250);
            lblAlertaId.Font = new Font("Segoe UI", 9F);
            lblAlertaId.ForeColor = Color.FromArgb(0, 115, 138);
            lblAlertaId.Location = new Point(10, 36);
            lblAlertaId.Name = "lblAlertaId";
            lblAlertaId.Size = new Size(90, 15);
            lblAlertaId.TabIndex = 30;
            lblAlertaId.Text = "Presione ENTER";
            lblAlertaId.TextAlign = ContentAlignment.TopCenter;
            // 
            // txtNumeroSerie
            // 
            txtNumeroSerie.BorderStyle = BorderStyle.None;
            txtNumeroSerie.Cursor = Cursors.IBeam;
            txtNumeroSerie.Font = new Font("Segoe UI Semibold", 12F);
            txtNumeroSerie.Location = new Point(10, 11);
            txtNumeroSerie.Name = "txtNumeroSerie";
            txtNumeroSerie.PlaceholderText = "Numero de Serie:";
            txtNumeroSerie.Size = new Size(209, 22);
            txtNumeroSerie.TabIndex = 20;
            txtNumeroSerie.TextChanged += txtNumeroSerie_TextChanged;
            // 
            // cmbEstado
            // 
            cmbEstado.Cursor = Cursors.Hand;
            cmbEstado.Enabled = false;
            cmbEstado.FlatStyle = FlatStyle.Flat;
            cmbEstado.Font = new Font("Segoe UI Semibold", 12F);
            cmbEstado.FormattingEnabled = true;
            cmbEstado.Items.AddRange(new object[] { "Nuevo", "Usado", "Desecho" });
            cmbEstado.Location = new Point(13, 220);
            cmbEstado.Name = "cmbEstado";
            cmbEstado.Size = new Size(209, 29);
            cmbEstado.TabIndex = 29;
            cmbEstado.Text = "Estado:";
            cmbEstado.KeyDown += cmbEstado_KeyDown;
            // 
            // cmbMarca
            // 
            cmbMarca.Cursor = Cursors.Hand;
            cmbMarca.Enabled = false;
            cmbMarca.FlatStyle = FlatStyle.Flat;
            cmbMarca.Font = new Font("Segoe UI Semibold", 12F);
            cmbMarca.FormattingEnabled = true;
            cmbMarca.Items.AddRange(new object[] { "Hp", "Dell", "Lenovo", "Acer", "Asus", "Huawei", "Apple" });
            cmbMarca.Location = new Point(13, 185);
            cmbMarca.Name = "cmbMarca";
            cmbMarca.Size = new Size(209, 29);
            cmbMarca.TabIndex = 28;
            cmbMarca.Text = "Marca: ";
            cmbMarca.KeyDown += cmbMarca_KewDown;
            // 
            // txtModelo
            // 
            txtModelo.BorderStyle = BorderStyle.None;
            txtModelo.Cursor = Cursors.IBeam;
            txtModelo.Font = new Font("Segoe UI Semibold", 12F);
            txtModelo.Location = new Point(12, 118);
            txtModelo.Name = "txtModelo";
            txtModelo.PlaceholderText = "Modelo:";
            txtModelo.Size = new Size(209, 22);
            txtModelo.TabIndex = 27;
            txtModelo.KeyDown += txtModelo_KeyDown;
            // 
            // cmbCategoria
            // 
            cmbCategoria.Cursor = Cursors.Hand;
            cmbCategoria.Enabled = false;
            cmbCategoria.FlatStyle = FlatStyle.Flat;
            cmbCategoria.Font = new Font("Segoe UI Semibold", 12F);
            cmbCategoria.FormattingEnabled = true;
            cmbCategoria.Items.AddRange(new object[] { "PC", "Laptop" });
            cmbCategoria.Location = new Point(13, 150);
            cmbCategoria.Name = "cmbCategoria";
            cmbCategoria.Size = new Size(209, 29);
            cmbCategoria.TabIndex = 21;
            cmbCategoria.Text = "Categoría:";
            cmbCategoria.KeyDown += cmbCategoria_KewDown;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Excel2__1_1;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(178, 81);
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // flowLayoutPanel3
            // 
            flowLayoutPanel3.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel3.Location = new Point(0, 680);
            flowLayoutPanel3.Name = "flowLayoutPanel3";
            flowLayoutPanel3.Size = new Size(1227, 18);
            flowLayoutPanel3.TabIndex = 16;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(248, 249, 250);
            panel5.Controls.Add(btnReportes);
            panel5.Controls.Add(label11);
            panel5.Controls.Add(btnProfil);
            panel5.Controls.Add(btnExit);
            panel5.Controls.Add(btnTracking);
            panel5.Controls.Add(btnCrud);
            panel5.Controls.Add(btnHome);
            panel5.Location = new Point(3, 20);
            panel5.Name = "panel5";
            panel5.Size = new Size(162, 658);
            panel5.TabIndex = 31;
            panel5.Paint += panel5_Paint;
            // 
            // btnReportes
            // 
            btnReportes.BackColor = Color.FromArgb(248, 249, 250);
            btnReportes.Cursor = Cursors.Hand;
            btnReportes.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnReportes.FlatAppearance.BorderSize = 2;
            btnReportes.FlatStyle = FlatStyle.Flat;
            btnReportes.Font = new Font("Segoe UI Semibold", 9F);
            btnReportes.ForeColor = Color.Black;
            btnReportes.Image = (Image)resources.GetObject("btnReportes.Image");
            btnReportes.ImageAlign = ContentAlignment.MiddleLeft;
            btnReportes.Location = new Point(19, 253);
            btnReportes.Name = "btnReportes";
            btnReportes.Size = new Size(121, 37);
            btnReportes.TabIndex = 12;
            btnReportes.Text = "Reportes";
            btnReportes.UseVisualStyleBackColor = false;
            btnReportes.Click += btnReportes_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(19, 62);
            label11.Name = "label11";
            label11.Size = new Size(111, 15);
            label11.TabIndex = 6;
            label11.Text = "¡HOLA, INGENIERO!";
            // 
            // btnProfil
            // 
            btnProfil.Cursor = Cursors.Hand;
            btnProfil.FlatAppearance.BorderSize = 0;
            btnProfil.FlatStyle = FlatStyle.Flat;
            btnProfil.Image = Properties.Resources.person_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnProfil.Location = new Point(40, 21);
            btnProfil.Name = "btnProfil";
            btnProfil.Size = new Size(64, 38);
            btnProfil.TabIndex = 10;
            btnProfil.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.FromArgb(248, 249, 250);
            btnExit.Cursor = Cursors.Hand;
            btnExit.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnExit.FlatAppearance.BorderSize = 2;
            btnExit.FlatStyle = FlatStyle.Flat;
            btnExit.Font = new Font("Segoe UI Semibold", 9F);
            btnExit.ForeColor = Color.Black;
            btnExit.Image = (Image)resources.GetObject("btnExit.Image");
            btnExit.ImageAlign = ContentAlignment.MiddleLeft;
            btnExit.Location = new Point(19, 375);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(121, 37);
            btnExit.TabIndex = 3;
            btnExit.Text = "Salir ";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // btnTracking
            // 
            btnTracking.BackColor = Color.FromArgb(248, 249, 250);
            btnTracking.Cursor = Cursors.Hand;
            btnTracking.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnTracking.FlatAppearance.BorderSize = 2;
            btnTracking.FlatStyle = FlatStyle.Flat;
            btnTracking.Font = new Font("Segoe UI Semibold", 9F);
            btnTracking.Image = (Image)resources.GetObject("btnTracking.Image");
            btnTracking.ImageAlign = ContentAlignment.MiddleLeft;
            btnTracking.Location = new Point(20, 200);
            btnTracking.Name = "btnTracking";
            btnTracking.Size = new Size(121, 37);
            btnTracking.TabIndex = 2;
            btnTracking.Text = "Asignación";
            btnTracking.UseVisualStyleBackColor = false;
            btnTracking.Click += btnTracking_Click;
            // 
            // btnCrud
            // 
            btnCrud.BackColor = Color.FromArgb(248, 249, 250);
            btnCrud.Cursor = Cursors.Hand;
            btnCrud.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnCrud.FlatAppearance.BorderSize = 2;
            btnCrud.FlatStyle = FlatStyle.Flat;
            btnCrud.Font = new Font("Segoe UI Semibold", 9F);
            btnCrud.Image = (Image)resources.GetObject("btnCrud.Image");
            btnCrud.ImageAlign = ContentAlignment.MiddleLeft;
            btnCrud.Location = new Point(20, 147);
            btnCrud.Name = "btnCrud";
            btnCrud.Size = new Size(121, 37);
            btnCrud.TabIndex = 1;
            btnCrud.Text = "Añadir";
            btnCrud.UseVisualStyleBackColor = false;
            btnCrud.Click += btnCrud_Click;
            // 
            // btnHome
            // 
            btnHome.BackColor = Color.FromArgb(248, 249, 250);
            btnHome.Cursor = Cursors.Hand;
            btnHome.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnHome.FlatAppearance.BorderSize = 2;
            btnHome.FlatStyle = FlatStyle.Flat;
            btnHome.Font = new Font("Segoe UI Semibold", 9F);
            btnHome.ForeColor = Color.Black;
            btnHome.Image = (Image)resources.GetObject("btnHome.Image");
            btnHome.ImageAlign = ContentAlignment.MiddleLeft;
            btnHome.Location = new Point(19, 99);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(121, 37);
            btnHome.TabIndex = 0;
            btnHome.Text = "Inicio";
            btnHome.UseVisualStyleBackColor = false;
            btnHome.Click += btnHome_Click;
            // 
            // panelPrincipal
            // 
            panelPrincipal.Anchor = AnchorStyles.None;
            panelPrincipal.Controls.Add(flowLayoutPanel1);
            panelPrincipal.Controls.Add(flowLayoutPanel3);
            panelPrincipal.Controls.Add(panel5);
            panelPrincipal.Controls.Add(panel1);
            panelPrincipal.Location = new Point(32, 12);
            panelPrincipal.Name = "panelPrincipal";
            panelPrincipal.Size = new Size(1227, 701);
            panelPrincipal.TabIndex = 32;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel1.Location = new Point(3, 0);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(1227, 19);
            flowLayoutPanel1.TabIndex = 33;
            // 
            // Crud
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1295, 749);
            Controls.Add(panelPrincipal);
            Name = "Crud";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Crud";
            WindowState = FormWindowState.Maximized;
            Load += Crud_Load;
            Resize += Crud_Resize;
            ((System.ComponentModel.ISupportInitialize)dataGridRegistro).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            panelEdicion.ResumeLayout(false);
            panelEdicion.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panelPrincipal.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridRegistro;
        private Button btnAñadirEquipo;
        private Button btnEliminarEquipo;
        private Label label1;
        private Panel panel1;
        private PictureBox pictureBox1;
        private FlowLayoutPanel flowLayoutPanel1;
        private FlowLayoutPanel flowLayoutPanel3;
        private Panel panel5;
        private Label label11;
        private Button btnProfil;
        private Button btnExit;
        private Button btnTracking;
        private Button btnCrud;
        private Button btnHome;
        private Button btnReportes;
        private ComboBox cmbEstado;
        private ComboBox cmbMarca;
        private TextBox txtModelo;
        private TextBox txtNumeroSerie;
        private ComboBox cmbCategoria;
        private Panel panelEdicion;
        private Label lblAlertaId;
        private Label lblInformacion;
        private PictureBox pictureBox2;
        private Panel panelPrincipal;
        private ComboBox cmb;
        private TextBox textBox2;
        private TextBox textBox1;
        private TextBox txtRam;
        private TextBox txtDisco;
        private ComboBox cmbProcesador;
        private ComboBox cmbSistema;
        private PictureBox pictureBox4;
        private Button button1;
        private Button btnLimpiar;
    }
}