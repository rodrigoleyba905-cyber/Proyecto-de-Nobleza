﻿using FormNobleza.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FormNobleza.Models;
using ZstdSharp.Unsafe;
namespace FormNobleza
{
    public partial class Crud : Form
    {
        private readonly HardwareRepository _hardwareRepository = new HardwareRepository();
        // Esta variable va a vivir en la RAM mientras la pantalla esté abierta

        private bool _esModoEdicion = false;
        private Hardware _equipoActual = null;
        private bool _busquedaSinResultados = false;


        // Mapeo texto del ComboBox → idCategoria en BD
        // Orden: índice 0 = "PC" = id 1, índice 1 = "Laptop" = id 2
        // Ajusta los IDs según tus inserts en categorias/marcas/estados
        private readonly int[] _idsCategoria = { 1, 2 };           // PC, Laptop
        private readonly int[] _idsMarca = { 1, 2, 3, 4, 5, 6, 7 };  // Hp, Dell, Lenovo, Acer, Asus
        private readonly int[] _idsEstado = { 1, 2, 3 };        // Disponible, Sistemas, Desecho
        private readonly int[] _idsProcesador = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };
        private readonly int[] _idsSistema = { 1, 2, 3 };


        public Crud()
        {
            InitializeComponent();
            CentrarPanel();
            ConfigurarInterfazInicial();
            txtNumeroSerie.KeyDown += txtNumeroSerie_KeyDown;
            AplicarEstiloCorporativoGrid();

            txtModelo.Enabled = false;
            cmbCategoria.Enabled = false;
            cmbMarca.Enabled = false;
            cmbEstado.Enabled = false;
            cmbProcesador.Enabled = false;
            txtDisco.Enabled = false;
            txtRam.Enabled = false;
            lblAlertaId.Enabled = true;

            lblInformacion.Enabled = true;

        }
        private void CentrarPanel()
        {
            // Verificamos que el panel exista y tenga un padre asignado
            if (panelPrincipal != null && panelPrincipal.Parent != null)
            {
                // Calculamos usando el tamaño del PADRE (ya sea el Formulario o panel1)
                int centroX = (panelPrincipal.Parent.ClientSize.Width - panelPrincipal.Width) / 2;
                int centroY = (panelPrincipal.Parent.ClientSize.Height - panelPrincipal.Height) / 2;

                panelPrincipal.Location = new Point(centroX, centroY);
            }
        }

        private void LimpiarFormulario()
        {
            // 1. Limpiamos todos los campos de texto
            txtNumeroSerie.Clear();
            txtModelo.Clear();
            txtDisco.Clear();
            txtRam.Clear();

            // 2. Limpiamos los ComboBox usando la misma instrucción que te funciona en el KeyDown
            cmbCategoria.SelectedIndex = -1;
            cmbMarca.SelectedIndex = -1;
            cmbEstado.SelectedIndex = -1;
            cmbProcesador.SelectedIndex = -1;
            cmbSistema.SelectedIndex = -1;



            // 3. Reiniciamos tus variables de control a su estado por defecto
            _equipoActual = null;
            _esModoEdicion = false;
            _busquedaSinResultados = true;

            // 4. Restauramos etiquetas y botones
            lblAlertaId.Visible = false;
            btnAñadirEquipo.Text = "Guardar Equipo";
            btnAñadirEquipo.Enabled = true;
            btnEliminarEquipo.Enabled = false;

            // 5. Bloqueamos los campos de captura (se desbloquean hasta el KeyDown del número de serie)
            txtModelo.Enabled = false;
            cmbCategoria.Enabled = false;
            cmbMarca.Enabled = false;
            cmbEstado.Enabled = false;
            cmbProcesador.Enabled = false;
            cmbSistema.Enabled = false;
            txtDisco.Enabled = false;
            txtRam.Enabled = false;

            // 6. Limpiamos el DataGrid de forma optimizada, tal como en tu validación
            dataGridRegistro.DataSource = new List<Hardware>();
            dataGridRegistro.ColumnHeadersVisible = false;
            dataGridRegistro.Invalidate(); // Llama al texto gris de fondo

            // 7. Devolvemos el control total al primer campo
            txtNumeroSerie.Enabled = true;
            txtNumeroSerie.Focus();
            lblAlertaId.Enabled = true;

        }
        private void Crud_Resize(object sender, EventArgs e)
        {
            CentrarPanel();
        }


        ///<summary>
        ///Establecemos el estado estático de los controles del formulario y bloque la edicion
        ///</summary>
        ///
        private void txtNumeroSerie_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter) return;
            e.SuppressKeyPress = true; // Evita el sonido molesto del "ding" de Windows

            if (string.IsNullOrWhiteSpace(txtNumeroSerie.Text))
            {
                MessageBox.Show("Ingresa un número de serie.", "Campo Vacío",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string serie = txtNumeroSerie.Text.Trim();
                bool existe = _hardwareRepository.ExisteNumeroSerie(serie);

                // Desbloquear siempre después de validar
                txtNumeroSerie.Enabled = true;
                txtModelo.Enabled = true;
                cmbCategoria.Enabled = true;
                cmbMarca.Enabled = true;
                cmbEstado.Enabled = true;
                cmbProcesador.Enabled = true;
                cmbSistema.Enabled = true;
                txtDisco.Enabled = true;
                txtRam.Enabled = true;
                txtRam.Enabled = true;

                if (existe)
                {
                    _equipoActual = _hardwareRepository.BuscarPorNumeroSerie(serie);
                    _esModoEdicion = true;
                    _busquedaSinResultados = true;


                    btnLimpiar.Visible = false;
                    lblAlertaId.Text = "Número de serie existente";
                    lblAlertaId.ForeColor = Color.RoyalBlue;
                    lblAlertaId.Visible = true;

                    // --- LLENAMOS TODOS LOS CAMPOS ---
                    txtModelo.Text = _equipoActual.modelo;
                    cmbCategoria.SelectedIndex = IndexDeId(_idsCategoria, _equipoActual.idCategoria);
                    cmbMarca.SelectedIndex = IndexDeId(_idsMarca, _equipoActual.idMarca);
                    cmbEstado.SelectedIndex = IndexDeId(_idsEstado, _equipoActual.idEstado);
                    cmbProcesador.SelectedIndex = IndexDeId(_idsProcesador, _equipoActual.idProcesador);
                    cmbSistema.SelectedIndex = IndexDeId(_idsSistema, _equipoActual.idSistema);
                    txtDisco.Text = _equipoActual.disco;
                    txtRam.Text = _equipoActual.ram;

                    // Limpieza de duplicados: Solo lo dejamos una vez
                    btnAñadirEquipo.Text = "Guardar Cambios";
                    btnAñadirEquipo.Enabled = true;
                    btnEliminarEquipo.Enabled = true;

                    // Vamos por el formato visual del equipo y lo pintamos en la tabla
                    var resultadoUnico = _hardwareRepository.BuscarUnicoParaGrid(serie);
                    dataGridRegistro.DataSource = resultadoUnico;

                    if (dataGridRegistro.Columns.Count > 0)
                    {
                        // Pintamos los títulos bonitos de los textos
                        dataGridRegistro.Columns["numeroSerie"].HeaderText = "Número de Serie";
                        dataGridRegistro.Columns["modelo"].HeaderText = "Modelo";
                        dataGridRegistro.Columns["Categoria"].HeaderText = "Categoría";
                        dataGridRegistro.Columns["Marca"].HeaderText = "Marca";
                        dataGridRegistro.Columns["Estado"].HeaderText = "Estado Físico";
                        dataGridRegistro.Columns["Procesador"].HeaderText = "Procesador";
                        dataGridRegistro.Columns["Sistema"].HeaderText = "Sistema Operativo";
                        dataGridRegistro.Columns["disco"].HeaderText = "Disco Duro";
                        dataGridRegistro.Columns["ram"].HeaderText = " RAM";
                        dataGridRegistro.Columns["fechaCreacion"].HeaderText = "Fecha de Registro";

                        // Apagamos los IDs para que el usuario no vea los números
                        dataGridRegistro.Columns["idHardware"].Visible = false;
                        dataGridRegistro.Columns["idProcesador"].Visible = false;
                        dataGridRegistro.Columns["idSistema"].Visible = false;

                        dataGridRegistro.Columns["idCategoria"].Visible = false;
                        dataGridRegistro.Columns["idMarca"].Visible = false;
                        dataGridRegistro.Columns["idEstado"].Visible = false;
                    }
                }
                else
                {
                    dataGridRegistro.DataSource = null;
                    dataGridRegistro.Rows.Clear();
                    dataGridRegistro.ColumnHeadersVisible = false;
                    dataGridRegistro.Invalidate(); // ¡Llama al texto gris!

                    _equipoActual = null;
                    _esModoEdicion = false;
                    dataGridRegistro.Columns.Clear();
                    _busquedaSinResultados = true;

                    lblAlertaId.Text = "Número de serie nuevo";
                    lblAlertaId.ForeColor = Color.RoyalBlue;
                    lblAlertaId.Visible = true;

                    // --- LIMPIAMOS TODOS LOS CAMPOS ---
                    txtModelo.Clear();
                    cmbCategoria.SelectedIndex = -1;
                    cmbMarca.SelectedIndex = -1;
                    cmbEstado.SelectedIndex = -1;
                    cmbProcesador.SelectedIndex = -1;
                    cmbSistema.SelectedIndex = -1;
                    txtDisco.Clear();
                    txtRam.Clear();

                    // Limpieza de duplicados
                    btnAñadirEquipo.Text = "Guardar Equipo";
                    btnAñadirEquipo.Enabled = true;
                    btnEliminarEquipo.Enabled = false;

                    // Limpiamos el grid dejándolo vacío
                    dataGridRegistro.DataSource = null;
                    dataGridRegistro.Rows.Clear();

                    // Esto dispara el evento Paint automáticamente en el fondo sin darte errores
                    dataGridRegistro.Invalidate();
                    dataGridRegistro.DataSource = new List<Hardware>();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al consultar:\n" + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ConfigurarInterfazInicial()
        {
            {

                //Bloqueamos todo, excepto el numeroSerie
                btnEliminarEquipo.Enabled = false;
                btnAñadirEquipo.Enabled = false;


                // Habilitamos los combos para alta nueva también
                cmbCategoria.Enabled = true;
                cmbMarca.Enabled = true;
                cmbEstado.Enabled = true;
            }

        }

        private void btnHome_Click(object sender, EventArgs e)
        {

            Menu pantallaDashboard = new Menu();
            pantallaDashboard.FormClosed += (s, args) => this.Close();
            pantallaDashboard.Show();


            this.Hide(); // Oculta el login
        }

        private void btnCrud_Click(object sender, EventArgs e)
        {

            Crud pantallaDashboard = new Crud();
            pantallaDashboard.FormClosed += (s, args) => this.Close();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnTracking_Click(object sender, EventArgs e)
        {

            Tracking pantallaDashboard = new Tracking();
            pantallaDashboard.FormClosed += (s, args) => this.Close();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult confirmacion = MessageBox.Show("¿Estás seguro de que deseas salir del sistema?", "Confirmar salida",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
            );

            // 2. Evaluamos qué botón presionó el usuario
            if (confirmacion == DialogResult.Yes)
            {
                FormLogin pantallaDashboard = new FormLogin();
                pantallaDashboard.FormClosed += (s, args) => this.Close();
                pantallaDashboard.Show();

                this.Hide(); // Oculta el login
            }
        }
        private void btnReportes_Click(object sender, EventArgs e)
        {
            Reportes pantallaDashboard = new Reportes();
            pantallaDashboard.FormClosed += (s, args) => this.Close();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnAñadir_Click(object sender, EventArgs e)
        {


            if (string.IsNullOrWhiteSpace(txtModelo.Text))
            {
                MessageBox.Show("El campo Modelo es obligatorio.", "Campo Vacío", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Añadimos la validación para los nuevos combos
            if (cmbCategoria.SelectedIndex < 0 || cmbMarca.SelectedIndex < 0 || cmbEstado.SelectedIndex < 0 ||
                cmbProcesador.SelectedIndex < 0 || cmbSistema.SelectedIndex < 0 || string.IsNullOrWhiteSpace(txtDisco.Text) || string.IsNullOrWhiteSpace(txtRam.Text))
            {
                MessageBox.Show("Selecciona Categoría, Marca, Estado, Procesador, Sistema, Disco Duro y Memoria RAM.", "Campos incompletos",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                int idCategoria = _idsCategoria[cmbCategoria.SelectedIndex];
                int idMarca = _idsMarca[cmbMarca.SelectedIndex];
                int idEstado = _idsEstado[cmbEstado.SelectedIndex]; // 3 = Desecho

                // CAPTURAMOS LOS NUEVOS DATOS
                int idProcesador = _idsProcesador[cmbProcesador.SelectedIndex];
                int idSistema = _idsSistema[cmbSistema.SelectedIndex];
                string disco = txtDisco.Text.Trim();
                string ram = txtRam.Text.Trim();

                int idUsuario = UsuarioSesion.IdUsuario;

                if (_esModoEdicion)
                {
                    // 1. Asignamos primero los valores actualizados de la pantalla al objeto
                    _equipoActual.numeroSerie = txtNumeroSerie.Text.Trim();
                    _equipoActual.modelo = txtModelo.Text.Trim();
                    _equipoActual.idCategoria = idCategoria;
                    _equipoActual.idMarca = idMarca;
                    _equipoActual.idEstado = idEstado;
                    _equipoActual.idProcesador = idProcesador;
                    _equipoActual.idSistema = idSistema;
                    _equipoActual.disco = disco;
                    _equipoActual.ram = ram;

                    if (idEstado == 3) // Dar de baja / Desecho
                    {
                        bool exitoBaja = _hardwareRepository.DarDeBajaDefinitiva(_equipoActual.numeroSerie, idEstado, idUsuario);
                        if (exitoBaja)
                        {
                            MessageBox.Show("El equipo ha sido dado de baja definitivamente.\nCualquier asignación activa fue cerrada automáticamente.",
                                            "Baja Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            RefrescarModulo();
                        }
                    }
                    else
                    {
                        // 2. Ejecutamos la actualización con los datos ya asignados
                        _hardwareRepository.Actualizar(_equipoActual);
                        MessageBox.Show("Equipo actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        RefrescarModulo();
                    }
                }
            
                else
                {
                    // ARMAMOS EL NUEVO OBJETO CON LOS NUEVOS CAMPOS
                    var nuevoHw = new Hardware
                    {
                        numeroSerie = txtNumeroSerie.Text.Trim(),
                        modelo = txtModelo.Text.Trim(),
                        idCategoria = idCategoria,
                        idMarca = idMarca,
                        idEstado = idEstado,

                        idProcesador = idProcesador,
                        idSistema = idSistema,
                        disco = disco,
                        ram = ram,

                    };

                    _hardwareRepository.Insertar(nuevoHw);
                    MessageBox.Show("Equipo registrado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                LimpiarFormulario();

                LimpiarPanel();
                lblAlertaId.Text = "Presione ENTER";
                lblAlertaId.ForeColor = Color.RoyalBlue;
                lblAlertaId.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




        private void btnEliminarEquipo_Click(object sender, EventArgs e)
        {
            if (_equipoActual == null) return;

            var confirmacion = MessageBox.Show(
                $"¿Deseas ELIMINAR el equipo '{_equipoActual.numeroSerie}' del sistema?\nÚsalo solo si fue un error de captura.",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirmacion != DialogResult.Yes) return;

            try
            {
                _hardwareRepository.Eliminar(_equipoActual.idHardware);
                MessageBox.Show("Equipo eliminado del sistema.", "Eliminado",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                RefrescarModulo();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar:\n" + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                RefrescarModulo();
            }
        }

        // Devuelve el índice en el array dado un id de BD
        private int IndexDeId(int[] ids, int idBuscado)
        {
            for (int i = 0; i < ids.Length; i++)
                if (ids[i] == idBuscado) return i;
            return 0;
        }

        // Limpia el panel de edición y resetea el estado
        private void LimpiarPanel()
        {
            txtNumeroSerie.Clear();
            txtNumeroSerie.Enabled = true;  // listo para nueva validación

            txtModelo.Clear();
            txtModelo.Enabled = false;
            cmbCategoria.Enabled = false;
            cmbMarca.Enabled = false;
            cmbEstado.Enabled = false;

            cmbCategoria.SelectedIndex = 0;
            cmbMarca.SelectedIndex = 0;
            cmbEstado.SelectedIndex = 0;

            lblAlertaId.Visible = false;
            btnAñadirEquipo.Enabled = false;
            btnEliminarEquipo.Enabled = false;
            btnAñadirEquipo.Text = "Guardar Equipo";
            _equipoActual = null;
            _esModoEdicion = false;

            txtNumeroSerie.Focus(); // foco directo al campo de serie
        }
        private void AplicarEstiloCorporativoGrid()
        {
            // Apagar el estilo por defecto para que deje pintar tus colores
            dataGridRegistro.EnableHeadersVisualStyles = false;

            // ENCABEZADOS 
            dataGridRegistro.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#00479A");
            dataGridRegistro.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            // Usamos Arial directo, en negritas para que el título resalte
            dataGridRegistro.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dataGridRegistro.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridRegistro.ColumnHeadersHeight = 35;

            //(Filas)
            dataGridRegistro.DefaultCellStyle.BackColor = ColorTranslator.FromHtml("#00738A");
            dataGridRegistro.DefaultCellStyle.ForeColor = Color.White;
            // Usamos Arial regular para la lectura de los datos
            dataGridRegistro.DefaultCellStyle.Font = new Font("Arial", 9);

            //FILAS ALTERNADAS (Efecto cebra)
            dataGridRegistro.AlternatingRowsDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#006579");

            //SELECCIÓN (Cuando le das clic a un equipo)
            // Mantenemos tu azul oscuro para que se note claramente qué fila agarraste
            dataGridRegistro.DefaultCellStyle.SelectionBackColor = ColorTranslator.FromHtml("#002B5E");
            dataGridRegistro.DefaultCellStyle.SelectionForeColor = Color.White;

            // BORDES Y APARIENCIA GENERAL
            dataGridRegistro.BorderStyle = BorderStyle.None;
            dataGridRegistro.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            // Cambié el borde de la celda a un gris muy claro para que la línea blanca pura no "deslumbre"
            dataGridRegistro.GridColor = Color.LightGray;

            // Ocultar la columna de la flechita izquierda y autoajustar el tamaño
            dataGridRegistro.RowHeadersVisible = false;
            dataGridRegistro.AllowUserToResizeRows = false;
            // Esto permite seleccionar celdas individuales en lugar de toda la fila
            dataGridRegistro.SelectionMode = DataGridViewSelectionMode.CellSelect;
            // Esto habilita la copia nativa con Ctrl+C
            dataGridRegistro.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            // Reemplaza el Fill por esto:
            dataGridRegistro.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dataGridRegistro.AllowUserToResizeColumns = true;
        }

        private void txtModelo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // Silencia el "Ding" de Windows

                // Ponemos el cursor a parpadear en la caja de la contraseña
                cmbCategoria.Focus();
            }
        }

        private void cmbCategoria_KewDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // Silencia el "Ding" de Windows

                // Ponemos el cursor a parpadear en la caja de la contraseña
                cmbMarca.Focus();
            }
        }
        private void cmbMarca_KewDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // Silencia el "Ding" de Windows

                cmbEstado.Focus();
            }
        }
        private void cmbEstado_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // Silencia el "Ding" de Windows

                cmbProcesador.Focus();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Crud_Load(object sender, EventArgs e)

        {

        }


        private void txtNumeroSerie_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridRegistro_Paint(object sender, PaintEventArgs e)
        {
            if (dataGridRegistro.Rows.Count > 0)
            {
                return;
            }
            if (_busquedaSinResultados)
            {
                string mensaje = "EQUIPO NUEVO\nInserte los valores";

                Font fuente = new Font("Arial", 14, FontStyle.Bold);
                Brush brocha = new SolidBrush(Color.LightSlateGray);

                StringFormat formato = new StringFormat();
                formato.Alignment = StringAlignment.Center;
                formato.LineAlignment = StringAlignment.Center;

                Rectangle area = new Rectangle(0, 0, dataGridRegistro.Width, dataGridRegistro.Height);

                e.Graphics.DrawString(mensaje, fuente, brocha, area, formato);
            }
            else
            {
                string mensaje = "\nDIGITE UN NUMERO DE SERIE";

                Font fuente = new Font("Arial", 14, FontStyle.Bold);
                Brush brocha = new SolidBrush(Color.LightSlateGray);

                StringFormat formato = new StringFormat();
                formato.Alignment = StringAlignment.Center;
                formato.LineAlignment = StringAlignment.Center;

                Rectangle area = new Rectangle(0, 0, dataGridRegistro.Width, dataGridRegistro.Height);

                e.Graphics.DrawString(mensaje, fuente, brocha, area, formato);
            }
        }


        private void cmbSistema_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void panelEdicion_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }



        private void btnLimpiar_Click(object sender, EventArgs e)
        {

            RefrescarModulo();
        }
        private void RefrescarModulo()
        {
            Crud pantallaDashboard = new Crud();
            pantallaDashboard.Show();
            this.Hide();
            txtNumeroSerie.Focus();
        }

        private void cmbProcesador_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // Silencia el "Ding" de Windows

                cmbSistema.Focus();
            }
        }

        private void cmbSistema_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // Silencia el "Ding" de Windows

                txtDisco.Focus();
            }
        }


        private void txtDisco_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // Silencia el "Ding" de Windows
                txtRam.Focus();
            }
        }


        private void txtRam_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // Silencia el "Ding" de Windows

                btnAñadirEquipo.PerformClick();
            }
        }

        
    }
}
