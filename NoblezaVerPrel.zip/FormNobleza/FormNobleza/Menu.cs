﻿using FormNobleza.Data;
using FormNobleza.Data; 
using FormNobleza.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace FormNobleza
{
    public partial class Menu : Form
    {
        private readonly MenuRepository _menuRepo = new MenuRepository();
        private readonly HardwareRepository _hardwareRepository;
        private List<Hardware> _inventarioGlobal = new List<Hardware>();

        private bool _busquedaSinResultados = true;

        // Esta variable guardará todo el inventario fusionado en la memoria de la PC
        private DataTable _tablaInventario;


        public Menu()
        {
            InitializeComponent();
            CentrarPanel();
            AplicarEstiloCorporativoGrid();
            _hardwareRepository = new HardwareRepository();
        }

        private void btnCrud_Click(object sender, EventArgs e)
        {

            Crud pantallaDashboard = new Crud();
            pantallaDashboard.FormClosed += (s, args) => this.Close();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnHome_Click(object sender, EventArgs e)
        {

            Menu pantallaDashboard = new Menu();
            pantallaDashboard.FormClosed += (s, args) => this.Close();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnTracking_Click(object sender, EventArgs e)
        {

            Tracking pantallaDashboard = new Tracking();
            pantallaDashboard.FormClosed += (s, args) => this.Close();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnExit_Click(object sender, EventArgs e)

        {
            DialogResult confirmacion = MessageBox.Show("¿Estás seguro de que deseas salir del sistema?", "Confirmar salida",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
            );

            // 2. Evaluamos qué botón presionó el usuario
            if (confirmacion == DialogResult.Yes)
            {
                FormLogin pantallaDashboard = new FormLogin();
                pantallaDashboard.FormClosed += (s, args) => this.Close();
                pantallaDashboard.Show();
                

                this.Hide(); // Oculta el login
            }
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {

            Reportes pantallaDashboard = new Reportes();
            pantallaDashboard.FormClosed += (s, args) => this.Close();
            pantallaDashboard.Show();

            this.Hide(); 
        }

        private void txtRastreoId_KeyDown(object sender, KeyEventArgs e)
        {
            //La tecla presionada fue ENTER?
            if (e.KeyCode == Keys.Enter)
            {

                e.SuppressKeyPress = true; //Sonido suprimido
            }
        }


        private void txtBuscador_TextChanged(object sender, EventArgs e)
        {
            // Protección por si la tabla aún no se ha cargado en memoria
            if (_tablaInventario == null) return;

            // Limpiamos el texto que escribió el usuario
            string busqueda = txtBuscador.Text.Trim().Replace("'", "''");

            // Si la caja está vacía, borramos cualquier filtro para mostrar todo otra vez
            if (string.IsNullOrWhiteSpace(busqueda))
            {
                _tablaInventario.DefaultView.RowFilter = "";
                return;
            }

            try
            {
                List<string> filtros = new List<string>();

                // Recorremos TODAS las columnas que tenga tu tabla actualmente
                foreach (DataColumn columna in _tablaInventario.Columns)
                {
                    // Generamos la regla para cada columna usando su nombre real exacto
                    filtros.Add($"Convert([{columna.ColumnName}], 'System.String') LIKE '%{busqueda}%'");
                }

                // Juntamos todas las reglas separadas por la palabra " OR "
                _tablaInventario.DefaultView.RowFilter = string.Join(" OR ", filtros);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en filtro: " + ex.Message, "Debug", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void AplicarEstiloCorporativoGrid()
        {
            // Apagar el estilo por defecto para que deje pintar tus colores
            dgvMenuPrincipal.EnableHeadersVisualStyles = false;

            // (Títulos)
            dgvMenuPrincipal.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#00479A");
            dgvMenuPrincipal.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            // Usamos Arial directo, en negritas 
            dgvMenuPrincipal.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgvMenuPrincipal.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dgvMenuPrincipal.ColumnHeadersHeight = 35;

            // (Filas)
            dgvMenuPrincipal.DefaultCellStyle.BackColor = ColorTranslator.FromHtml("#00738A");
            dgvMenuPrincipal.DefaultCellStyle.ForeColor = Color.White;
            // Usamos Arial regular para la lectura de los datos
            dgvMenuPrincipal.DefaultCellStyle.Font = new Font("Arial", 9);

            // FILAS ALTERNADAS 
            dgvMenuPrincipal.AlternatingRowsDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#006579");

            // SELECCIÓN 
            dgvMenuPrincipal.DefaultCellStyle.SelectionBackColor = ColorTranslator.FromHtml("#002B5E");
            dgvMenuPrincipal.DefaultCellStyle.SelectionForeColor = Color.White;

            //  BORDES
            dgvMenuPrincipal.BorderStyle = BorderStyle.None;
            dgvMenuPrincipal.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvMenuPrincipal.GridColor = Color.LightGray;

            dgvMenuPrincipal.RowHeadersVisible = false;
            dgvMenuPrincipal.AllowUserToResizeRows = false;
            // Esto permite seleccionar celdas individuales en lugar de toda la fila
            dgvMenuPrincipal.SelectionMode = DataGridViewSelectionMode.CellSelect;
            // Esto habilita la copia nativa con Ctrl+C
            dgvMenuPrincipal.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            // Reemplaza el Fill por esto:
            dgvMenuPrincipal.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dgvMenuPrincipal.AllowUserToResizeColumns = true;
        }


        private void Menu_Load(object sender, EventArgs e)
        {
            try
            {
                // Traemos la súper tabla fusionada una sola vez
                _tablaInventario = _hardwareRepository.ObtenerTodos();

                // La conectamos al Grid
                dgvMenuPrincipal.DataSource = _tablaInventario;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar el inventario: " + ex.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void CargarInventarioPrincipal()
        {
            try
            {
                dgvMenuPrincipal.DataSource = _hardwareRepository.ObtenerTodos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error de Carga", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvMenuPrincipal_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void CentrarPanel()
        {
            // Verificamos que el panel exista y tenga un padre asignado
            if (panelPrincipal != null && panelPrincipal.Parent != null)
            {
                // Calculamos usando el tamaño del PADRE (ya sea el Formulario o panel1)
                int centroX = (panelPrincipal.Parent.ClientSize.Width - panelPrincipal.Width) / 2;
                int centroY = (panelPrincipal.Parent.ClientSize.Height - panelPrincipal.Height) / 2;

                panelPrincipal.Location = new Point(centroX, centroY);
            }
        }

        private void panelPrincipal_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Menu_Resize(object sender, EventArgs e)
        {
            CentrarPanel();
        }

        private void ReportesGrid_Paint(object sender, PaintEventArgs e)

        {
            if (_busquedaSinResultados)
            {
                string mensaje = "DIGITE UN NÚMERO DE SERIE";

                Font fuente = new Font("Arial", 14, FontStyle.Bold);
                Brush brocha = new SolidBrush(Color.LightSlateGray);

                StringFormat formato = new StringFormat();
                formato.Alignment = StringAlignment.Center;
                formato.LineAlignment = StringAlignment.Center;

                Rectangle area = new Rectangle(0, 0, dgvMenuPrincipal.Width, dgvMenuPrincipal.Height);

                e.Graphics.DrawString(mensaje, fuente, brocha, area, formato);
            }
        }

        private void flowLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}


    

