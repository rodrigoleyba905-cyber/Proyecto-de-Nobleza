﻿using System;
using System.Data;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextFont = iTextSharp.text.Font;

namespace FormNobleza.Services
{
    public class GeneradorReportesPDF
    {
        // 1. AÑADIMOS 'string fechaCreacion' A LOS PARÁMETROS
        public void ExportarHistorialAPdf(string rutaArchivo, string numeroSerie, string procesador, string ram, string disco, string sistema, string fechaCreacion, DataTable datosHistorial)
        {
            Document documento = new Document(PageSize.A4, 42, 42, 42, 42);

            try
            {
                PdfWriter writer = PdfWriter.GetInstance(documento, new FileStream(rutaArchivo, FileMode.Create));
                documento.Open();

                BaseColor azulCorporativo = new BaseColor(18, 30, 49);
                BaseColor grisCebra = new BaseColor(245, 245, 245);
                BaseColor textoNegro = new BaseColor(40, 40, 40);

                iTextFont fuenteTitulo = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 18f, azulCorporativo);
                iTextFont fuenteSubtitulo = FontFactory.GetFont(FontFactory.HELVETICA, 9f, BaseColor.GRAY);
                iTextFont fuenteHeaderTabla = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 9f, BaseColor.WHITE);
                iTextFont fuenteCeldaNormal = FontFactory.GetFont(FontFactory.HELVETICA, 9f, textoNegro);
                iTextFont fuenteCeldaNegrita = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 9f, azulCorporativo);

                Paragraph titulo = new Paragraph("HISTORIAL Y TRAZABILIDAD DE HARDWARE", fuenteTitulo);
                titulo.Alignment = Element.ALIGN_LEFT;
                documento.Add(titulo);

                Paragraph subtitulo = new Paragraph($"Reporte oficial emitido el: {DateTime.Now:dd/MM/yyyy HH:mm} | TrackPc", fuenteSubtitulo);
                subtitulo.SpacingAfter = 20f;
                documento.Add(subtitulo);

                PdfPTable tablaMeta = new PdfPTable(2);
                tablaMeta.WidthPercentage = 100;
                tablaMeta.SetWidths(new float[] { 30f, 70f });
                tablaMeta.SpacingAfter = 20f;

                AgregarFilaMeta(tablaMeta, "NÚMERO DE SERIE:", fuenteCeldaNegrita);
                AgregarFilaMeta(tablaMeta, numeroSerie, fuenteCeldaNormal);

                AgregarFilaMeta(tablaMeta, "PROCESADOR:", fuenteCeldaNegrita);
                AgregarFilaMeta(tablaMeta, procesador, fuenteCeldaNormal);

                AgregarFilaMeta(tablaMeta, "MEMORIA RAM:", fuenteCeldaNegrita);
                AgregarFilaMeta(tablaMeta, ram, fuenteCeldaNormal);

                AgregarFilaMeta(tablaMeta, "ALMACENAMIENTO:", fuenteCeldaNegrita);
                AgregarFilaMeta(tablaMeta, disco, fuenteCeldaNormal);

                AgregarFilaMeta(tablaMeta, "SISTEMA OPERATIVO:", fuenteCeldaNegrita);
                AgregarFilaMeta(tablaMeta, sistema, fuenteCeldaNormal);

                AgregarFilaMeta(tablaMeta, "FECHA DE ALTA:", fuenteCeldaNegrita);
                AgregarFilaMeta(tablaMeta, fechaCreacion, fuenteCeldaNormal);

                AgregarFilaMeta(tablaMeta, "MOVIMIENTOS REGISTRADOS:", fuenteCeldaNegrita);
                AgregarFilaMeta(tablaMeta, datosHistorial.Rows.Count.ToString(), fuenteCeldaNormal);

                documento.Add(tablaMeta);

                PdfPTable tablaDatos = new PdfPTable(6);
                tablaDatos.WidthPercentage = 100;
                tablaDatos.SetWidths(new float[] { 15f, 13f, 22f, 10f, 13f, 27f });

                string[] encabezados = { "FECHA", "NOMBRE DEL EQUIPO", "RESPONSABLE", "NAVE", "ESTADO", "COMENTARIOS" };
                foreach (string header in encabezados)
                {
                    PdfPCell celdaHeader = new PdfPCell(new Phrase(header, fuenteHeaderTabla));
                    celdaHeader.BackgroundColor = azulCorporativo;
                    celdaHeader.HorizontalAlignment = Element.ALIGN_CENTER;
                    celdaHeader.Padding = 8f;
                    celdaHeader.Border = PdfPCell.NO_BORDER;
                    tablaDatos.AddCell(celdaHeader);
                }

                bool intercalarColor = false;
                foreach (DataRow fila in datosHistorial.Rows)
                {
                    BaseColor fondoActual = intercalarColor ? grisCebra : BaseColor.WHITE;

                    DateTime fechaOriginal = Convert.ToDateTime(fila["fecha"]);
                    string fechaFormateada = fechaOriginal.ToString("dd/MM/yyyy");

                    string idTrab = fila["nombreEquipo"]?.ToString() ?? "";
                    string nombreTrab = fila["nombreTrabajador"]?.ToString() ?? "";
                    string nave = fila["nave"]?.ToString() ?? "";
                    string estado = fila["estado"]?.ToString() ?? "";
                    string comentarios = fila["comentarios"]?.ToString() ?? "";

                    tablaDatos.AddCell(CrearCelda(fechaFormateada, fuenteCeldaNormal, fondoActual, Element.ALIGN_CENTER));
                    tablaDatos.AddCell(CrearCelda(idTrab, fuenteCeldaNormal, fondoActual, Element.ALIGN_CENTER));
                    tablaDatos.AddCell(CrearCelda(nombreTrab, fuenteCeldaNormal, fondoActual, Element.ALIGN_LEFT));
                    tablaDatos.AddCell(CrearCelda(nave, fuenteCeldaNormal, fondoActual, Element.ALIGN_CENTER));
                    tablaDatos.AddCell(CrearCelda(estado, fuenteCeldaNormal, fondoActual, Element.ALIGN_CENTER));
                    tablaDatos.AddCell(CrearCelda(comentarios, fuenteCeldaNormal, fondoActual, Element.ALIGN_LEFT));

                    intercalarColor = !intercalarColor;
                }

                documento.Add(tablaDatos);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al estructurar los vectores del PDF: " + ex.Message);
            }
            finally
            {
                if (documento.IsOpen()) documento.Close();
            }
        }

        private void AgregarFilaMeta(PdfPTable tabla, string texto, iTextFont fuente)
        {
            PdfPCell celda = new PdfPCell(new Phrase(texto, fuente));
            celda.Padding = 5f;
            celda.Border = PdfPCell.BOTTOM_BORDER;
            celda.BorderColorBottom = BaseColor.LIGHT_GRAY;
            tabla.AddCell(celda);
        }

        private PdfPCell CrearCelda(string texto, iTextFont fuente, BaseColor fondo, int alineacion)
        {
            PdfPCell celda = new PdfPCell(new Phrase(texto, fuente));
            celda.BackgroundColor = fondo;
            celda.HorizontalAlignment = alineacion;
            celda.Padding = 6f;
            celda.Border = PdfPCell.BOTTOM_BORDER;
            celda.BorderColorBottom = new BaseColor(235, 235, 235);
            return celda;
        }

        // 2. AÑADIMOS 'string fechaCreacion' A LOS PARÁMETROS
        public void ExportarCartaResponsiva(string rutaGuardado, string nombreEmpleado, string tipo, string marca, string modelo, string serie, string procesador, string ram, string disco, string sistema, string fechaCreacion, string comentarios)
        {
            iTextSharp.text.Document doc = new iTextSharp.text.Document(iTextSharp.text.PageSize.LETTER, 50, 50, 50, 50);

            try
            {
                PdfWriter.GetInstance(doc, new FileStream(rutaGuardado, FileMode.Create));
                doc.Open();

                iTextSharp.text.Font fontTitulo = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 14);
                iTextSharp.text.Font fontNormal = FontFactory.GetFont(FontFactory.HELVETICA, 10);
                iTextSharp.text.Font fontNegrita = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 10);

                Paragraph titulo = new Paragraph("CARTA RESPONSIVA", fontTitulo)
                {
                    Alignment = Element.ALIGN_CENTER,
                    SpacingAfter = 20f
                };
                doc.Add(titulo);

                Paragraph intro = new Paragraph("Por medio de la presente, se hace constar la asignación y entrega formal del siguiente equipo de cómputo y accesorios, propiedad de la empresa Excel Nobleza, para el uso exclusivo en el desempeño de las funciones laborales que le han sido encomendadas. Este documento sirve como comprobante y establece la responsabilidad del usuario sobre el equipo mencionado.\n\n", fontNormal)
                {
                    Alignment = Element.ALIGN_JUSTIFIED
                };
                doc.Add(intro);

                PdfPTable tabla = new PdfPTable(2)
                {
                    WidthPercentage = 100,
                    SpacingAfter = 20f
                };
                tabla.SetWidths(new float[] { 30f, 70f });

                void AgregarFila(string etiqueta, string valor)
                {
                    PdfPCell celdaEtiqueta = new PdfPCell(new Phrase(etiqueta, fontNegrita))
                    {
                        BackgroundColor = new BaseColor(240, 240, 240),
                        Padding = 6f,
                        BorderColor = BaseColor.LIGHT_GRAY
                    };

                    PdfPCell celdaValor = new PdfPCell(new Phrase(valor, fontNormal))
                    {
                        Padding = 6f,
                        BorderColor = BaseColor.LIGHT_GRAY
                    };

                    tabla.AddCell(celdaEtiqueta);
                    tabla.AddCell(celdaValor);
                }

                AgregarFila("NOMBRE:", nombreEmpleado);
                AgregarFila("TIPO:", tipo);
                AgregarFila("MARCA:", marca);
                AgregarFila("MODELO:", modelo);
                AgregarFila("NUM DE SERIE:", serie);
                AgregarFila("PROCESADOR:", procesador);
                AgregarFila("MEMORIA RAM:", ram);
                AgregarFila("ALMACENAMIENTO:", disco);
                AgregarFila("SISTEMA OPERATIVO:", sistema);

                // 👇 AQUÍ INYECTAMOS LA FECHA DE CREACIÓN 👇
                AgregarFila("FECHA DE ALTA:", fechaCreacion);

                AgregarFila("ACCESORIOS:", string.IsNullOrWhiteSpace(comentarios) ? "Ninguno" : comentarios);

                doc.Add(tabla);

                Paragraph reglasIntro = new Paragraph("Nos permitimos recordar y establecer los siguientes aspectos fundamentales sobre el uso adecuado, la custodia y responsabilidad del equipo y los recursos tecnológicos que le han sido asignados:\n\n", fontNormal)
                {
                    Alignment = Element.ALIGN_JUSTIFIED
                };
                doc.Add(reglasIntro);

                iTextSharp.text.List listaReglas = new iTextSharp.text.List(iTextSharp.text.List.UNORDERED, 15f);
                listaReglas.SetListSymbol("\u2022 ");

                string[] puntosReglas = {
            "Uso personal e Intransferible: El derecho a utilizar las herramientas y recursos puestos a su disposición son estrictamente para fines laborales y personales, en relación con las actividades de la empresa. En ningún caso se permite la transferencia o sesión de uso a terceros, especialmente a personas ajenas a la empresa, ni siquiera de manera temporal.",
            "Custodia y Diligencia: Usted es responsable del uso que le da a su equipo y la preservación de las herramientas, recursos e información contenida en el equipo. Cualquier daño, perdida o mal uso del equipo sin contar el desgaste por el tiempo será su responsabilidad.",
            "Mantenimiento y Cuidado Físico: Se debe realizar un mantenimiento físico regular del equipo, incluyendo su limpieza. Se debe evitar la exposición a líquidos y alimentos, igual forma las caídas o cualquier situación que pueda dañar la integridad física del dispositivo.",
            "Actualizaciones: Es la responsabilidad del usuario mantener actualizado el sistema operativo y programas necesarios. En caso de requerir la ayuda de un experto puede acudir al levantamiento de tickets y/o al departamento de TI.",
            "Respaldo de Información: El usuario debe tener activa su cuenta empresarial y hacer uso de OneDrive para el resguardo de la información, recordando que las carpetas sincronizadas para OneDrive son: escritorio, imágenes y documentos. Es su responsabilidad asegurarse de mantener sincronizada y actualizada dichas carpetas para evitar la pérdida de datos.",
            "Apagado y Cierre de Sesión: Al finalizar la jornada laboral o cuando el equipo no esté en uso se recomienda apagarlo o suspenderlo correctamente. Esto previene problemas con el hardware, reduce el consumo de energía y prolonga la vida del equipo.",
            "Devolución de equipo: Al finalizar la relación laboral, el equipo y todos los accesorios otorgados deberán ser devueltos en las mejores condiciones posibles al departamento de TI."
        };

                foreach (string punto in puntosReglas)
                {
                    ListItem item = new ListItem(new Phrase(punto, fontNormal))
                    {
                        Alignment = Element.ALIGN_JUSTIFIED,
                        SpacingAfter = 10f
                    };
                    listaReglas.Add(item);
                }
                doc.Add(listaReglas);

                Paragraph cierre = new Paragraph("\nAl firmar este documento, usted manifiesta que ha recibido el equipo descrito con anterioridad y se compromete a cumplir con las responsabilidades y lineamientos establecidos.\n\nAgradecemos su compromiso y colaboración.", fontNormal)
                {
                    Alignment = Element.ALIGN_JUSTIFIED,
                    SpacingAfter = 50f
                };
                doc.Add(cierre);

                PdfPTable tablaFirma = new PdfPTable(1) { WidthPercentage = 40 };

                PdfPCell celdaLinea = new PdfPCell(new Phrase(" ")) { Border = iTextSharp.text.Rectangle.BOTTOM_BORDER, BorderWidthBottom = 1f };
                PdfPCell celdaTexto = new PdfPCell(new Phrase("(NOMBRE, FIRMA Y FECHA)", fontNormal))
                {
                    Border = iTextSharp.text.Rectangle.NO_BORDER,
                    HorizontalAlignment = Element.ALIGN_CENTER,
                    PaddingTop = 5f
                };

                tablaFirma.AddCell(celdaLinea);
                tablaFirma.AddCell(celdaTexto);
                doc.Add(tablaFirma);

            }
            catch (Exception ex)
            {
                throw new Exception("Error interno en iTextSharp: " + ex.Message);
            }
            finally
            {
                if (doc.IsOpen())
                {
                    doc.Close();
                }
            }
        }
    }
}