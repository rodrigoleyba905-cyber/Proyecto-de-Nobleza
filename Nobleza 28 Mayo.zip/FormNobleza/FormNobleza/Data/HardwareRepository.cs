﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;
using FormNobleza.Models;
using System.Data;
using Google.Protobuf;

namespace FormNobleza.Data
{
    public class HardwareRepository : ConnectionToSql //Herencia para el metodo GETCONNECTION()

    {
        public bool Insertar(Hardware equipo)
        {
            //Consulta SQL 
            //@parametros contra la inyección SQL

            string query = @"INSERT INTO hardware (numeroSerie, modelo, idCategoria, idMarca, idEstado, creadoPor)
            VALUES 
            (@numeroSerie, @modelo, @idCategoria, @idMarca, @idEstado, @creadoPor);";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();

                    using (var command = new MySqlCommand(query, connection))
                    {
                        //Mapeo de las propiedades de Objeto c# a Parametros SQL
                        command.Parameters.AddWithValue("@numeroSerie", equipo.numeroSerie);
                        command.Parameters.AddWithValue("@modelo", equipo.modelo);
                        command.Parameters.AddWithValue("@idCategoria", equipo.idCategoria);
                        command.Parameters.AddWithValue("@idMarca", equipo.idMarca);
                        command.Parameters.AddWithValue("@idEstado", equipo.idEstado);
                        command.Parameters.AddWithValue("@creadoPor", equipo.creadoPor);

                        int filasAfectadas = command.ExecuteNonQuery(); //Devuelve las filas afectadas

                        return filasAfectadas > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al insertar el hardware a la base de datos : " + ex.Message);
            }
        }
        //Buscar un registro por ID
        public Hardware BuscarPorId(int id)
        {
            //Consulta de búsqueda por llave primaria
            string query = "SELECT * FROM hardware WHERE idHardware = @id;";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        //Pasamos el Id 
                        command.Parameters.AddWithValue("@id", id);

                        using (var reader = command.ExecuteReader())
                        {
                            //Si el read halla una fila ".Read(), devuelve true"
                            if (reader.Read())
                            {

                                //Objeto con los datos de Maria DB
                                Hardware equipo = new Hardware
                                {
                                    idHardware = Convert.ToInt32(reader["idHardware"]),
                                    numeroSerie = reader["numeroSerie"].ToString(),
                                    modelo = reader["modelo"].ToString(),
                                    idCategoria = Convert.ToInt32(reader["idCategoria"]),
                                    idMarca = Convert.ToInt32(reader["idMarca"]),
                                    idEstado = Convert.ToInt32(reader["idEstado"]),
                                    creadoPor = Convert.ToInt32(reader["creadoPor"]),
                                    //Por si "actualizadoPor" sigue vacío
                                    actualizadoPor = reader["actualizadoPor"] == DBNull.Value ? 0 : Convert.ToInt32(reader["actualizadoPor"]),
                                    fecha = Convert.ToDateTime(reader["fechaCreacion"])

                                };
                                return equipo; //Devolver el objeto limpio 
                            }
                        }
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al buscar el hardware por ID: " + ex.Message);
            }

        }

        public bool Actualizar(Hardware equipo)
        {
            //Consulta sql 
            string query = @"UPDATE hardware
                            SET numeroSerie= @numeroSerie,
                            modelo = @modelo,
                            idCategoria = @idCategoria,
                            idMarca = @idMarca,
                            idEstado = @idEstado,
                            actualizadoPor = @actualizadoPor
                            WHERE idHardware = @idHardware;";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@idHardware", equipo.idHardware);
                        command.Parameters.AddWithValue("@numeroSerie", equipo.numeroSerie);
                        command.Parameters.AddWithValue("@modelo", equipo.modelo);
                        command.Parameters.AddWithValue("@idCategoria", equipo.idCategoria);
                        command.Parameters.AddWithValue("@idMarca", equipo.idMarca);
                        command.Parameters.AddWithValue("@idEstado", equipo.idEstado);
                        command.Parameters.AddWithValue("@actualizadoPor", equipo.actualizadoPor);

                        int filasAfectadas = command.ExecuteNonQuery();

                        return filasAfectadas > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al actualizar el equipo de hardware" + ex.Message);
            }


        }

        public bool Eliminar(Hardware id)
        {
            string query = "DELETE FROM hardware WHERE idHardware = @id;";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);

                        int filasAfectadas = command.ExecuteNonQuery();
                        return filasAfectadas > 0;

                    }
                }

            }
            catch (Exception ex)
            {
                throw new Exception("Error al eliminar el equipo de hardware" + ex.Message);
            }
        }

        ///<summary>
        ///Recupera el listado de categorias de la base de datos
        /// </summary>
        /// 

        public DataTable ObtenerCategorias()
        {
            string query = "SELECT idCategoria, nombreCategoria FROM categorias ORDER BY nombreCategoria ASC;";
            DataTable tabla = new DataTable();

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query))
                    {
                        using (var adapter = new MySqlDataAdapter(command))
                        {
                            adapter.Fill(tabla);

                        }
                    }
                }
                return tabla;
            }
            catch (Exception ex)
            {
                {
                    throw new Exception("Error al recuperar las categorías" + ex.Message);
                }
            }
        }
        
        
        /// <summary>
        /// Recupera el listado completo de marcas desde la base de datos.
        /// </summary>
        public DataTable ObtenerMarcas()
        {
            string query = "SELECT idMarca, nombreMarca FROM marcas ORDER BY nombre ASC;";
            DataTable tabla = new DataTable();

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        
                        using (var adapter = new MySqlDataAdapter(command))
                        {
                            adapter.Fill(tabla);
                        }
                    }
                }
                return tabla;
            }
            catch(Exception ex) 
                {
                throw new Exception("Error al recuperar el catálogo de marcas" + ex.Message);
                }
        }

        /// <summary>
        /// Recupera el listado completo de marcas desde la base de datos.
        /// </summary>
       
        public DataTable ObtenerEstados()
        {
            string query = "SELECT idEstado, nombreEstado FROM estados_hardware ORDER BY nombreEstado ASC;";
            DataTable tabla = new DataTable();
            
            try 
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        using (var adapter = new MySqlDataAdapter(command))
                        {
                            adapter.Fill(tabla); 
                        }
                    }
                }
                return tabla;
            }
            catch (Exception ex)
            {
                throw new Exception(" Error al recuperar el catálogo de estados"+ ex.Message);
            }

        }
    }
}

