﻿using FormNobleza.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FormNobleza.Models;


namespace FormNobleza
{
    public partial class Crud : Form
    {
        private readonly HardwareRepository _hardwareRepository = new HardwareRepository();

        private bool _esModoEdicion = false;
        public Crud()
        {
            InitializeComponent();
            ConfigurarInterfazInicial();
        }

        ///<summary>
        ///Establecemos el estado estático de los controles del formulario y bloque la edicion
        ///</summary>
        ///

        private void ConfigurarInterfazInicial()
        {
            //Restrriccion de botones
            btnEliminarEquipo.Enabled = false;
            btnAñadirEquipo.Enabled = false;    

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Crud_Load(object sender, EventArgs e)
        {


        }

        private void btnHome_Click(object sender, EventArgs e)
        {

            Menu pantallaDashboard = new Menu();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnCrud_Click(object sender, EventArgs e)
        {

            Crud pantallaDashboard = new Crud();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnTracking_Click(object sender, EventArgs e)
        {

            Tracking pantallaDashboard = new Tracking();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnExit_Click(object sender, EventArgs e)
        {

            FormLogin pantallaDashboard = new FormLogin();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnAñadir_Click(object sender, EventArgs e)
        {
            //Validacion de campos vacios 

            if (string.IsNullOrWhiteSpace(txtModelo.Text) || string.IsNullOrWhiteSpace(txtNumeroSerie.Text))
            {
                MessageBox.Show("Error de Captura: El numero de Serie y Modelo son obligatorios",
                    "Validacion de Interfaz", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return;

            }
            
                try
            {
                //  Empacamos los datos en un objeto
                //Usamos SELECTED VALUE para los ComboBox y obtener las llaves

                Hardware equipoData = new Hardware
                {
                    modelo = txtModelo.Text.Trim(),
                    numeroSerie = txtNumeroSerie.Text.Trim(),
                    idCategoria = Convert.ToInt32(cmbCategoria.SelectedValue),
                    idMarca = Convert.ToInt32(cmbMarca.SelectedValue),
                    idEstado = Convert.ToInt32(cmbEstado.SelectedValue),

                    //Auditamos qué usuario está registrando

                    creadoPor = UsuarioSesion.IdUsuario,
                    actualizadoPor = UsuarioSesion.IdUsuario
                };

                bool resultadoTransaccion = false;

                //Bifurcamos
                if (_esModoEdicion)
                {
                    //Modo edicion: Registro existente en MariaDB "UPDATE"
                    resultadoTransaccion  = _hardwareRepository.Actualizar(equipoData);
                }
                else
                {
                    //Modo incersion: Libre, ejecutamos "INSERT INTO"
                    resultadoTransaccion = _hardwareRepository.Insertar(equipoData);
                }

                if (resultadoTransaccion)
                {
                    MessageBox.Show("Operacion completada. Los datos han sido guardados en la Base de Datos",
                        "Éxit", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    //Limpiamos pantalla y bloqueamos todo de nuevo
                    txtRastreoId.Clear();
                    LimpiarControlesCaptura();
                    ConfigurarInterfazInicial();

                
                }

            }
            }
        

        private void btnReportes_Click(object sender, EventArgs e)
        {
            Reportes pantallaDashboard = new Reportes();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnBusqueda_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtRastreoId.Text))
            {
                MessageBox.Show("Debe ingresar un id");
            }

        }

        private void txtRastreoId_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRastreoId_KeyDown(object sender, KeyEventArgs e)
        {
            //La tecla presionada fue ENTER?
            if (e.KeyCode == Keys.Enter)
            {

                e.SuppressKeyPress = true; //Sonido suprimido
                btnBusqueda_Click(this, new EventArgs()); //Evento del boton original
            }
        }

        private void dataGridRegistro_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void LimpiarControlesCaptura()
        {
            // 1. Vaciamos las cadenas de texto de los TextBox analógicos
            txtModelo.Clear();
            txtNumeroSerie.Clear();

            // 2. Reiniciamos los ComboBox para que vuelvan a apuntar al primer registro de sus catálogos
            // Evaluamos con un condicional preventivo que contengan datos para evitar excepciones de índice
            if (cmbCategoria.Items.Count > 0) cmbCategoria.SelectedIndex = 0;
            if (cmbMarca.Items.Count > 0) cmbMarca.SelectedIndex = 0;
            if (cmbEstado.Items.Count > 0) cmbEstado.SelectedIndex = 0;
        }
    }
}
