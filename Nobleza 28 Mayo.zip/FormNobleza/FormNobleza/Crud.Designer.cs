﻿namespace FormNobleza
{
    partial class Crud
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Crud));
            dataGridRegistro = new DataGridView();
            btnAñadirEquipo = new Button();
            btnEliminarEquipo = new Button();
            label1 = new Label();
            panel1 = new Panel();
            panel2 = new Panel();
            txtNumeroSerie = new TextBox();
            cmbEstado = new ComboBox();
            cmbMarca = new ComboBox();
            txtModelo = new TextBox();
            cmbCategoria = new ComboBox();
            label2 = new Label();
            txtRastreoId = new TextBox();
            btnBusqueda = new Button();
            pictureBox1 = new PictureBox();
            flowLayoutPanel1 = new FlowLayoutPanel();
            flowLayoutPanel3 = new FlowLayoutPanel();
            panel5 = new Panel();
            btnReportes = new Button();
            label11 = new Label();
            btnProfil = new Button();
            btnExit = new Button();
            btnTracking = new Button();
            btnCrud = new Button();
            btnHome = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridRegistro).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridRegistro
            // 
            dataGridRegistro.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridRegistro.Location = new Point(12, 137);
            dataGridRegistro.Name = "dataGridRegistro";
            dataGridRegistro.Size = new Size(483, 267);
            dataGridRegistro.TabIndex = 0;
            dataGridRegistro.CellContentClick += dataGridRegistro_CellContentClick;
            // 
            // btnAñadirEquipo
            // 
            btnAñadirEquipo.BackColor = Color.FromArgb(25, 118, 210);
            btnAñadirEquipo.Cursor = Cursors.Hand;
            btnAñadirEquipo.FlatAppearance.BorderSize = 0;
            btnAñadirEquipo.FlatStyle = FlatStyle.Flat;
            btnAñadirEquipo.Font = new Font("Segoe UI Semibold", 12F);
            btnAñadirEquipo.ForeColor = Color.FromArgb(248, 249, 250);
            btnAñadirEquipo.Location = new Point(3, 213);
            btnAñadirEquipo.Name = "btnAñadirEquipo";
            btnAñadirEquipo.Size = new Size(200, 30);
            btnAñadirEquipo.TabIndex = 1;
            btnAñadirEquipo.Text = "Guardar Cambios";
            btnAñadirEquipo.UseVisualStyleBackColor = false;
            btnAñadirEquipo.Click += btnAñadir_Click;
            // 
            // btnEliminarEquipo
            // 
            btnEliminarEquipo.BackColor = Color.FromArgb(25, 118, 210);
            btnEliminarEquipo.Cursor = Cursors.Hand;
            btnEliminarEquipo.FlatAppearance.BorderSize = 0;
            btnEliminarEquipo.FlatStyle = FlatStyle.Flat;
            btnEliminarEquipo.Font = new Font("Segoe UI Semibold", 12F);
            btnEliminarEquipo.ForeColor = Color.FromArgb(248, 249, 250);
            btnEliminarEquipo.Location = new Point(3, 259);
            btnEliminarEquipo.Name = "btnEliminarEquipo";
            btnEliminarEquipo.Size = new Size(200, 30);
            btnEliminarEquipo.TabIndex = 3;
            btnEliminarEquipo.Text = "Eliminar";
            btnEliminarEquipo.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 18F);
            label1.Location = new Point(356, 21);
            label1.Name = "label1";
            label1.Size = new Size(266, 32);
            label1.TabIndex = 4;
            label1.Text = "REGISTRO DE EQUIPOS";
            label1.Click += label1_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(248, 249, 250);
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(txtRastreoId);
            panel1.Controls.Add(btnBusqueda);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(dataGridRegistro);
            panel1.Controls.Add(pictureBox1);
            panel1.ForeColor = Color.FromArgb(26, 26, 26);
            panel1.Location = new Point(186, 55);
            panel1.Name = "panel1";
            panel1.Size = new Size(761, 415);
            panel1.TabIndex = 5;
            // 
            // panel2
            // 
            panel2.Controls.Add(txtNumeroSerie);
            panel2.Controls.Add(cmbEstado);
            panel2.Controls.Add(btnAñadirEquipo);
            panel2.Controls.Add(cmbMarca);
            panel2.Controls.Add(btnEliminarEquipo);
            panel2.Controls.Add(txtModelo);
            panel2.Controls.Add(cmbCategoria);
            panel2.Controls.Add(label2);
            panel2.Location = new Point(512, 69);
            panel2.Name = "panel2";
            panel2.Size = new Size(220, 335);
            panel2.TabIndex = 30;
            // 
            // txtNumeroSerie
            // 
            txtNumeroSerie.BorderStyle = BorderStyle.None;
            txtNumeroSerie.Cursor = Cursors.IBeam;
            txtNumeroSerie.Font = new Font("Segoe UI Semibold", 12F);
            txtNumeroSerie.Location = new Point(3, 7);
            txtNumeroSerie.Name = "txtNumeroSerie";
            txtNumeroSerie.PlaceholderText = "Numero de Serie:";
            txtNumeroSerie.Size = new Size(209, 22);
            txtNumeroSerie.TabIndex = 20;
            // 
            // cmbEstado
            // 
            cmbEstado.Cursor = Cursors.Hand;
            cmbEstado.Enabled = false;
            cmbEstado.FlatStyle = FlatStyle.Flat;
            cmbEstado.Font = new Font("Segoe UI Semibold", 12F);
            cmbEstado.FormattingEnabled = true;
            cmbEstado.Items.AddRange(new object[] { "Nave 1", "Nave 2", "Nave 3", "Nave 4", "Nave 5", "Nave 6", "Nave 7", "Nave 8", "Nave 9", "Nave 10", "Nave 11", "Nave 12", "", "" });
            cmbEstado.Location = new Point(3, 166);
            cmbEstado.Name = "cmbEstado";
            cmbEstado.Size = new Size(209, 29);
            cmbEstado.TabIndex = 29;
            cmbEstado.Text = "Estado:";
            // 
            // cmbMarca
            // 
            cmbMarca.Cursor = Cursors.Hand;
            cmbMarca.Enabled = false;
            cmbMarca.FlatStyle = FlatStyle.Flat;
            cmbMarca.Font = new Font("Segoe UI Semibold", 12F);
            cmbMarca.FormattingEnabled = true;
            cmbMarca.Items.AddRange(new object[] { "Nave 1", "Nave 2", "Nave 3", "Nave 4", "Nave 5", "Nave 6", "Nave 7", "Nave 8", "Nave 9", "Nave 10", "Nave 11", "Nave 12", "", "" });
            cmbMarca.Location = new Point(3, 131);
            cmbMarca.Name = "cmbMarca";
            cmbMarca.Size = new Size(209, 29);
            cmbMarca.TabIndex = 28;
            cmbMarca.Text = "Marca: ";
            // 
            // txtModelo
            // 
            txtModelo.BorderStyle = BorderStyle.None;
            txtModelo.Cursor = Cursors.IBeam;
            txtModelo.Font = new Font("Segoe UI Semibold", 12F);
            txtModelo.Location = new Point(3, 60);
            txtModelo.Name = "txtModelo";
            txtModelo.PlaceholderText = "Modelo:";
            txtModelo.Size = new Size(209, 22);
            txtModelo.TabIndex = 27;
            // 
            // cmbCategoria
            // 
            cmbCategoria.Cursor = Cursors.Hand;
            cmbCategoria.Enabled = false;
            cmbCategoria.FlatStyle = FlatStyle.Flat;
            cmbCategoria.Font = new Font("Segoe UI Semibold", 12F);
            cmbCategoria.FormattingEnabled = true;
            cmbCategoria.Items.AddRange(new object[] { "Nave 1", "Nave 2", "Nave 3", "Nave 4", "Nave 5", "Nave 6", "Nave 7", "Nave 8", "Nave 9", "Nave 10", "Nave 11", "Nave 12", "", "" });
            cmbCategoria.Location = new Point(3, 96);
            cmbCategoria.Name = "cmbCategoria";
            cmbCategoria.Size = new Size(209, 29);
            cmbCategoria.TabIndex = 21;
            cmbCategoria.Text = "Categoría:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.FromArgb(255, 128, 128);
            label2.Location = new Point(3, 32);
            label2.Name = "label2";
            label2.Size = new Size(182, 15);
            label2.TabIndex = 24;
            label2.Text = "Este dispositivo ya fue registrado!";
            // 
            // txtRastreoId
            // 
            txtRastreoId.BorderStyle = BorderStyle.None;
            txtRastreoId.Cursor = Cursors.IBeam;
            txtRastreoId.Font = new Font("Segoe UI Semibold", 12F);
            txtRastreoId.Location = new Point(17, 105);
            txtRastreoId.Name = "txtRastreoId";
            txtRastreoId.PlaceholderText = "Buscar por Id:";
            txtRastreoId.Size = new Size(433, 22);
            txtRastreoId.TabIndex = 17;
            txtRastreoId.TextChanged += txtRastreoId_TextChanged;
            txtRastreoId.KeyDown += txtRastreoId_KeyDown;
            // 
            // btnBusqueda
            // 
            btnBusqueda.FlatAppearance.BorderSize = 0;
            btnBusqueda.FlatStyle = FlatStyle.Flat;
            btnBusqueda.Image = Properties.Resources.search_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24;
            btnBusqueda.Location = new Point(452, 109);
            btnBusqueda.Name = "btnBusqueda";
            btnBusqueda.Size = new Size(30, 18);
            btnBusqueda.TabIndex = 16;
            btnBusqueda.UseVisualStyleBackColor = true;
            btnBusqueda.Click += btnBusqueda_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Excel2__1_1;
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(178, 81);
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel1.Location = new Point(36, 33);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(911, 19);
            flowLayoutPanel1.TabIndex = 5;
            // 
            // flowLayoutPanel3
            // 
            flowLayoutPanel3.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel3.Location = new Point(36, 476);
            flowLayoutPanel3.Name = "flowLayoutPanel3";
            flowLayoutPanel3.Size = new Size(911, 19);
            flowLayoutPanel3.TabIndex = 16;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(248, 249, 250);
            panel5.Controls.Add(btnReportes);
            panel5.Controls.Add(label11);
            panel5.Controls.Add(btnProfil);
            panel5.Controls.Add(btnExit);
            panel5.Controls.Add(btnTracking);
            panel5.Controls.Add(btnCrud);
            panel5.Controls.Add(btnHome);
            panel5.Location = new Point(39, 55);
            panel5.Name = "panel5";
            panel5.Size = new Size(144, 415);
            panel5.TabIndex = 31;
            // 
            // btnReportes
            // 
            btnReportes.BackColor = Color.FromArgb(25, 118, 210);
            btnReportes.Cursor = Cursors.Hand;
            btnReportes.FlatAppearance.BorderSize = 0;
            btnReportes.FlatStyle = FlatStyle.Flat;
            btnReportes.ForeColor = Color.FromArgb(141, 122, 104);
            btnReportes.Image = (Image)resources.GetObject("btnReportes.Image");
            btnReportes.Location = new Point(60, 253);
            btnReportes.Name = "btnReportes";
            btnReportes.Size = new Size(64, 47);
            btnReportes.TabIndex = 12;
            btnReportes.UseVisualStyleBackColor = false;
            btnReportes.Click += btnReportes_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(19, 62);
            label11.Name = "label11";
            label11.Size = new Size(111, 15);
            label11.TabIndex = 6;
            label11.Text = "¡HOLA, INGENIERO!";
            // 
            // btnProfil
            // 
            btnProfil.Cursor = Cursors.Hand;
            btnProfil.FlatAppearance.BorderSize = 0;
            btnProfil.FlatStyle = FlatStyle.Flat;
            btnProfil.Image = Properties.Resources.person_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnProfil.Location = new Point(40, 21);
            btnProfil.Name = "btnProfil";
            btnProfil.Size = new Size(64, 38);
            btnProfil.TabIndex = 10;
            btnProfil.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.FromArgb(25, 118, 210);
            btnExit.Cursor = Cursors.Hand;
            btnExit.FlatAppearance.BorderSize = 0;
            btnExit.FlatStyle = FlatStyle.Flat;
            btnExit.Image = Properties.Resources.logout_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnExit.Location = new Point(60, 306);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(64, 47);
            btnExit.TabIndex = 3;
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // btnTracking
            // 
            btnTracking.BackColor = Color.FromArgb(25, 118, 210);
            btnTracking.Cursor = Cursors.Hand;
            btnTracking.FlatAppearance.BorderSize = 0;
            btnTracking.FlatStyle = FlatStyle.Flat;
            btnTracking.Image = Properties.Resources.analytics_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnTracking.Location = new Point(60, 200);
            btnTracking.Name = "btnTracking";
            btnTracking.Size = new Size(64, 47);
            btnTracking.TabIndex = 2;
            btnTracking.UseVisualStyleBackColor = false;
            btnTracking.Click += btnTracking_Click;
            // 
            // btnCrud
            // 
            btnCrud.BackColor = Color.FromArgb(25, 118, 210);
            btnCrud.Cursor = Cursors.Hand;
            btnCrud.FlatAppearance.BorderSize = 0;
            btnCrud.FlatStyle = FlatStyle.Flat;
            btnCrud.Image = Properties.Resources.table_edit_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnCrud.Location = new Point(60, 147);
            btnCrud.Name = "btnCrud";
            btnCrud.Size = new Size(64, 47);
            btnCrud.TabIndex = 1;
            btnCrud.UseVisualStyleBackColor = false;
            btnCrud.Click += btnCrud_Click;
            // 
            // btnHome
            // 
            btnHome.BackColor = Color.FromArgb(25, 118, 210);
            btnHome.Cursor = Cursors.Hand;
            btnHome.FlatAppearance.BorderSize = 0;
            btnHome.FlatStyle = FlatStyle.Flat;
            btnHome.ForeColor = Color.FromArgb(141, 122, 104);
            btnHome.Image = (Image)resources.GetObject("btnHome.Image");
            btnHome.Location = new Point(60, 94);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(64, 47);
            btnHome.TabIndex = 0;
            btnHome.UseVisualStyleBackColor = false;
            btnHome.Click += btnHome_Click;
            // 
            // Crud
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1034, 532);
            Controls.Add(panel5);
            Controls.Add(flowLayoutPanel3);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(panel1);
            Name = "Crud";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Crud";
            Load += Crud_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridRegistro).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridRegistro;
        private Button btnAñadirEquipo;
        private Button btnEliminarEquipo;
        private Label label1;
        private Panel panel1;
        private PictureBox pictureBox1;
        private FlowLayoutPanel flowLayoutPanel1;
        private FlowLayoutPanel flowLayoutPanel3;
        private Panel panel5;
        private Label label11;
        private Button btnProfil;
        private Button btnExit;
        private Button btnTracking;
        private Button btnCrud;
        private Button btnHome;
        private Button btnReportes;
        private TextBox txtRastreoId;
        private Button btnBusqueda;
        private ComboBox cmbEstado;
        private ComboBox cmbMarca;
        private TextBox txtModelo;
        private Label label2;
        private TextBox txtNumeroSerie;
        private ComboBox cmbCategoria;
        private Panel panel2;
    }
}