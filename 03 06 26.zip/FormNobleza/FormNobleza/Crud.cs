﻿using FormNobleza.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FormNobleza.Models;

namespace FormNobleza
{
    public partial class Crud : Form
    {
        private readonly HardwareRepository _hardwareRepository = new HardwareRepository();

        private bool _esModoEdicion = false;
        private Hardware _equipoActual = null;

        // Mapeo texto del ComboBox → idCategoria en BD
        // Orden: índice 0 = "PC" = id 1, índice 1 = "Laptop" = id 2
        // Ajusta los IDs según tus inserts en categorias/marcas/estados
        private readonly int[] _idsCategoria = { 1, 2 };           // PC, Laptop
        private readonly int[] _idsMarca = { 1, 2, 3, 4, 5 };  // Hp, Dell, Lenovo, Acer, Asus
        private readonly int[] _idsEstado = { 1, 2, 3 };        // Nuevo, Usado, Desecho
        public Crud()
        {
            InitializeComponent();
            ConfigurarInterfazInicial();
            txtNumeroSerie.KeyDown += txtNumeroSerie_KeyDown;
            CargarDataGrid();

            txtModelo.Enabled = false;
            cmbCategoria.Enabled = false;
            cmbMarca.Enabled = false;
            cmbEstado.Enabled = false;
        }

        private void CargarDataGrid()
        {
            try
            {
                var lista = _hardwareRepository.ObtenerTodos();
                dataGridRegistro.DataSource = null;
                dataGridRegistro.DataSource = lista;

                if (dataGridRegistro.Columns["idHardware"] != null) dataGridRegistro.Columns["idHardware"]!.Visible = false;
                if (dataGridRegistro.Columns["idCategoria"] != null) dataGridRegistro.Columns["idCategoria"]!.Visible = false;
                if (dataGridRegistro.Columns["idMarca"] != null) dataGridRegistro.Columns["idMarca"]!.Visible = false;
                if (dataGridRegistro.Columns["idEstado"] != null) dataGridRegistro.Columns["idEstado"]!.Visible = false;
                if (dataGridRegistro.Columns["creadoPor"] != null) dataGridRegistro.Columns["creadoPor"]!.Visible = false;
                if (dataGridRegistro.Columns["actualizadoPor"] != null) dataGridRegistro.Columns["actualizadoPor"]!.Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar la tabla:\n" + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        ///<summary>
        ///Establecemos el estado estático de los controles del formulario y bloque la edicion
        ///</summary>
        ///
        private void txtNumeroSerie_KeyDown(object sender, KeyEventArgs e)
        {
        
            if (e.KeyCode != Keys.Enter) return;
            e.SuppressKeyPress = true;

            if (string.IsNullOrWhiteSpace(txtNumeroSerie.Text))
            {
                MessageBox.Show("Ingresa un número de serie.", "Campo Vacío",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string serie = txtNumeroSerie.Text.Trim();
                bool existe = _hardwareRepository.ExisteNumeroSerie(serie);

                // Desbloquear siempre después de validar
                txtNumeroSerie.Enabled = false;
                txtModelo.Enabled = true;
                cmbCategoria.Enabled = true;
                cmbMarca.Enabled = true;
                cmbEstado.Enabled = true;

                if (existe)
                {
                    _equipoActual = _hardwareRepository.BuscarPorNumeroSerie(serie);
                    _esModoEdicion = true;


                    // Alertas si el numeroSerie existe. Desbloqueamos todo el crud para edición.
                    lblAlertaId.Text = "Número de serie existente";
                    lblAlertaId.ForeColor = Color.Green;
                    lblAlertaId.Visible = true;

                    txtModelo.Text = _equipoActual.modelo;
                    cmbCategoria.SelectedIndex = IndexDeId(_idsCategoria, _equipoActual.idCategoria);
                    cmbMarca.SelectedIndex = IndexDeId(_idsMarca, _equipoActual.idMarca);
                    cmbEstado.SelectedIndex = IndexDeId(_idsEstado, _equipoActual.idEstado);

                    btnAñadirEquipo.Text = "Guardar Cambios";
                    btnAñadirEquipo.Enabled = true;
                    btnEliminarEquipo.Enabled = true;
                }
                else
                {   
                    //Si no existe el numeroSerie, desbloqueamos todo el crud,listo para hacer una incersión 
                    _equipoActual = null;
                    _esModoEdicion = false;

                    lblAlertaId.Text = "Número de serie nuevo";
                    lblAlertaId.ForeColor = Color.DodgerBlue;
                    lblAlertaId.Visible = true;

                    txtModelo.Clear();
                    cmbCategoria.SelectedIndex = 0;
                    cmbMarca.SelectedIndex = 0;
                    cmbEstado.SelectedIndex = 0;

                    btnAñadirEquipo.Text = "Guardar Equipo";
                    btnAñadirEquipo.Enabled = true;
                    btnEliminarEquipo.Enabled = false;
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error al consultar:\n" + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void ConfigurarInterfazInicial()
        {
            {

                //Bloqueamos todo, excepto el numeroSerie
                btnEliminarEquipo.Enabled = false;
                btnAñadirEquipo.Enabled = false;
                lblAlertaId.Visible = false;

                // Habilitamos los combos para alta nueva también
                cmbCategoria.Enabled = true;
                cmbMarca.Enabled = true;
                cmbEstado.Enabled = true;
            }

        }

        private void Crud_Load(object sender, EventArgs e)
        {


        }

        private void btnHome_Click(object sender, EventArgs e)
        {

            Menu pantallaDashboard = new Menu();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnCrud_Click(object sender, EventArgs e)
        {

            Crud pantallaDashboard = new Crud();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnTracking_Click(object sender, EventArgs e)
        {

            Tracking pantallaDashboard = new Tracking();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnExit_Click(object sender, EventArgs e)
        {

            FormLogin pantallaDashboard = new FormLogin();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnAñadir_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(txtModelo.Text))
            {

                //Si está vacio el campo, lanzamos una alerta
                MessageBox.Show("El campo Modelo es obligatorio.", "Campo Vacío",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbCategoria.SelectedIndex < 0 || cmbMarca.SelectedIndex < 0 || cmbEstado.SelectedIndex < 0)
            {

                //Si no hay numero de categoria seleccionado, mandamos una alerta
                MessageBox.Show("Selecciona Categoría, Marca y Estado.", "Campos incompletos",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {


                int idCategoria = _idsCategoria[cmbCategoria.SelectedIndex];
                int idMarca = _idsMarca[cmbMarca.SelectedIndex];
                int idEstado = _idsEstado[cmbEstado.SelectedIndex];
                int idUsuario = UsuarioSesion.IdUsuario;

                if (_esModoEdicion)
                {
                    // UPDATE
                    _equipoActual.modelo = txtModelo.Text.Trim();
                    _equipoActual.idCategoria = idCategoria;
                    _equipoActual.idMarca = idMarca;
                    _equipoActual.idEstado = idEstado;
                    _equipoActual.actualizadoPor = idUsuario;

                    _hardwareRepository.Actualizar(_equipoActual);
                    MessageBox.Show("Equipo actualizado correctamente.", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    // INSERT
                    var nuevoHw = new Hardware
                    {
                        numeroSerie = txtNumeroSerie.Text.Trim(),
                        modelo = txtModelo.Text.Trim(),
                        idCategoria = idCategoria,
                        idMarca = idMarca,
                        idEstado = idEstado,
                        creadoPor = idUsuario
                    };

                    _hardwareRepository.Insertar(nuevoHw);
                    MessageBox.Show("Equipo registrado correctamente.", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                LimpiarPanel();
                CargarDataGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar:\n" + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnReportes_Click(object sender, EventArgs e)
        {
            Reportes pantallaDashboard = new Reportes();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnBusqueda_Click(object sender, EventArgs e)
        {


        }

        private void txtRastreoId_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRastreoId_KeyDown(object sender, KeyEventArgs e)
        {

        }



        private void txtNumeroSerie_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnEliminarEquipo_Click(object sender, EventArgs e)
        {
            if (_equipoActual == null) return;

            var confirmacion = MessageBox.Show(
                $"¿Deseas ELIMINAR el equipo '{_equipoActual.numeroSerie}' del sistema?\nÚsalo solo si fue un error de captura.",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirmacion != DialogResult.Yes) return;

            try
            {
                _hardwareRepository.Eliminar(_equipoActual.idHardware);
                MessageBox.Show("Equipo eliminado del sistema.", "Eliminado",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                LimpiarPanel();
                CargarDataGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar:\n" + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        // Devuelve el índice en el array dado un id de BD
        private int IndexDeId(int[] ids, int idBuscado)
        {
            for (int i = 0; i < ids.Length; i++)
                if (ids[i] == idBuscado) return i;
            return 0;
        }

        // Limpia el panel de edición y resetea el estado
        private void LimpiarPanel()
        {
            txtNumeroSerie.Clear();
            txtNumeroSerie.Enabled = true;  // listo para nueva validación

            txtModelo.Clear();
            txtModelo.Enabled = false;
            cmbCategoria.Enabled = false;
            cmbMarca.Enabled = false;
            cmbEstado.Enabled = false;

            cmbCategoria.SelectedIndex = 0;
            cmbMarca.SelectedIndex = 0;
            cmbEstado.SelectedIndex = 0;

            lblAlertaId.Visible = false;
            btnAñadirEquipo.Enabled = false;
            btnEliminarEquipo.Enabled = false;
            btnAñadirEquipo.Text = "Guardar Equipo";
            _equipoActual = null;
            _esModoEdicion = false;

            txtNumeroSerie.Focus(); // foco directo al campo de serie
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
 