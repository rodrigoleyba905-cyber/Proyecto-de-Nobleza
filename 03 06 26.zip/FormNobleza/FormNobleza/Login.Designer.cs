﻿namespace FormNobleza
{
    partial class FormLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel3 = new Panel();
            txtContraseña = new TextBox();
            txtUsuario = new TextBox();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            panel1 = new Panel();
            btnIniciarSesion = new Button();
            lblError = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(0, 115, 138);
            panel3.Location = new Point(183, 58);
            panel3.Name = "panel3";
            panel3.Size = new Size(248, 412);
            panel3.TabIndex = 8;
            // 
            // txtContraseña
            // 
            txtContraseña.BorderStyle = BorderStyle.None;
            txtContraseña.Cursor = Cursors.IBeam;
            txtContraseña.Font = new Font("Segoe UI Semibold", 12F);
            txtContraseña.Location = new Point(395, 205);
            txtContraseña.Name = "txtContraseña";
            txtContraseña.PlaceholderText = "Contraseña:";
            txtContraseña.Size = new Size(200, 22);
            txtContraseña.TabIndex = 4;
            // 
            // txtUsuario
            // 
            txtUsuario.BorderStyle = BorderStyle.None;
            txtUsuario.Cursor = Cursors.IBeam;
            txtUsuario.Font = new Font("Segoe UI Semibold", 12F);
            txtUsuario.Location = new Point(395, 157);
            txtUsuario.Name = "txtUsuario";
            txtUsuario.PlaceholderText = "Usuario:";
            txtUsuario.Size = new Size(200, 22);
            txtUsuario.TabIndex = 3;
            txtUsuario.TextChanged += txtUsuario_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.Control;
            label1.Font = new Font("Segoe UI Semibold", 18F);
            label1.ForeColor = Color.FromArgb(26, 26, 26);
            label1.Location = new Point(428, 24);
            label1.Name = "label1";
            label1.Size = new Size(210, 32);
            label1.TabIndex = 0;
            label1.Text = "INICIO DE SESIÓN";
            label1.Click += label1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Excel2__1_1;
            pictureBox1.Location = new Point(244, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(178, 81);
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(395, 241);
            label2.Name = "label2";
            label2.Size = new Size(0, 15);
            label2.TabIndex = 10;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(248, 249, 250);
            panel1.Controls.Add(btnIniciarSesion);
            panel1.Controls.Add(lblError);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(txtUsuario);
            panel1.Controls.Add(txtContraseña);
            panel1.Location = new Point(183, 58);
            panel1.Name = "panel1";
            panel1.Size = new Size(770, 415);
            panel1.TabIndex = 8;
            // 
            // btnIniciarSesion
            // 
            btnIniciarSesion.BackColor = Color.FromArgb(25, 118, 210);
            btnIniciarSesion.Cursor = Cursors.Hand;
            btnIniciarSesion.FlatAppearance.BorderSize = 0;
            btnIniciarSesion.FlatStyle = FlatStyle.Flat;
            btnIniciarSesion.Font = new Font("Segoe UI Semibold", 12F);
            btnIniciarSesion.ForeColor = Color.FromArgb(248, 249, 250);
            btnIniciarSesion.Location = new Point(395, 259);
            btnIniciarSesion.Name = "btnIniciarSesion";
            btnIniciarSesion.Size = new Size(200, 30);
            btnIniciarSesion.TabIndex = 17;
            btnIniciarSesion.Text = "Iniciar Sesion";
            btnIniciarSesion.UseVisualStyleBackColor = false;
            btnIniciarSesion.Click += btnIniciarSesion_Click;
            // 
            // lblError
            // 
            lblError.AutoSize = true;
            lblError.ForeColor = Color.FromArgb(255, 128, 128);
            lblError.Location = new Point(395, 241);
            lblError.Name = "lblError";
            lblError.Size = new Size(119, 15);
            lblError.TabIndex = 16;
            lblError.Text = "Error de credenciales!";
            // 
            // FormLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(984, 541);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Name = "FormLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form Login";
            Load += FormLogin_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel3;
        private TextBox txtContraseña;
        private TextBox txtUsuario;
        private Button btnSesion;
        private Label label1;
        private PictureBox pictureBox1;
        private Label label2;
        private Panel panel1;
        private Label lblError;
        private Button btnIniciarSesion;
    }
}
