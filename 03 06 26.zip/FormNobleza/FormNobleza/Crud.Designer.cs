﻿namespace FormNobleza
{
    partial class Crud
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Crud));
            dataGridRegistro = new DataGridView();
            btnAñadirEquipo = new Button();
            btnEliminarEquipo = new Button();
            label1 = new Label();
            panel1 = new Panel();
            panelEdicion = new Panel();
            lblAlertaId = new Label();
            txtNumeroSerie = new TextBox();
            cmbEstado = new ComboBox();
            cmbMarca = new ComboBox();
            txtModelo = new TextBox();
            cmbCategoria = new ComboBox();
            txtRastreoId = new TextBox();
            btnBusqueda = new Button();
            pictureBox1 = new PictureBox();
            flowLayoutPanel1 = new FlowLayoutPanel();
            flowLayoutPanel3 = new FlowLayoutPanel();
            panel5 = new Panel();
            btnReportes = new Button();
            label11 = new Label();
            btnProfil = new Button();
            btnExit = new Button();
            btnTracking = new Button();
            btnCrud = new Button();
            btnHome = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridRegistro).BeginInit();
            panel1.SuspendLayout();
            panelEdicion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridRegistro
            // 
            dataGridRegistro.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(33, 97, 172);
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 10F);
            dataGridViewCellStyle1.ForeColor = Color.White;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridRegistro.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridRegistro.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.White;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9.5F);
            dataGridViewCellStyle2.ForeColor = Color.FromArgb(26, 26, 26);
            dataGridViewCellStyle2.SelectionBackColor = Color.Black;
            dataGridViewCellStyle2.SelectionForeColor = Color.White;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataGridRegistro.DefaultCellStyle = dataGridViewCellStyle2;
            dataGridRegistro.EnableHeadersVisualStyles = false;
            dataGridRegistro.Location = new Point(12, 137);
            dataGridRegistro.MultiSelect = false;
            dataGridRegistro.Name = "dataGridRegistro";
            dataGridRegistro.ReadOnly = true;
            dataGridRegistro.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridRegistro.Size = new Size(483, 267);
            dataGridRegistro.TabIndex = 0;
            // 
            // btnAñadirEquipo
            // 
            btnAñadirEquipo.BackColor = Color.FromArgb(25, 118, 210);
            btnAñadirEquipo.Cursor = Cursors.Hand;
            btnAñadirEquipo.FlatAppearance.BorderSize = 0;
            btnAñadirEquipo.FlatStyle = FlatStyle.Flat;
            btnAñadirEquipo.Font = new Font("Segoe UI Semibold", 12F);
            btnAñadirEquipo.ForeColor = Color.FromArgb(248, 249, 250);
            btnAñadirEquipo.Location = new Point(15, 238);
            btnAñadirEquipo.Name = "btnAñadirEquipo";
            btnAñadirEquipo.Size = new Size(200, 30);
            btnAñadirEquipo.TabIndex = 1;
            btnAñadirEquipo.Text = "Guardar Cambios";
            btnAñadirEquipo.UseVisualStyleBackColor = false;
            btnAñadirEquipo.Click += btnAñadir_Click;
            // 
            // btnEliminarEquipo
            // 
            btnEliminarEquipo.BackColor = Color.FromArgb(25, 118, 210);
            btnEliminarEquipo.Cursor = Cursors.Hand;
            btnEliminarEquipo.FlatAppearance.BorderSize = 0;
            btnEliminarEquipo.FlatStyle = FlatStyle.Flat;
            btnEliminarEquipo.Font = new Font("Segoe UI Semibold", 12F);
            btnEliminarEquipo.ForeColor = Color.FromArgb(248, 249, 250);
            btnEliminarEquipo.Location = new Point(15, 278);
            btnEliminarEquipo.Name = "btnEliminarEquipo";
            btnEliminarEquipo.Size = new Size(200, 30);
            btnEliminarEquipo.TabIndex = 3;
            btnEliminarEquipo.Text = "Eliminar";
            btnEliminarEquipo.UseVisualStyleBackColor = false;
            btnEliminarEquipo.Click += btnEliminarEquipo_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 18F);
            label1.Location = new Point(356, 21);
            label1.Name = "label1";
            label1.Size = new Size(266, 32);
            label1.TabIndex = 4;
            label1.Text = "REGISTRO DE EQUIPOS";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(248, 249, 250);
            panel1.Controls.Add(panelEdicion);
            panel1.Controls.Add(txtRastreoId);
            panel1.Controls.Add(btnBusqueda);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(dataGridRegistro);
            panel1.Controls.Add(pictureBox1);
            panel1.ForeColor = Color.FromArgb(26, 26, 26);
            panel1.Location = new Point(186, 55);
            panel1.Name = "panel1";
            panel1.Size = new Size(761, 415);
            panel1.TabIndex = 5;
            panel1.Paint += panel1_Paint;
            // 
            // panelEdicion
            // 
            panelEdicion.Controls.Add(lblAlertaId);
            panelEdicion.Controls.Add(txtNumeroSerie);
            panelEdicion.Controls.Add(cmbEstado);
            panelEdicion.Controls.Add(btnAñadirEquipo);
            panelEdicion.Controls.Add(cmbMarca);
            panelEdicion.Controls.Add(btnEliminarEquipo);
            panelEdicion.Controls.Add(txtModelo);
            panelEdicion.Controls.Add(cmbCategoria);
            panelEdicion.Location = new Point(516, 72);
            panelEdicion.Name = "panelEdicion";
            panelEdicion.Size = new Size(230, 332);
            panelEdicion.TabIndex = 30;
            // 
            // lblAlertaId
            // 
            lblAlertaId.AutoSize = true;
            lblAlertaId.BackColor = Color.WhiteSmoke;
            lblAlertaId.Font = new Font("Microsoft Sans Serif", 8.25F);
            lblAlertaId.ForeColor = Color.Green;
            lblAlertaId.Location = new Point(118, 43);
            lblAlertaId.Name = "lblAlertaId";
            lblAlertaId.Size = new Size(70, 13);
            lblAlertaId.TabIndex = 30;
            lblAlertaId.Text = "¡ID Existente!";
            lblAlertaId.TextAlign = ContentAlignment.TopCenter;
            // 
            // txtNumeroSerie
            // 
            txtNumeroSerie.BorderStyle = BorderStyle.None;
            txtNumeroSerie.Cursor = Cursors.IBeam;
            txtNumeroSerie.Font = new Font("Segoe UI Semibold", 12F);
            txtNumeroSerie.Location = new Point(18, 15);
            txtNumeroSerie.Name = "txtNumeroSerie";
            txtNumeroSerie.PlaceholderText = "Numero de Serie:";
            txtNumeroSerie.Size = new Size(209, 22);
            txtNumeroSerie.TabIndex = 20;
            // 
            // cmbEstado
            // 
            cmbEstado.Cursor = Cursors.Hand;
            cmbEstado.Enabled = false;
            cmbEstado.FlatStyle = FlatStyle.Flat;
            cmbEstado.Font = new Font("Segoe UI Semibold", 12F);
            cmbEstado.FormattingEnabled = true;
            cmbEstado.Items.AddRange(new object[] { "Nuevo", "Usado", "Desecho" });
            cmbEstado.Location = new Point(15, 185);
            cmbEstado.Name = "cmbEstado";
            cmbEstado.Size = new Size(209, 29);
            cmbEstado.TabIndex = 29;
            cmbEstado.Text = "Estado:";
            // 
            // cmbMarca
            // 
            cmbMarca.Cursor = Cursors.Hand;
            cmbMarca.Enabled = false;
            cmbMarca.FlatStyle = FlatStyle.Flat;
            cmbMarca.Font = new Font("Segoe UI Semibold", 12F);
            cmbMarca.FormattingEnabled = true;
            cmbMarca.Items.AddRange(new object[] { "Hp", "Dell", "Lenovo", "Acer", "Asus" });
            cmbMarca.Location = new Point(15, 150);
            cmbMarca.Name = "cmbMarca";
            cmbMarca.Size = new Size(209, 29);
            cmbMarca.TabIndex = 28;
            cmbMarca.Text = "Marca: ";
            // 
            // txtModelo
            // 
            txtModelo.BorderStyle = BorderStyle.None;
            txtModelo.Cursor = Cursors.IBeam;
            txtModelo.Font = new Font("Segoe UI Semibold", 12F);
            txtModelo.Location = new Point(15, 79);
            txtModelo.Name = "txtModelo";
            txtModelo.PlaceholderText = "Modelo:";
            txtModelo.Size = new Size(209, 22);
            txtModelo.TabIndex = 27;
            // 
            // cmbCategoria
            // 
            cmbCategoria.Cursor = Cursors.Hand;
            cmbCategoria.Enabled = false;
            cmbCategoria.FlatStyle = FlatStyle.Flat;
            cmbCategoria.Font = new Font("Segoe UI Semibold", 12F);
            cmbCategoria.FormattingEnabled = true;
            cmbCategoria.Items.AddRange(new object[] { "PC", "Laptop" });
            cmbCategoria.Location = new Point(15, 115);
            cmbCategoria.Name = "cmbCategoria";
            cmbCategoria.Size = new Size(209, 29);
            cmbCategoria.TabIndex = 21;
            cmbCategoria.Text = "Categoría:";
            // 
            // txtRastreoId
            // 
            txtRastreoId.BorderStyle = BorderStyle.None;
            txtRastreoId.Cursor = Cursors.IBeam;
            txtRastreoId.Font = new Font("Segoe UI Semibold", 12F);
            txtRastreoId.Location = new Point(17, 105);
            txtRastreoId.Name = "txtRastreoId";
            txtRastreoId.PlaceholderText = "Buscar por Id:";
            txtRastreoId.Size = new Size(433, 22);
            txtRastreoId.TabIndex = 17;
            txtRastreoId.KeyDown += txtRastreoId_KeyDown;
            // 
            // btnBusqueda
            // 
            btnBusqueda.FlatAppearance.BorderSize = 0;
            btnBusqueda.FlatStyle = FlatStyle.Flat;
            btnBusqueda.Image = Properties.Resources.search_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24;
            btnBusqueda.Location = new Point(452, 109);
            btnBusqueda.Name = "btnBusqueda";
            btnBusqueda.Size = new Size(30, 18);
            btnBusqueda.TabIndex = 16;
            btnBusqueda.UseVisualStyleBackColor = true;
            btnBusqueda.Click += btnBusqueda_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Excel2__1_1;
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(178, 81);
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel1.Location = new Point(36, 33);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(911, 19);
            flowLayoutPanel1.TabIndex = 5;
            // 
            // flowLayoutPanel3
            // 
            flowLayoutPanel3.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel3.Location = new Point(36, 476);
            flowLayoutPanel3.Name = "flowLayoutPanel3";
            flowLayoutPanel3.Size = new Size(911, 19);
            flowLayoutPanel3.TabIndex = 16;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(248, 249, 250);
            panel5.Controls.Add(btnReportes);
            panel5.Controls.Add(label11);
            panel5.Controls.Add(btnProfil);
            panel5.Controls.Add(btnExit);
            panel5.Controls.Add(btnTracking);
            panel5.Controls.Add(btnCrud);
            panel5.Controls.Add(btnHome);
            panel5.Location = new Point(39, 55);
            panel5.Name = "panel5";
            panel5.Size = new Size(144, 415);
            panel5.TabIndex = 31;
            // 
            // btnReportes
            // 
            btnReportes.BackColor = Color.FromArgb(248, 249, 250);
            btnReportes.Cursor = Cursors.Hand;
            btnReportes.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnReportes.FlatAppearance.BorderSize = 2;
            btnReportes.FlatStyle = FlatStyle.Flat;
            btnReportes.Font = new Font("Segoe UI Semibold", 9F);
            btnReportes.ForeColor = Color.Black;
            btnReportes.Image = (Image)resources.GetObject("btnReportes.Image");
            btnReportes.ImageAlign = ContentAlignment.MiddleLeft;
            btnReportes.Location = new Point(19, 253);
            btnReportes.Name = "btnReportes";
            btnReportes.Size = new Size(121, 37);
            btnReportes.TabIndex = 12;
            btnReportes.Text = "Reportes";
            btnReportes.UseVisualStyleBackColor = false;
            btnReportes.Click += btnReportes_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(19, 62);
            label11.Name = "label11";
            label11.Size = new Size(111, 15);
            label11.TabIndex = 6;
            label11.Text = "¡HOLA, INGENIERO!";
            // 
            // btnProfil
            // 
            btnProfil.Cursor = Cursors.Hand;
            btnProfil.FlatAppearance.BorderSize = 0;
            btnProfil.FlatStyle = FlatStyle.Flat;
            btnProfil.Image = Properties.Resources.person_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnProfil.Location = new Point(40, 21);
            btnProfil.Name = "btnProfil";
            btnProfil.Size = new Size(64, 38);
            btnProfil.TabIndex = 10;
            btnProfil.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.FromArgb(248, 249, 250);
            btnExit.Cursor = Cursors.Hand;
            btnExit.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnExit.FlatAppearance.BorderSize = 2;
            btnExit.FlatStyle = FlatStyle.Flat;
            btnExit.Font = new Font("Segoe UI Semibold", 9F);
            btnExit.ForeColor = Color.Black;
            btnExit.Image = (Image)resources.GetObject("btnExit.Image");
            btnExit.ImageAlign = ContentAlignment.MiddleLeft;
            btnExit.Location = new Point(19, 375);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(121, 37);
            btnExit.TabIndex = 3;
            btnExit.Text = "Salir ";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // btnTracking
            // 
            btnTracking.BackColor = Color.FromArgb(248, 249, 250);
            btnTracking.Cursor = Cursors.Hand;
            btnTracking.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnTracking.FlatAppearance.BorderSize = 2;
            btnTracking.FlatStyle = FlatStyle.Flat;
            btnTracking.Font = new Font("Segoe UI Semibold", 9F);
            btnTracking.Image = (Image)resources.GetObject("btnTracking.Image");
            btnTracking.ImageAlign = ContentAlignment.MiddleLeft;
            btnTracking.Location = new Point(20, 200);
            btnTracking.Name = "btnTracking";
            btnTracking.Size = new Size(121, 37);
            btnTracking.TabIndex = 2;
            btnTracking.Text = "Rastreo";
            btnTracking.UseVisualStyleBackColor = false;
            btnTracking.Click += btnTracking_Click;
            // 
            // btnCrud
            // 
            btnCrud.BackColor = Color.FromArgb(248, 249, 250);
            btnCrud.Cursor = Cursors.Hand;
            btnCrud.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnCrud.FlatAppearance.BorderSize = 2;
            btnCrud.FlatStyle = FlatStyle.Flat;
            btnCrud.Font = new Font("Segoe UI Semibold", 9F);
            btnCrud.Image = (Image)resources.GetObject("btnCrud.Image");
            btnCrud.ImageAlign = ContentAlignment.MiddleLeft;
            btnCrud.Location = new Point(20, 147);
            btnCrud.Name = "btnCrud";
            btnCrud.Size = new Size(121, 37);
            btnCrud.TabIndex = 1;
            btnCrud.Text = "Añadir";
            btnCrud.UseVisualStyleBackColor = false;
            btnCrud.Click += btnCrud_Click;
            // 
            // btnHome
            // 
            btnHome.BackColor = Color.FromArgb(248, 249, 250);
            btnHome.Cursor = Cursors.Hand;
            btnHome.FlatAppearance.BorderColor = Color.FromArgb(0, 115, 138);
            btnHome.FlatAppearance.BorderSize = 2;
            btnHome.FlatStyle = FlatStyle.Flat;
            btnHome.Font = new Font("Segoe UI Semibold", 9F);
            btnHome.ForeColor = Color.Black;
            btnHome.Image = (Image)resources.GetObject("btnHome.Image");
            btnHome.ImageAlign = ContentAlignment.MiddleLeft;
            btnHome.Location = new Point(19, 99);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(121, 37);
            btnHome.TabIndex = 0;
            btnHome.Text = "Inicio";
            btnHome.UseVisualStyleBackColor = false;
            btnHome.Click += btnHome_Click;
            // 
            // Crud
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1034, 532);
            Controls.Add(panel5);
            Controls.Add(flowLayoutPanel3);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(panel1);
            Name = "Crud";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Crud";
            Load += Crud_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridRegistro).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panelEdicion.ResumeLayout(false);
            panelEdicion.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridRegistro;
        private Button btnAñadirEquipo;
        private Button btnEliminarEquipo;
        private Label label1;
        private Panel panel1;
        private PictureBox pictureBox1;
        private FlowLayoutPanel flowLayoutPanel1;
        private FlowLayoutPanel flowLayoutPanel3;
        private Panel panel5;
        private Label label11;
        private Button btnProfil;
        private Button btnExit;
        private Button btnTracking;
        private Button btnCrud;
        private Button btnHome;
        private Button btnReportes;
        private TextBox txtRastreoId;
        private Button btnBusqueda;
        private ComboBox cmbEstado;
        private ComboBox cmbMarca;
        private TextBox txtModelo;
        private TextBox txtNumeroSerie;
        private ComboBox cmbCategoria;
        private Panel panelEdicion;
        private Label lblAlertaId;
    }
}