﻿namespace FormNobleza
{
    partial class principalMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(principalMenu));
            panel1 = new Panel();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            panel2 = new Panel();
            label5 = new Label();
            panel3 = new Panel();
            label6 = new Label();
            txtRastreo = new TextBox();
            label8 = new Label();
            flowLayoutPanel1 = new FlowLayoutPanel();
            flowLayoutPanel2 = new FlowLayoutPanel();
            panel4 = new Panel();
            pictureBox3 = new PictureBox();
            dataGridView1 = new DataGridView();
            panel6 = new Panel();
            button1 = new Button();
            label9 = new Label();
            flowLayoutPanel3 = new FlowLayoutPanel();
            flowLayoutPanel4 = new FlowLayoutPanel();
            panel5 = new Panel();
            label11 = new Label();
            btnProfil = new Button();
            btnExit = new Button();
            btnTracking = new Button();
            btnCrud = new Button();
            btnHome = new Button();
            label10 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel6.SuspendLayout();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(19, 253);
            panel1.Name = "panel1";
            panel1.Size = new Size(240, 147);
            panel1.TabIndex = 0;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(57, 136);
            label4.Name = "label4";
            label4.Size = new Size(0, 15);
            label4.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(29, 125);
            label3.Name = "label3";
            label3.Size = new Size(49, 15);
            label3.TabIndex = 2;
            label3.Text = "Laptops";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(29, 77);
            label2.Name = "label2";
            label2.Size = new Size(28, 15);
            label2.TabIndex = 1;
            label2.Text = "Pc's";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 33);
            label1.Name = "label1";
            label1.Size = new Size(97, 15);
            label1.TabIndex = 0;
            label1.Text = "Total de equipos:";
            // 
            // panel2
            // 
            panel2.Controls.Add(label5);
            panel2.Location = new Point(265, 253);
            panel2.Name = "panel2";
            panel2.Size = new Size(240, 147);
            panel2.TabIndex = 1;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(73, 23);
            label5.Name = "label5";
            label5.Size = new Size(103, 15);
            label5.TabIndex = 0;
            label5.Text = "Movimientos hoy:";
            // 
            // panel3
            // 
            panel3.Controls.Add(label6);
            panel3.Location = new Point(511, 253);
            panel3.Name = "panel3";
            panel3.Size = new Size(240, 147);
            panel3.TabIndex = 2;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(33, 23);
            label6.Name = "label6";
            label6.Size = new Size(121, 15);
            label6.TabIndex = 0;
            label6.Text = "Reparaciones/Alertas:";
            // 
            // txtRastreo
            // 
            txtRastreo.BorderStyle = BorderStyle.None;
            txtRastreo.Cursor = Cursors.Help;
            txtRastreo.Font = new Font("Segoe UI Semibold", 12F);
            txtRastreo.Location = new Point(3, 5);
            txtRastreo.Name = "txtRastreo";
            txtRastreo.Size = new Size(683, 22);
            txtRastreo.TabIndex = 4;
            txtRastreo.Text = "  Rastreo por ID";
            txtRastreo.Visible = false;
            txtRastreo.TextChanged += txtRastreo_TextChanged;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Semibold", 18F);
            label8.ForeColor = Color.FromArgb(26, 26, 26);
            label8.Location = new Point(404, 21);
            label8.Name = "label8";
            label8.Size = new Size(206, 32);
            label8.TabIndex = 5;
            label8.Text = "MENÚ PRINCIPAL";
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Location = new Point(50, 50);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(0, 0);
            flowLayoutPanel1.TabIndex = 6;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.Location = new Point(0, 0);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(0, 0);
            flowLayoutPanel2.TabIndex = 7;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(248, 249, 250);
            panel4.Controls.Add(pictureBox3);
            panel4.Controls.Add(dataGridView1);
            panel4.Controls.Add(panel6);
            panel4.Controls.Add(label8);
            panel4.Controls.Add(panel1);
            panel4.Controls.Add(panel2);
            panel4.Controls.Add(panel3);
            panel4.Location = new Point(188, 53);
            panel4.Name = "panel4";
            panel4.Size = new Size(770, 415);
            panel4.TabIndex = 8;
            panel4.Paint += panel4_Paint;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.Excel2__1_1;
            pictureBox3.Location = new Point(0, 0);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(178, 81);
            pictureBox3.TabIndex = 14;
            pictureBox3.TabStop = false;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(43, 140);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(693, 100);
            dataGridView1.TabIndex = 13;
            // 
            // panel6
            // 
            panel6.Controls.Add(button1);
            panel6.Controls.Add(txtRastreo);
            panel6.Location = new Point(43, 101);
            panel6.Name = "panel6";
            panel6.Size = new Size(693, 33);
            panel6.TabIndex = 6;
            // 
            // button1
            // 
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Image = Properties.Resources.search_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24;
            button1.Location = new Point(654, 2);
            button1.Name = "button1";
            button1.Size = new Size(36, 28);
            button1.TabIndex = 7;
            button1.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(111, 313);
            label9.Name = "label9";
            label9.Size = new Size(0, 15);
            label9.TabIndex = 24;
            // 
            // flowLayoutPanel3
            // 
            flowLayoutPanel3.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel3.Location = new Point(38, 471);
            flowLayoutPanel3.Name = "flowLayoutPanel3";
            flowLayoutPanel3.Size = new Size(920, 19);
            flowLayoutPanel3.TabIndex = 28;
            // 
            // flowLayoutPanel4
            // 
            flowLayoutPanel4.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel4.Location = new Point(38, 31);
            flowLayoutPanel4.Name = "flowLayoutPanel4";
            flowLayoutPanel4.Size = new Size(920, 19);
            flowLayoutPanel4.TabIndex = 26;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(248, 249, 250);
            panel5.Controls.Add(label11);
            panel5.Controls.Add(btnProfil);
            panel5.Controls.Add(btnExit);
            panel5.Controls.Add(btnTracking);
            panel5.Controls.Add(btnCrud);
            panel5.Controls.Add(btnHome);
            panel5.Location = new Point(38, 53);
            panel5.Name = "panel5";
            panel5.Size = new Size(144, 415);
            panel5.TabIndex = 27;
            panel5.Paint += panel5_Paint;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(17, 102);
            label11.Name = "label11";
            label11.Size = new Size(111, 15);
            label11.TabIndex = 6;
            label11.Text = "¡HOLA, INGENIERO!";
            // 
            // btnProfil
            // 
            btnProfil.Cursor = Cursors.Hand;
            btnProfil.FlatAppearance.BorderSize = 0;
            btnProfil.FlatStyle = FlatStyle.Flat;
            btnProfil.Image = Properties.Resources.person_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnProfil.Location = new Point(39, 61);
            btnProfil.Name = "btnProfil";
            btnProfil.Size = new Size(64, 38);
            btnProfil.TabIndex = 10;
            btnProfil.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.FromArgb(25, 118, 210);
            btnExit.Cursor = Cursors.Hand;
            btnExit.FlatAppearance.BorderSize = 0;
            btnExit.FlatStyle = FlatStyle.Flat;
            btnExit.Image = Properties.Resources.logout_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnExit.Location = new Point(64, 330);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(64, 47);
            btnExit.TabIndex = 3;
            btnExit.UseVisualStyleBackColor = false;
            // 
            // btnTracking
            // 
            btnTracking.BackColor = Color.FromArgb(25, 118, 210);
            btnTracking.Cursor = Cursors.Hand;
            btnTracking.FlatAppearance.BorderSize = 0;
            btnTracking.FlatStyle = FlatStyle.Flat;
            btnTracking.Image = Properties.Resources.analytics_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnTracking.Location = new Point(64, 266);
            btnTracking.Name = "btnTracking";
            btnTracking.Size = new Size(64, 47);
            btnTracking.TabIndex = 2;
            btnTracking.UseVisualStyleBackColor = false;
            // 
            // btnCrud
            // 
            btnCrud.BackColor = Color.FromArgb(25, 118, 210);
            btnCrud.Cursor = Cursors.Hand;
            btnCrud.FlatAppearance.BorderSize = 0;
            btnCrud.FlatStyle = FlatStyle.Flat;
            btnCrud.Image = Properties.Resources.table_edit_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnCrud.Location = new Point(64, 203);
            btnCrud.Name = "btnCrud";
            btnCrud.Size = new Size(64, 47);
            btnCrud.TabIndex = 1;
            btnCrud.UseVisualStyleBackColor = false;
            // 
            // btnHome
            // 
            btnHome.BackColor = Color.FromArgb(25, 118, 210);
            btnHome.Cursor = Cursors.Hand;
            btnHome.FlatAppearance.BorderSize = 0;
            btnHome.FlatStyle = FlatStyle.Flat;
            btnHome.ForeColor = Color.FromArgb(141, 122, 104);
            btnHome.Image = (Image)resources.GetObject("btnHome.Image");
            btnHome.Location = new Point(64, 143);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(64, 47);
            btnHome.TabIndex = 0;
            btnHome.UseVisualStyleBackColor = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(77, 315);
            label10.Name = "label10";
            label10.Size = new Size(0, 15);
            label10.TabIndex = 25;
            // 
            // principalMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1024, 508);
            Controls.Add(flowLayoutPanel3);
            Controls.Add(flowLayoutPanel4);
            Controls.Add(panel5);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(panel4);
            Controls.Add(flowLayoutPanel2);
            Controls.Add(flowLayoutPanel1);
            Name = "principalMenu";
            Text = "MenuPrincipal";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label5;
        private Label label6;
        private TextBox txtRastreo;
        private Label label8;
        private FlowLayoutPanel flowLayoutPanel1;
        private FlowLayoutPanel flowLayoutPanel2;
        private Panel panel4;
        private Label label9;
        private FlowLayoutPanel flowLayoutPanel3;
        private FlowLayoutPanel flowLayoutPanel4;
        private Panel panel5;
        private Button btnProfil;
        private Button btnExit;
        private Button btnTracking;
        private Button btnCrud;
        private Button btnHome;
        private Label label10;
        private Label label11;
        private Panel panel6;
        private Button button1;
        private DataGridView dataGridView1;
        private PictureBox pictureBox3;
    }
}