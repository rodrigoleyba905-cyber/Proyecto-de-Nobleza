﻿using System;
using System.Data;
using MySql.Data.MySqlClient;
using FormNobleza.Models;

namespace FormNobleza.Data
{
    // Hereda ConnectionToSql para reutilizar GetConnection()
    public class HardwareRepository : ConnectionToSql
    {
      //VALIDAR ID

        public bool ExisteNumeroSerie(string serie)
        {
            string query = "SELECT COUNT(*) FROM hardware WHERE numeroSerie = @numeroSerie;";
            string numeroSerie = serie.Trim();

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@numeroSerie", numeroSerie);

                        //Regresamos el primer valor a la fila
                        int count = Convert.ToInt32(command.ExecuteScalar());
                        return count > 0;

                    }
                }
            } catch (Exception ex)
            {
                throw new Exception("Error al validar el ID: " + ex.Message);
            }
        }

        //Buscamos por numero de serie

        //Devuleve el objeto para pintar el panel
        //Devuelve null si no existe

        public Hardware BuscarPorNumeroSerie(string serie)
        {
            string valorSerie= serie.Trim();
            string query = "SELECT * FROM hardware WHERE numeroSerie = @numeroSerie;";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@numeroSerie", valorSerie);

                        using(var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                //Mapeamos todo en los objetos del crud

                                return new Hardware
                                {
                                    idHardware = Convert.ToInt32(reader["idHardware"]),
                                    numeroSerie = reader["numeroSerie"].ToString(),
                                    modelo = reader["modelo"].ToString(),
                                    idCategoria = Convert.ToInt32(reader["idCategoria"]),
                                    idMarca = Convert.ToInt32(reader["idMarca"]),
                                    idEstado = Convert.ToInt32(reader["idEstado"]),
                                    creadoPor = Convert.ToInt32(reader["creadoPor"]),
                                    actualizadoPor= reader["actualizadoPor"] ==DBNull.Value ?0 :Convert.ToInt32(reader["actualizadoPor"])


                                };

                            }
                        }

                    }
                        
                    
                } return null;
            } catch (Exception ex)
            {
                throw new Exception("Error al buscar por numero de Serie " + ex.Message);
            }
        }

        //INSERTAR NUEVO HARDWARE

        public void Insertar(Hardware hw)
        {
            string query = "INSERT INTO hardware (numeroSerie, modelo, idCategoria, idMarca, idEstado, creadoPor) VALUES (@numeroSerie, @modelo, @idCategoria, @idMarca, @idEstado, @creadoPor);";
            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@numeroSerie", hw.numeroSerie.Trim());
                        command.Parameters.AddWithValue("@modelo", hw.modelo.Trim());
                        command.Parameters.AddWithValue("@idCategoria", hw.idCategoria);
                        command.Parameters.AddWithValue("@idMarca", hw.idMarca);
                        command.Parameters.AddWithValue("@idEstado", hw.idEstado);
                        command.Parameters.AddWithValue("@creadoPor", hw.creadoPor);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al insertar el equipo: " + ex.Message);
            }
        }

        //ACTUALIZAR Hardware existente 

        public void Actualizar(Hardware hw)
        {
            string query = @"
                UPDATE hardware SET
                    modelo         = @modelo,
                    idCategoria    = @idCategoria,
                    idMarca        = @idMarca,
                    idEstado       = @idEstado,
                    actualizadoPor = @actualizadoPor
                WHERE idHardware = @idHardware;";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@modelo", hw.modelo.Trim());
                        command.Parameters.AddWithValue("@idCategoria", hw.idCategoria);
                        command.Parameters.AddWithValue("@idMarca", hw.idMarca);
                        command.Parameters.AddWithValue("@idEstado", hw.idEstado);
                        command.Parameters.AddWithValue("@actualizadoPor", hw.actualizadoPor);
                        command.Parameters.AddWithValue("@idHardware", hw.idHardware);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al actualizar el equipo: " + ex.Message);
            }
        }

        //ELIMINAR (DESECHO)
        public void Eliminar(int idHardware)
        {
            string query = "DELETE FROM hardware WHERE idHardware = @idHardware;";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@idHardware", idHardware);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al eliminar el equipo: " + ex.Message);
            }
        }

        //Pintar el grid
        public List<Hardware> ObtenerTodos()
        {
            string query = "SELECT h.idHardware, h.numeroSerie, h.modelo, c.nombreCategoria, m.nombreMarca, e.nombreEstado, h.fechaCreacion FROM hardware h INNER JOIN categorias c ON h.idCategoria = c.idCategoria INNER JOIN marcas m ON h.idMarca = m.idMarca INNER JOIN estados_hardware e ON h.idEstado = e.idEstado ORDER BY h.fechaCreacion DESC;";

            var lista = new List<Hardware>();

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            lista.Add(new Hardware
                            {
                                idHardware = Convert.ToInt32(reader["idHardware"]),
                                numeroSerie = reader["numeroSerie"].ToString(),
                                modelo = reader["modelo"].ToString(),
                                Categoria = reader["nombreCategoria"].ToString(),
                                Marca = reader["nombreMarca"].ToString(),
                                Estado = reader["nombreEstado"].ToString(),
                                fechaCreacion = Convert.ToDateTime(reader["fechaCreacion"])

                            });
                        
                    }
                    }
                }
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al obtener los equipos: " + ex.Message);
            }
        }

        
    }
        

        
    }
