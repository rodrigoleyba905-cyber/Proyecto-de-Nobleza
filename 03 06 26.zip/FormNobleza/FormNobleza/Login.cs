using System.Drawing.Text;
using System.Drawing;
using System.Windows.Forms;
using FormNobleza.Services;
using System;
using FormNobleza.Models;
namespace FormNobleza
{
    public partial class FormLogin : Form
    {
        //Instancia de autenticación
        private readonly AuthService _authService = new AuthService();
        public FormLogin()
        {
            InitializeComponent();
            lblError.Visible = false; //Label oculto
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


        }


        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtUsuario_TextChanged(object sender, EventArgs e)
        {
        }

        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            string usuarioInput = txtUsuario.Text.Trim();
            string passwordInput = txtContraseña.Text;

            try
            {
                bool loginExitoso = _authService.ValidarLogin(usuarioInput, passwordInput);

                if (loginExitoso)
                {
                    //Login exitoso
                    UsuarioSesion.IdUsuario = 1;
                    UsuarioSesion.NombreUsuario = usuarioInput;
                    
                    lblError.Visible = false;
                    MessageBox.Show($"¡Bienvenido al sistema, {usuarioInput}!", "Acceso Concedido", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Menu principal = new Menu();
                    principal.Show();
                    this.Hide(); // Oculta el login actual

                }
                else
                {
                    // FALLÓ EL LOGIN: Activamos nuestra alerta visual personalizada
                    lblError.Text = "El usuario o la contraseña son incorrectos.";
                    lblError.ForeColor = Color.Red; // Pintamos las letras de rojo para alertar
                    lblError.Visible = true;        

                }


            }
            catch (Exception ex)
            {

                //Error de servicios de Xampp apagados
                MessageBox.Show(ex.Message, "Error de Conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }





        private void error(string mensaje)
        {
            lblError.Text = mensaje;
            lblError.Visible = true;
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }
    }
}