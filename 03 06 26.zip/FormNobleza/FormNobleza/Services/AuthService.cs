﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using FormNobleza.Data;
using FormNobleza.Models;
using MySql.Data.MySqlClient;
using BCrypt.Net;

namespace FormNobleza.Services
{
    public class AuthService
    {
        //Instancia de conexión para MARIADB
        private readonly ConnectionToSql _connectionProvider = new ConnectionToSql();

        /// <summary>
        /// Validar credenciales con la base de datos
        /// </summary>

        public bool ValidarLogin(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                return false;
            }


            //Consulas SQL

            string query = "SELECT idUsuario, nombreUsuario, password_hash FROM usuarios WHERE nombreUsuario = @user";
            
            try
            {
                using (var connection = _connectionProvider.GetConnection())
            {
                using (var command = new MySqlCommand(query, connection))
                {
                    
                        command.Parameters.AddWithValue("@user", username.Trim());

                       
                            connection.Open(); //Canal de MARIADB

                            using (var reader = command.ExecuteReader())
                            {
                                if (reader.Read()) //Reader encontró fila? USUARIO EXISTE
                                {
                                    string hashAlmacenado = reader["password_hash"].ToString(); //Hash real de Xampp

                                    //Comprobacion de contraseña 

                                    //  ESTA LÍNEA PROFESIONAL:
                                    if (BCrypt.Net.BCrypt.Verify(password.Trim(), hashAlmacenado))
                                    {
                                        return true;
                                    }
                                }
                            }
                        } 
                    }
                    
                }catch (Exception ex) {

                            //Log de errores

                            throw new Exception("ERROR CRÍTICO DE BASE DE DATOS");
            }
            return false;
        } 
    }
}
