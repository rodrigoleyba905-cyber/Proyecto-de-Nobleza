﻿using MySql.Data.MySqlClient;
using System.Data.SqlClient;
namespace DataAccess
{
    public abstract class SqlConnection
    {
        private readonly string connectionString;
        public SqlConnection()
        {
            connectionString = "Server = localhost; Port = 3306; Database = nobleza; Uid = root; Pwd=;";
       }
        protected MySqlConnection GetConnection()
        {
            return new MySqlConnection(connectionString);
        }
    }
}
