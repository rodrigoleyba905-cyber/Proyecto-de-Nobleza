﻿using FormNobleza.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using iTextFont = iTextSharp.text.Font;
using FormNobleza.Services; // (O el nombre de la carpeta donde guardaste tu clase de PDF)

namespace FormNobleza

{
    public partial class Reportes : Form
    {
        public Reportes()
        {
            InitializeComponent();

        }
        private readonly ReportesRepository _reportesRepo = new ReportesRepository();
        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            Reportes pantallaDashboard = new Reportes();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            Menu pantallaDashboard = new Menu();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnCrud_Click(object sender, EventArgs e)
        {

            Crud pantallaDashboard = new Crud();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnTracking_Click(object sender, EventArgs e)
        {
            Tracking pantallaDashboard = new Tracking();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            FormLogin pantallaDashboard = new FormLogin();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtId_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtId_KeyDown(object sender, KeyEventArgs e)

        {
            //Detectamos si la tecla presionada es el Enter
            if (e.KeyCode == Keys.Enter)
            {
                // 2. Silenciamos el "Ding" de Windows
                e.SuppressKeyPress = true;

                string serie = txtId.Text.Trim();

                //Validamos que no esté vacío
                if (string.IsNullOrWhiteSpace(serie))
                {
                    MessageBox.Show("Ingresa un número de serie para buscar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                try
                {
                    // Vamos a MariaDB por el historial fusionado
                    DataTable historial = _reportesRepo.ObtenerLineaDeTiempoCompleta(serie);
                    
                    
                    if (historial.Rows.Count > 0)
                    {

                        // Si hay datos, los pintamos en el Grid y activamos el botón de PDF
                        GridReportes.DataSource = historial;
                        btnPDF.Enabled = true;

                        // Formato para que las columnas llenen el espacio visual
                        GridReportes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    }
                    else
                    {
                        // Si la laptop es nueva o no existe, limpiamos la tabla
                        GridReportes.DataSource = null;
                        btnPDF.Enabled = false;
                        MessageBox.Show("No hay registros históricos para este equipo.", "Sin Datos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Error de Servidor", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnPDF_Click(object sender, EventArgs e)
        {
          
            // 1. Seguridad: Extraemos el número de serie que introdujeron en el buscador
            string serie = txtId.Text.Trim();

            // Recuperamos el DataTable que está guardado dentro de la memoria del DataGridView
            DataTable tablaEnPantalla = GridReportes.DataSource as DataTable;

            if (tablaEnPantalla == null || tablaEnPantalla.Rows.Count == 0)
            {
                MessageBox.Show("No hay datos en la tabla para poder exportar a PDF.",
                                "Tabla Vacía", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // 3. Abrimos la ventana nativa de Windows para que el admin elija dónde guardar su archivo
                using (SaveFileDialog ventanaGuardar = new SaveFileDialog())
                {
                    ventanaGuardar.Filter = "Documento PDF (*.pdf)|*.pdf";
                    ventanaGuardar.FileName = $"Historial_Trazabilidad_{serie}_{DateTime.Now:yyyyMMdd}";
                    ventanaGuardar.Title = "Guardar Reporte de Historial";

                    if (ventanaGuardar.ShowDialog() == DialogResult.OK)
                    {
                        // 4. Mandamos los datos directos de la pantalla a la fábrica de PDFs
                        GeneradorReportesPDF pdfService = new GeneradorReportesPDF();
                        pdfService.ExportarHistorialAPdf(ventanaGuardar.FileName, serie, tablaEnPantalla);

                        MessageBox.Show("El reporte en PDF ha sido generado y descargado con éxito.",
                                        "Operación Completada", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un problema al procesar el archivo: " + ex.Message,
                                "Error Crítico", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
    }