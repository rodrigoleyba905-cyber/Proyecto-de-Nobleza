﻿using System;
using System.Data;
using MySql.Data.MySqlClient;

namespace FormNobleza.Data
{
    public class ReportesRepository : ConnectionToSql
    {
        /// <summary>
        /// Fusiona la tabla histórica y la tabla viva para armar la línea de tiempo completa.
        /// Retorna un DataTable listo para pintar en el DataGridView o mandar al PDF.
        /// </summary>
        public DataTable ObtenerLineaDeTiempoCompleta(string numeroSerie)
        {
            DataTable tablaHistorial = new DataTable();

            // Usamos UNION ALL para pegar los registros viejos con el registro actual
            string query = @"
                SELECT numeroSerie, idTrabajador, nombreTrabajador, nave, comentarios, 'DEVUELTA' AS estado, fechaMovimiento AS fecha
                FROM historial_asignaciones
                WHERE numeroSerie = @serie
                
                UNION ALL
                
                SELECT numeroSerie, idTrabajador, nombreTrabajador, nave, comentarios, estadoAsignacion AS estado, fechaAsignacion AS fecha
                FROM asignaciones
                WHERE numeroSerie = @serie
                
                ORDER BY fecha ASC;";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@serie", numeroSerie.Trim());

                        using (var adapter = new MySqlDataAdapter(command))
                        {
                            adapter.Fill(tablaHistorial);
                        }
                    }
                }
                return tablaHistorial;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al fusionar el historial del equipo: " + ex.Message);
            }
        }
    }
}