﻿using System;
using System.Data;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextFont = iTextSharp.text.Font;


namespace FormNobleza.Services
{
    public class GeneradorReportesPDF 
    {
        public void ExportarHistorialAPdf(string rutaArchivo, string numeroSerie, DataTable datosHistorial)
        {
            Document documento = new Document(PageSize.A4, 42, 42, 42, 42);

            try
            {
                PdfWriter writer = PdfWriter.GetInstance(documento, new FileStream(rutaArchivo, FileMode.Create));
                documento.Open();

                BaseColor azulCorporativo = new BaseColor(18, 30, 49);
                BaseColor grisCebra = new BaseColor(245, 245, 245);
                BaseColor textoNegro = new BaseColor(40, 40, 40);

                iTextFont fuenteTitulo = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 18f, azulCorporativo);
                iTextFont fuenteSubtitulo = FontFactory.GetFont(FontFactory.HELVETICA, 9f, BaseColor.GRAY);
                iTextFont fuenteHeaderTabla = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 9f, BaseColor.WHITE);
                iTextFont fuenteCeldaNormal = FontFactory.GetFont(FontFactory.HELVETICA, 9f, textoNegro);
                iTextFont fuenteCeldaNegrita = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 9f, azulCorporativo);

                Paragraph titulo = new Paragraph("HISTORIAL Y TRAZABILIDAD DE HARDWARE", fuenteTitulo);
                titulo.Alignment = Element.ALIGN_LEFT;
                documento.Add(titulo);

                Paragraph subtitulo = new Paragraph($"Reporte oficial emitido el: {DateTime.Now:dd/MM/yyyy HH:mm} | StockSale v1.0", fuenteSubtitulo);
                subtitulo.SpacingAfter = 20f;
                documento.Add(subtitulo);

                PdfPTable tablaMeta = new PdfPTable(2);
                tablaMeta.WidthPercentage = 100;
                tablaMeta.SetWidths(new float[] { 25f, 75f });
                tablaMeta.SpacingAfter = 20f;

                AgregarFilaMeta(tablaMeta, "NÚMERO DE SERIE:", fuenteCeldaNegrita);
                AgregarFilaMeta(tablaMeta, numeroSerie, fuenteCeldaNormal);
                AgregarFilaMeta(tablaMeta, "MOVIMIENTOS REGISTRADOS:", fuenteCeldaNegrita);
                AgregarFilaMeta(tablaMeta, datosHistorial.Rows.Count.ToString(), fuenteCeldaNormal);

                documento.Add(tablaMeta);

                PdfPTable tablaDatos = new PdfPTable(6);
                tablaDatos.WidthPercentage = 100;
                tablaDatos.SetWidths(new float[] { 15f, 13f, 22f, 10f, 13f, 27f });

                string[] encabezados = { "FECHA", "ID EMP.", "RESPONSABLE", "NAVE", "ESTADO", "COMENTARIOS" };
                foreach (string header in encabezados)
                {
                    PdfPCell celdaHeader = new PdfPCell(new Phrase(header, fuenteHeaderTabla));
                    celdaHeader.BackgroundColor = azulCorporativo;
                    celdaHeader.HorizontalAlignment = Element.ALIGN_CENTER;
                    celdaHeader.Padding = 8f;
                    celdaHeader.Border = PdfPCell.NO_BORDER;
                    tablaDatos.AddCell(celdaHeader);
                }

                bool intercalarColor = false;
                foreach (DataRow fila in datosHistorial.Rows)
                {
                    BaseColor fondoActual = intercalarColor ? grisCebra : BaseColor.WHITE;

                    DateTime fechaOriginal = Convert.ToDateTime(fila["fecha"]);
                    string fechaFormateada = fechaOriginal.ToString("dd/MM/yyyy");

                    //ROTECCIÓN CONTRA NULOS: Agregamos ?.ToString() ?? "" para que si viene vacío, no explote
                    string idTrab = fila["idTrabajador"]?.ToString() ?? "";
                    string nombreTrab = fila["nombreTrabajador"]?.ToString() ?? "";
                    string nave = fila["nave"]?.ToString() ?? "";
                    string estado = fila["estado"]?.ToString() ?? "";
                    string comentarios = fila["comentarios"]?.ToString() ?? "";

                    tablaDatos.AddCell(CrearCelda(fechaFormateada, fuenteCeldaNormal, fondoActual, Element.ALIGN_CENTER));
                    tablaDatos.AddCell(CrearCelda(idTrab, fuenteCeldaNormal, fondoActual, Element.ALIGN_CENTER));
                    tablaDatos.AddCell(CrearCelda(nombreTrab, fuenteCeldaNormal, fondoActual, Element.ALIGN_LEFT));
                    tablaDatos.AddCell(CrearCelda(nave, fuenteCeldaNormal, fondoActual, Element.ALIGN_CENTER));
                    tablaDatos.AddCell(CrearCelda(estado, fuenteCeldaNormal, fondoActual, Element.ALIGN_CENTER));
                    tablaDatos.AddCell(CrearCelda(comentarios, fuenteCeldaNormal, fondoActual, Element.ALIGN_LEFT));

                    intercalarColor = !intercalarColor;
                }

                documento.Add(tablaDatos);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al estructurar los vectores del PDF: " + ex.Message);
            }
            finally
            {
                if (documento.IsOpen()) documento.Close();
            }
        }

        // 💡 NOTA: También cambiamos 'Font' por 'iTextFont' en estos métodos de abajo
        private void AgregarFilaMeta(PdfPTable tabla, string texto, iTextFont fuente)
        {
            PdfPCell celda = new PdfPCell(new Phrase(texto, fuente));
            celda.Padding = 5f;
            celda.Border = PdfPCell.BOTTOM_BORDER;
            celda.BorderColorBottom = BaseColor.LIGHT_GRAY;
            tabla.AddCell(celda);
        }

        private PdfPCell CrearCelda(string texto, iTextFont fuente, BaseColor fondo, int alineacion)
        {
            PdfPCell celda = new PdfPCell(new Phrase(texto, fuente));
            celda.BackgroundColor = fondo;
            celda.HorizontalAlignment = alineacion;
            celda.Padding = 6f;
            celda.Border = PdfPCell.BOTTOM_BORDER;
            celda.BorderColorBottom = new BaseColor(235, 235, 235);
            return celda;
        }
    }
}