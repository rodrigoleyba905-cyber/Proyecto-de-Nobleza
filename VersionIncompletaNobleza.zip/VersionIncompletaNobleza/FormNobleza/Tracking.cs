﻿using FormNobleza.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FormNobleza.Models;
using FormNobleza.Data;
using FormNobleza.Data;

namespace FormNobleza
{
    public partial class Tracking : Form
    {
        public Tracking()
        {
            InitializeComponent();
            ConfigurarInterfazInicial();
            RefrescarGridTracking();
        }
        //  Variable para saber si el botón guardar hará un INSERT nuevo o una REASIGNACIÓN
        private bool _esReasignacion = false;
        private readonly TrackingRepository _trackingRepository = new TrackingRepository();
        private readonly HardwareRepository _hardwareRepository = new HardwareRepository();
        /// <summary>
        /// Bloquea todos los controles de captura y oculta elementos dinámicos.
        /// Se llama al abrir el formulario y después de cada guardado exitoso.
        /// </summary>
        private void ConfigurarInterfazInicial()
        {
            txtIdTrabajador.Enabled = false;
            txtEncargado.Enabled = false;
            cmbUbicacion.Enabled = false;
            txtComentarios.Enabled = false;

            btnGuardarAsignacion.Enabled = false;
            btnGuardarAsignacion.Visible = true;
            btnGuardarAsignacion.Text = "Guardar";

            btnReasignar.Visible = false;
            btnReasignar.Enabled = false;

            cmbUbicacion.SelectedIndex = -1;
            txtIdTrabajador.Clear();
            txtEncargado.Clear();
            txtComentarios.Clear();

            lblAlerta.Text = "";
            lblAlerta.Visible = false;

            _esReasignacion = false;
            txtnumeroSerie.Focus();
        }

        private void BuscarEquipo()
        {
            string serie = txtnumeroSerie.Text.Trim();
            if (string.IsNullOrWhiteSpace(serie)) return;

            // Reset visual
            lblAlerta.Visible = false;
            btnReasignar.Visible = false;
            btnReasignar.Enabled = false;
            btnGuardarAsignacion.Enabled = false;
            DeshabilitarCampos();

            try
            {
               // ¿Existe el número de serie en hardware?
                bool existe = _hardwareRepository.ExisteNumeroSerie(serie);
                if (!existe)
                {
                    MostrarAlerta("Equipo no registrado en el sistema.", Color.OrangeRed);
                    return;
                }

                // Tiene asignación ACTIVA
                AsignacionTracking actual = _trackingRepository.BuscarAsignacionActiva(serie);

                if (actual == null)
                {
                    // RUTA A — Libre: alta nueva
                    MostrarAlerta(" Equipo disponible. Complete la asignación.", Color.SeaGreen);
                    HabilitarCampos();
                    btnGuardarAsignacion.Enabled = true;
                    _esReasignacion = false;
                }
                else
                {
                    // RUTA B — Ya asignado: mostrar dueño en naranja
                    txtIdTrabajador.Text = actual.idTrabajador;
                    txtEncargado.Text = actual.nombreTrabajador;
                    cmbUbicacion.Text = actual.nave;
                    txtComentarios.Text = actual.comentarios;

                    MostrarAlerta(
                        $" Asignado a: {actual.nombreTrabajador}  |  ID: {actual.idTrabajador}  |  Nave: {actual.nave}",
                        Color.DarkOrange);

                    btnReasignar.Visible = true;
                    btnReasignar.Enabled = true;
                    btnGuardarAsignacion.Enabled = false;
                    _esReasignacion = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al buscar el equipo: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Tracking_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnCrud_Click(object sender, EventArgs e)
        {

            Crud pantallaDashboard = new Crud();
            pantallaDashboard.Show();

            this.Hide(); 
        }

        private void btnHome_Click(object sender, EventArgs e)
        {

            Menu pantallaDashboard = new Menu();
            pantallaDashboard.Show();

            this.Hide(); 
        }

        private void btnTracking_Click(object sender, EventArgs e)
        {

            Tracking pantallaDashboard = new Tracking();
            pantallaDashboard.Show();

            this.Hide(); 
        }

        private void btnExit_Click(object sender, EventArgs e)
        {

            FormLogin pantallaDashboard = new FormLogin();
            pantallaDashboard.Show();

            this.Hide(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void txtUbicacion_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            Reportes pantallaDashboard = new Reportes();
            pantallaDashboard.Show();

            this.Hide(); 
        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtnumeroSerie_KeyDown(object sender, KeyEventArgs e)
        {
        
            if (e.KeyCode == Keys.Enter)
            {
                //Silenciamos el sonido de Windows
                e.SuppressKeyPress = true;
                BuscarEquipo();
            }
        
        }

        private void txtId_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnGuardarAsignacion_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(txtIdTrabajador.Text) ||
                 string.IsNullOrWhiteSpace(txtEncargado.Text) ||
                 cmbUbicacion.SelectedIndex == -1)
            {
                MessageBox.Show("ID Trabajador, Nombre y Nave son obligatorios.",
                                "Captura incompleta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string serie = txtnumeroSerie.Text.Trim();
                string idTrabajador = txtIdTrabajador.Text.Trim();
                string nombre = txtEncargado.Text.Trim();
                string nave = cmbUbicacion.Text;
                string comentarios = txtComentarios.Text.Trim();
                bool exito;

                if (_esReasignacion)
                {
                    // Le pasamos el 1 al final, simulando que el admin ID 1 está haciendo el movimiento
                    exito = _trackingRepository.ActualizarAsignacion(serie, nave, idTrabajador, nombre, comentarios, 1);
                        MessageBox.Show("Equipo reasignado exitosamente.",
                                        "Reasignación completada", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    RefrescarGridTracking();
                }
                else
                {
                    var nueva = new AsignacionTracking
                    {
                        numeroSerie = serie,
                        idTrabajador = idTrabajador,
                        nombreTrabajador = nombre,
                        nave = nave,
                        comentarios = comentarios,
                        estadoAsignacion = "ACTIVA",
                            asignadoPor = 1 

                    };

                    exito = _trackingRepository.InsertarAsignacion(nueva);
                    if (exito)
                        MessageBox.Show("Equipo asignado exitosamente.",
                                        "Asignación completada", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                if (!exito)
                {
                    MessageBox.Show("No se pudo guardar en la base de datos.",
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                txtnumeroSerie.Clear();
                ConfigurarInterfazInicial();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Excepción", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        

        private void btnReasignar_Click(object sender, EventArgs e)
        {
            HabilitarCampos();
            btnGuardarAsignacion.Enabled = true;
            btnGuardarAsignacion.Text = "Confirmar Reasignación";
            btnReasignar.Enabled = false;

            MostrarAlerta("✏ Edite los datos y confirme la reasignación.", Color.DarkOrange);
            txtIdTrabajador.Focus();
        }

        private void HabilitarCampos()
        {
            txtIdTrabajador.Enabled = true;
            txtEncargado.Enabled = true;
            cmbUbicacion.Enabled = true;
            txtComentarios.Enabled = true;
        }

        private void DeshabilitarCampos()
        {
            txtIdTrabajador.Enabled = false;
            txtEncargado.Enabled = false;
            cmbUbicacion.Enabled = false;
            txtComentarios.Enabled = false;

            txtIdTrabajador.Clear();
            txtEncargado.Clear();
            cmbUbicacion.SelectedIndex = -1;
            txtComentarios.Clear();
        }

        private void MostrarAlerta(string mensaje, Color color)
        {
            lblAlerta.Text = mensaje;
            lblAlerta.ForeColor = color;
            lblAlerta.Visible = true;
        }

        /// <summary>
        /// Llama al repositorio y refresca el DataGridView con los datos más recientes.
        /// </summary>
        private void RefrescarGridTracking()
        {
            try
            {
                // 1. Obtenemos los datos de MariaDB
                DataTable datos = _trackingRepository.ObtenerAsignacionesActivas();

                // 2. 💡 ¡OJO AQUÍ! Cambia 'dgvTracking' por el nombre real de tu DataGridView
                dataGridAsignacion.DataSource = datos;

                // 3. (Opcional) Le damos formato profesional a los títulos de las columnas
                if (dataGridAsignacion.Columns.Count > 0)
                {
                    dataGridAsignacion.Columns["idAsignacion"].Visible = false; // Ocultamos el ID interno de la BD
                    dataGridAsignacion.Columns["numeroSerie"].HeaderText = "NÚMERO DE SERIE";
                    dataGridAsignacion.Columns["idTrabajador"].HeaderText = "ID EMPLEADO";
                    dataGridAsignacion.Columns["nombreTrabajador"].HeaderText = "NOMBRE";
                    dataGridAsignacion.Columns["nave"].HeaderText = "NAVE";
                    dataGridAsignacion.Columns["fechaAsignacion"].HeaderText = "FECHA ASIGNADO";
                    dataGridAsignacion.Columns["comentarios"].HeaderText = "COMENTARIOS";

                    // Auto-ajustar el tamaño de las columnas
                    dataGridAsignacion.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo cargar la tabla de tracking: " + ex.Message,
                                "Error de Conexión", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

    }


}

