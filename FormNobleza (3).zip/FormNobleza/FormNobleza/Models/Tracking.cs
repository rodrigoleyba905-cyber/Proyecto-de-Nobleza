﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FormNobleza.Models
{
    
       
        public class AsignacionTracking
        {
            public int idTracking { get; set; }
            public string numeroSerie { get; set; }
            public string idTrabajador { get; set; }
            public string nombre { get; set; }
            public string nave { get; set; }
            public string comentarios { get; set; }
            public string estadoAsignacion { get; set; } // "Activa" o "Devuelta"
            public DateTime fechaAsignacion { get; set; }
        }
    }


