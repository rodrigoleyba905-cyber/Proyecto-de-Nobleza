﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;
namespace FormNobleza.Models.Tracking;


    public class TrackingRepository
    {
        // Tu cadena de conexión habitual (Ajusta la contraseña si la tienes diferente en XAMPP)
        private readonly string connectionString = "Server=localhost;Database=nobleza;Uid=root;Pwd=;";

        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(connectionString);
        }

        /// <summary>
        /// Busca si un número de serie específico tiene una asignación en estado 'Activa'.
        /// Esto decide si la pantalla se va por la Ruta A (Verde) o Ruta B (Naranja).
        /// </summary>
        public AsignacionTracking BuscarAsignacionActiva(string numeroSerie)
        {
            // El AND estadoAsignacion = 'Activa' es la clave de todo el sistema
            string query = @"SELECT * FROM asignaciones_hardware 
                             WHERE numeroSerie = @serie 
                             AND estadoAsignacion = 'Activa' LIMIT 1;";
            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@serie", numeroSerie.Trim());

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new AsignacionTracking
                                {
                                    idTracking = Convert.ToInt32(reader["idTracking"]),
                                    numeroSerie = reader["numeroSerie"].ToString(),
                                    idTrabajador = reader["idTrabajador"].ToString(),
                                    nombre = reader["nombre"].ToString(),
                                    nave = reader["nave"].ToString(),
                                    comentarios = reader["comentarios"].ToString(),
                                    estadoAsignacion = reader["estadoAsignacion"].ToString()
                                };
                            }
                        }
                    }
                }
                return null; // Si no hay registros 'Activos', la laptop está libre
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar la asignación activa: " + ex.Message);
            }
        }

        /// <summary>
        /// Registra una nueva asignación de hardware a un trabajador.
        /// </summary>
        public bool InsertarAsignacion(AsignacionTracking asignacion)
        {
            // No pasamos la fecha porque MariaDB la pone sola con CURRENT_TIMESTAMP
            string query = @"INSERT INTO asignaciones_hardware 
                             (numeroSerie, idTrabajador, nombre, nave, comentarios, estadoAsignacion) 
                             VALUES (@serie, @idTrab, @nombre, @nave, @comentarios, 'Activa');";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@serie", asignacion.numeroSerie);
                        command.Parameters.AddWithValue("@idTrab", asignacion.idTrabajador);
                        command.Parameters.AddWithValue("@nombre", asignacion.nombre);
                        command.Parameters.AddWithValue("@nave", asignacion.nave);
                        command.Parameters.AddWithValue("@comentarios", asignacion.comentarios);

                        int filas = command.ExecuteNonQuery();
                        return filas > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al insertar nueva asignación: " + ex.Message);
            }
        }

        /// <summary>
        /// Actualiza los datos de quien tiene la laptop (Modo Reasignación).
        /// Reemplaza al trabajador anterior con el nuevo en el mismo registro activo.
        /// </summary>
        public bool ActualizarAsignacion(string numeroSerie, string nave, string idTrabajador, string nombre, string comentarios)
        {
            string query = @"UPDATE asignaciones_hardware 
                             SET nave = @nave, 
                                 idTrabajador = @idTrab, 
                                 nombre = @nombre, 
                                 comentarios = @comentarios 
                             WHERE numeroSerie = @serie AND estadoAsignacion = 'Activa';";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@nave", nave);
                        command.Parameters.AddWithValue("@idTrab", idTrabajador);
                        command.Parameters.AddWithValue("@nombre", nombre);
                        command.Parameters.AddWithValue("@comentarios", comentarios);
                        command.Parameters.AddWithValue("@serie", numeroSerie);

                        int filas = command.ExecuteNonQuery();
                        return filas > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al reasignar el equipo: " + ex.Message);
            }
        }
    }



