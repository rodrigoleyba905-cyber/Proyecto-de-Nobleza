﻿using FormNobleza.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FormNobleza.Models.Tracking;
using FormNobleza.Models;


namespace FormNobleza
{
    public partial class Tracking : Form
    {
        public Tracking()
        {
            InitializeComponent();
            ConfigurarInterfazInicial();
        }
        // 💡 Variable global para saber si el botón guardar hará un INSERT nuevo o una REASIGNACIÓN
        private bool _esReasignacion = false;
        private readonly TrackingRepository _trackingRepository = new TrackingRepository();
        private readonly HardwareRepository _hardwareRepository = new HardwareRepository();
        /// <summary>
        /// Bloquea todos los controles de captura y oculta elementos dinámicos.
        /// Se llama al abrir el formulario y después de cada guardado exitoso.
        /// </summary>
        private void ConfigurarInterfazInicial()
        {
            // 1. Bloqueamos los controles de captura individuales (sin usar paneles)
            cmbUbicacion.Enabled = false;
            txtIdTrabajador.Enabled = false;
            txtEncargado.Enabled = false;
            txtComentarios.Enabled = false;

            // 2. Configuración segura de los botones
            btnGuardarAsignacion.Enabled = false;
            btnGuardarAsignacion.Visible = true;    // El de guardar se ve, pero no hace nada

            btnReasignar.Visible = false; // Escondemos el fantasma de reasignación
            btnReasignar.Enabled = false;
            btnReasignar.Text = "Reasignar"; // Lo reseteamos por si se había quedado en "Confirmar"

            // 3. La "escoba digital": Limpiamos todo el texto viejo
            // cboNave.SelectedIndex = -1 lo deja en blanco, o usa 0 si quieres que seleccione el primero
            cmbUbicacion.SelectedIndex = -1;
            txtIdTrabajador.Clear();
            txtEncargado.Clear();
            txtComentarios.Clear();

            // 4. Apagamos la etiqueta visual de estado (naranja/verde)
            lblAlerta.Text = "";
            lblAlerta.Visible = false;

            // 5. Regresamos el cursor al buscador para la siguiente pistola de escáner
            txtnumeroSerie.Focus();
        }
        
        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Tracking_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnCrud_Click(object sender, EventArgs e)
        {

            Crud pantallaDashboard = new Crud();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnHome_Click(object sender, EventArgs e)
        {

            Menu pantallaDashboard = new Menu();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnTracking_Click(object sender, EventArgs e)
        {

            Tracking pantallaDashboard = new Tracking();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnExit_Click(object sender, EventArgs e)
        {

            FormLogin pantallaDashboard = new FormLogin();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void txtUbicacion_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            Reportes pantallaDashboard = new Reportes();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtId_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Silenciamos el molesto sonido de 
                e.SuppressKeyPress = true;

                //LA MAGIA: Le decimos al botón de búsqueda que se presione a sí mismo
                // Nota: Cambia 'btnBuscarTracking' por el nombre real que le hayas puesto a tu botón
                btnTracking.PerformClick();
            }
        }

        private void txtId_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnGuardarAsignacion_Click(object sender, EventArgs e)
        {
          
            // 1. VALIDACIÓN UX: No permitimos asignaciones fantasma
            if (string.IsNullOrWhiteSpace(txtIdTrabajador.Text) ||
                string.IsNullOrWhiteSpace(txtEncargado.Text) ||
                cmbUbicacion.SelectedIndex == -1) // -1 significa que no ha elegido nada en el combo
            {
                MessageBox.Show("El ID del Trabajador, Nombre y Nave son datos obligatorios para asignar el equipo.",
                                "Captura Incompleta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // 2. EMPAQUETADO: Armamos el objeto con los datos de la interfaz
                AsignacionTracking nuevaAsignacion = new AsignacionTracking
                {
                    numeroSerie = txtnumeroSerie.Text.Trim(), // El que escaneó/buscó
                    idTrabajador = txtIdTrabajador.Text.Trim(),
                    nombre = txtEncargado.Text.Trim(),
                    nave = cmbUbicacion.Text,
                    comentarios = txtComentarios.Text.Trim(),
                    estadoAsignacion = "Activa" // Por defecto nace como activa
                };

                // 3. PERSISTENCIA: Mandamos a llamar a tu repositorio (Aún lo vamos a crear, pero dejamos la llamada lista)
                bool exito = _trackingRepository.InsertarAsignacion(nuevaAsignacion);

                if (exito)
                {
                    MessageBox.Show("El equipo ha sido asignado al trabajador exitosamente.",
                                    "Asignación Completada", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // 4. LIMPIEZA: Volvemos al estado 0 para que no puedan dar doble clic
                    txtnumeroSerie.Clear();
                    ConfigurarInterfazInicial();
                }
                else
                {
                    MessageBox.Show("No se pudo registrar la asignación en la base de datos.",
                                    "Error del Servidor", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error crítico en la capa de guardado: " + ex.Message,
                                "Excepción de Software", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
    }

