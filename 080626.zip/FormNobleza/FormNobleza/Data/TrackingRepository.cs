﻿using System;
using MySql.Data.MySqlClient;
using FormNobleza.Models;
using System.Data;

namespace FormNobleza.Data
{
    public class TrackingRepository : ConnectionToSql
    {
        /// <summary>
        /// Busca si un número de serie tiene una asignación ACTIVA.
        /// Retorna el objeto si existe, null si el equipo está libre.
        /// </summary>
        public AsignacionTracking BuscarAsignacionActiva(string numeroSerie)
        {
            string query = @"SELECT * FROM asignaciones 
                             WHERE numeroSerie = @serie 
                               AND estadoAsignacion = 'ACTIVA' 
                             LIMIT 1;";
            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@serie", numeroSerie.Trim());

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new AsignacionTracking
                                {
                                    idAsignacion = Convert.ToInt32(reader["idAsignacion"]),
                                    numeroSerie = reader["numeroSerie"].ToString(),
                                    idTrabajador = reader["idTrabajador"].ToString(),
                                    nombreTrabajador = reader["nombreTrabajador"].ToString(),
                                    nave = reader["nave"].ToString(),
                                    comentarios = reader["comentarios"].ToString(),
                                    estadoAsignacion = reader["estadoAsignacion"].ToString(),
                                    fechaAsignacion = Convert.ToDateTime(reader["fechaAsignacion"]),
                                    asignadoPor = Convert.ToInt32(reader["asignadoPor"])
                                };
                            }
                        }
                    }
                }
                return null; // Equipo libre
            }
            catch (Exception ex)
            {
                throw new Exception("Error al consultar la asignación activa: " + ex.Message);
            }
        }

        /// <summary>
        /// Registra una nueva asignación (INSERT).
        /// fechaAsignacion la genera MariaDB con DEFAULT current_timestamp().
        /// </summary>
        public bool InsertarAsignacion(AsignacionTracking asignacion)
        {
            string query = @"INSERT INTO asignaciones 
                             (numeroSerie, idTrabajador, nombreTrabajador, nave, comentarios, asignadoPor, estadoAsignacion) 
                             VALUES (@serie, @idTrab, @nombre, @nave, @comentarios, @asignadoPor, 'ACTIVA');";
            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@serie", asignacion.numeroSerie);
                        command.Parameters.AddWithValue("@idTrab", asignacion.idTrabajador);
                        command.Parameters.AddWithValue("@nombre", asignacion.nombreTrabajador);
                        command.Parameters.AddWithValue("@nave", asignacion.nave);
                        command.Parameters.AddWithValue("@comentarios", asignacion.comentarios ?? "");
                        command.Parameters.AddWithValue("@asignadoPor", asignacion.asignadoPor);

                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al insertar nueva asignación: " + ex.Message);
            }
        }

        /// <summary>
        /// Actualiza el dueño actual (UPDATE – modo Reasignación).
        /// Solo afecta el registro ACTIVA del número de serie.
        /// </summary>
        public bool ActualizarAsignacion(string numeroSerie, string nave, string idTrabajador,
                                         string nombreTrabajador, string comentarios)
        {
            string query = @"UPDATE asignaciones 
                             SET nave             = @nave,
                                 idTrabajador     = @idTrab,
                                 nombreTrabajador = @nombre,
                                 comentarios      = @comentarios
                             WHERE numeroSerie    = @serie 
                               AND estadoAsignacion = 'ACTIVA';";
            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@nave", nave);
                        command.Parameters.AddWithValue("@idTrab", idTrabajador);
                        command.Parameters.AddWithValue("@nombre", nombreTrabajador);
                        command.Parameters.AddWithValue("@comentarios", comentarios ?? "");
                        command.Parameters.AddWithValue("@serie", numeroSerie);

                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al reasignar el equipo: " + ex.Message);
            }
        }

        /// <summary>
        /// Extrae todo el historial de equipos que actualmente están asignados (ACTIVOS)
        /// </summary>
        /// 

        public  DataTable ObtenerAsignacionesActivas()
        {
            DataTable tablaVacia = new DataTable();
            // Traemos los datos clave y los ordenamos para que la asignación más reciente salga hasta arriba
            string query = @"SELECT idAsignacion, numeroSerie, idTrabajador, nombreTrabajador, nave, fechaAsignacion, comentarios 
                     FROM asignaciones 
                     WHERE estadoAsignacion = 'ACTIVA' 
                     ORDER BY fechaAsignacion DESC;";
            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        // El DataAdapter ejecuta el query y llena el DataTable automáticamente
                        using (var adapter = new MySqlDataAdapter(command))
                        {
                            adapter.Fill(tablaVacia);
                        }
                    }
                }
                return tablaVacia;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al obtener el historial de tracking: " + ex.Message);
            }
        }

    }
}