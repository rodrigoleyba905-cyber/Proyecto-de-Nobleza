﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FormNobleza.Data
{
    internal class ReportesRepository
    {
    }
}
