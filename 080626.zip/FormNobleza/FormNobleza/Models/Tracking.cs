﻿using System;

namespace FormNobleza.Models
{
    public class AsignacionTracking
    {
        public int idAsignacion { get; set; }
        public string numeroSerie { get; set; }
        public string idTrabajador { get; set; }
        public string nombreTrabajador { get; set; }   // nombreTrabajador en BD
        public string nave { get; set; }
        public string comentarios { get; set; }
        public string estadoAsignacion { get; set; }   // 'ACTIVA' | 'INACTIVA'
        public DateTime fechaAsignacion { get; set; }
        public int asignadoPor { get; set; }   // FK → usuarios.idUsuario
    }
}